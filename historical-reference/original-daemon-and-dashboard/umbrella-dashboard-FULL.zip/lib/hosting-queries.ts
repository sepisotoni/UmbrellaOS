'use client'

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from './api'

// --- Nodes ---
export function useNodes() {
  return useQuery({ queryKey: ['hosting', 'nodes'], queryFn: api.listNodes })
}
export function useNode(nodeId: string) {
  return useQuery({ queryKey: ['hosting', 'node', nodeId], queryFn: () => api.getNode(nodeId) })
}
export function useRegisterNode() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (body: { name: string; daemon_url: string; labels?: Record<string, string> }) =>
      api.registerNode(body),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['hosting', 'nodes'] }),
  })
}

// --- Templates ---
export function useTemplates() {
  return useQuery({ queryKey: ['hosting', 'templates'], queryFn: api.listTemplates })
}
export function useCreateTemplate() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (body: Parameters<typeof api.createTemplate>[0]) => api.createTemplate(body),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['hosting', 'templates'] }),
  })
}

// --- Allocations ---
export function useFreeAllocations(nodeId: string | undefined) {
  return useQuery({
    queryKey: ['hosting', 'allocations', 'free', nodeId],
    queryFn: () => api.listFreeAllocations(nodeId as string),
    enabled: !!nodeId,
  })
}
export function useCreateAllocation() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (body: { node_id: string; port: number; protocol?: string }) => api.createAllocation(body),
    onSuccess: (_, variables) =>
      queryClient.invalidateQueries({ queryKey: ['hosting', 'allocations', 'free', variables.node_id] }),
  })
}

// --- Servers ---
export function useServersFleet(nodeId?: string) {
  return useQuery({ queryKey: ['hosting', 'servers', nodeId ?? 'all'], queryFn: () => api.listServers(nodeId) })
}
export function useHostedServer(serverId: string) {
  return useQuery({ queryKey: ['hosting', 'server', serverId], queryFn: () => api.getServer(serverId) })
}
export function useServerStats(serverId: string, enabled = true) {
  return useQuery({
    queryKey: ['hosting', 'server', serverId, 'stats'],
    queryFn: () => api.getServerStats(serverId),
    enabled,
    refetchInterval: 5000, // live-ish stats without a push channel yet (Phase 9 observability)
  })
}
export function useCreateServer() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (body: Parameters<typeof api.createServer>[0]) => api.createServer(body),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['hosting', 'servers'] }),
  })
}

function useServerAction(action: (serverId: string) => Promise<unknown>) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (serverId: string) => action(serverId),
    onSuccess: (_, serverId) => {
      queryClient.invalidateQueries({ queryKey: ['hosting', 'servers'] })
      queryClient.invalidateQueries({ queryKey: ['hosting', 'server', serverId] })
    },
  })
}
export function useStartServer() { return useServerAction(api.startServer) }
export function useRestartServer() { return useServerAction(api.restartServer) }
export function useKillServer() { return useServerAction(api.killServer) }
export function useStopServer() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ serverId, gracePeriodSeconds }: { serverId: string; gracePeriodSeconds?: number }) =>
      api.stopServer(serverId, gracePeriodSeconds),
    onSuccess: (_, { serverId }) => {
      queryClient.invalidateQueries({ queryKey: ['hosting', 'servers'] })
      queryClient.invalidateQueries({ queryKey: ['hosting', 'server', serverId] })
    },
  })
}
export function useDeleteServer() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (serverId: string) => api.deleteServer(serverId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['hosting', 'servers'] }),
  })
}

// --- Identity: API keys + MFA ---
export function useApiKeys() {
  return useQuery({ queryKey: ['identity', 'apikeys'], queryFn: api.listApiKeys })
}
export function useCreateApiKey() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (body: { name: string; permissions?: string[]; expires_in_days?: number }) =>
      api.createApiKey(body),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['identity', 'apikeys'] }),
  })
}
export function useRevokeApiKey() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (apiKeyId: string) => api.revokeApiKey(apiKeyId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['identity', 'apikeys'] }),
  })
}
