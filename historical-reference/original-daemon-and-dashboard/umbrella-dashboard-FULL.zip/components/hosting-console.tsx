'use client'

import { useEffect, useRef, useState } from 'react'
import { Send } from 'lucide-react'
import { API_ROOT, getToken } from '@/lib/api-config'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

/**
 * Live console viewer/input for one hosted server, over the WebSocket proxy
 * at api/routers/hosting_console_ws.py — core never hands the dashboard a
 * node token directly; the dashboard only ever holds its own session
 * token, which core validates and uses to open the proxied connection to
 * the correct node's daemon.
 */
export function HostingConsole({ serverId }: { serverId: string }) {
  const [lines, setLines] = useState<string[]>([])
  const [command, setCommand] = useState('')
  const [connected, setConnected] = useState(false)
  const socketRef = useRef<WebSocket | null>(null)
  const scrollRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    const token = getToken()
    if (!token) return

    const wsRoot = API_ROOT.replace(/^http/, 'ws')
    const socket = new WebSocket(`${wsRoot}/api/v1/hosting/servers/${serverId}/console?token=${token}`)
    socket.binaryType = 'arraybuffer'
    socketRef.current = socket

    socket.onopen = () => setConnected(true)
    socket.onclose = () => setConnected(false)
    socket.onerror = () => setConnected(false)
    socket.onmessage = (event) => {
      const text =
        typeof event.data === 'string' ? event.data : new TextDecoder().decode(event.data as ArrayBuffer)
      setLines((prev) => [...prev.slice(-999), ...text.split('\n')])
    }

    return () => socket.close()
  }, [serverId])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight })
  }, [lines])

  function sendCommand() {
    if (!command.trim() || !socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) return
    socketRef.current.send(new TextEncoder().encode(command + '\n'))
    setCommand('')
  }

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">
          {connected ? 'Connected' : 'Disconnected'}
        </span>
      </div>
      <div
        ref={scrollRef}
        className="h-96 overflow-y-auto rounded-lg border border-border bg-black/90 p-3 font-mono text-xs text-green-400"
      >
        {lines.length === 0 ? (
          <span className="text-muted-foreground">Waiting for console output…</span>
        ) : (
          lines.map((line, i) => <div key={i} className="whitespace-pre-wrap break-all">{line}</div>)
        )}
      </div>
      <div className="flex gap-2">
        <Input
          value={command}
          onChange={(e) => setCommand(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') sendCommand()
          }}
          placeholder="Type a server command…"
          disabled={!connected}
          className="font-mono"
        />
        <Button onClick={sendCommand} disabled={!connected} size="icon" aria-label="Send command">
          <Send className="size-4" />
        </Button>
      </div>
    </div>
  )
}
