'use client'

import { useState } from 'react'
import { Plus, Copy, Check } from 'lucide-react'
import { toast } from 'sonner'
import { useNodes, useRegisterNode, useCreateAllocation, useFreeAllocations } from '@/lib/hosting-queries'
import { PageHeader } from '@/components/page-header'
import { GenericStatusBadge } from '@/components/status-badge'
import type { HostingNode } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

export default function HostingNodesPage() {
  const { data: nodes, isLoading } = useNodes()

  return (
    <>
      <PageHeader title="Nodes" description="Every host running umbrella-daemon.">
        <RegisterNodeDialog />
      </PageHeader>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {isLoading || !nodes
          ? Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-40 rounded-xl" />)
          : nodes.length === 0
            ? <p className="text-sm text-muted-foreground col-span-full">No nodes registered yet.</p>
            : nodes.map((n) => <NodeCard key={n.id} node={n} />)}
      </div>
    </>
  )
}

function NodeCard({ node }: { node: HostingNode }) {
  const [port, setPort] = useState('')
  const createAllocation = useCreateAllocation()
  const { data: freeAllocations } = useFreeAllocations(node.id)

  async function addPort() {
    const parsed = parseInt(port, 10)
    if (!parsed || parsed < 1 || parsed > 65535) {
      toast.error('Enter a valid port number (1-65535)')
      return
    }
    try {
      await createAllocation.mutateAsync({ node_id: node.id, port: parsed })
      toast.success(`Reserved port ${parsed}`)
      setPort('')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to reserve port')
    }
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="font-mono text-base">{node.name}</CardTitle>
          <GenericStatusBadge status={node.status} />
        </div>
        <p className="truncate text-xs text-muted-foreground" title={node.daemon_url}>{node.daemon_url}</p>
      </CardHeader>
      <CardContent className="flex flex-col gap-3">
        <p className="text-xs text-muted-foreground">
          {(freeAllocations ?? []).length} free port allocation{(freeAllocations ?? []).length === 1 ? '' : 's'}
        </p>
        <div className="flex gap-2">
          <Input
            value={port}
            onChange={(e) => setPort(e.target.value)}
            placeholder="25565"
            className="font-mono"
          />
          <Button size="sm" variant="outline" disabled={createAllocation.isPending} onClick={addPort}>
            <Plus className="size-4" /> Reserve
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

function RegisterNodeDialog() {
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const [daemonUrl, setDaemonUrl] = useState('')
  const [signingSecret, setSigningSecret] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const registerNode = useRegisterNode()

  async function handleRegister() {
    if (!name || !daemonUrl) {
      toast.error('Name and daemon URL are required')
      return
    }
    try {
      const node = await registerNode.mutateAsync({ name, daemon_url: daemonUrl })
      setSigningSecret(node.signing_secret)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to register node')
    }
  }

  function copySecret() {
    if (!signingSecret) return
    navigator.clipboard.writeText(signingSecret)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  function handleOpenChange(next: boolean) {
    setOpen(next)
    if (!next) {
      setName(''); setDaemonUrl(''); setSigningSecret(null); setCopied(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger render={<Button><Plus className="size-4" /> Register node</Button>} />
      <DialogContent>
        {signingSecret ? (
          <>
            <DialogHeader>
              <DialogTitle>Node registered</DialogTitle>
              <DialogDescription>
                Copy this signing secret now — it will not be shown again. Set it as
                <code className="mx-1 rounded bg-muted px-1 py-0.5 text-xs">UMBRELLA_NODE_SIGNING_SECRET</code>
                on the node before starting umbrella-daemon.
              </DialogDescription>
            </DialogHeader>
            <div className="flex items-center gap-2 rounded-lg border border-border bg-muted/40 p-3">
              <code className="flex-1 break-all font-mono text-xs">{signingSecret}</code>
              <Button size="icon" variant="ghost" onClick={copySecret} aria-label="Copy secret">
                {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
              </Button>
            </div>
            <DialogFooter>
              <Button onClick={() => handleOpenChange(false)}>Done</Button>
            </DialogFooter>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle>Register a node</DialogTitle>
              <DialogDescription>
                The daemon URL is the base address of umbrella-daemon on that host (e.g. https://node1.example.com:8443).
              </DialogDescription>
            </DialogHeader>
            <div className="flex flex-col gap-4 py-2">
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="node-name">Name</Label>
                <Input id="node-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="node-1" />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="node-url">Daemon URL</Label>
                <Input
                  id="node-url"
                  value={daemonUrl}
                  onChange={(e) => setDaemonUrl(e.target.value)}
                  placeholder="https://node1.example.com:8443"
                  className="font-mono"
                />
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleRegister} disabled={registerNode.isPending}>Register</Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}
