'use client'

import { use } from 'react'
import Link from 'next/link'
import { ArrowLeft, Power, Square, RefreshCw, Skull } from 'lucide-react'
import { toast } from 'sonner'
import {
  useHostedServer, useServerStats, useStartServer, useStopServer, useRestartServer, useKillServer,
} from '@/lib/hosting-queries'
import { PageHeader } from '@/components/page-header'
import { GenericStatusBadge } from '@/components/status-badge'
import { HostingConsole } from '@/components/hosting-console'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'

export default function HostedServerDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const { data: server, isLoading } = useHostedServer(id)
  const isRunning = server?.status === 'running'
  const { data: stats } = useServerStats(id, isRunning)

  const start = useStartServer()
  const stop = useStopServer()
  const restart = useRestartServer()
  const kill = useKillServer()
  const busy = start.isPending || stop.isPending || restart.isPending || kill.isPending

  async function run(label: string, fn: () => Promise<unknown>) {
    try {
      await fn()
      toast.success(`${label} succeeded`)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : `${label} failed`)
    }
  }

  if (isLoading || !server) {
    return <Skeleton className="h-96 rounded-xl" />
  }

  const cpuPct = Math.min(100, stats?.cpu_percent ?? 0)
  const memPct = stats && stats.memory_limit_bytes > 0
    ? Math.round((stats.memory_used_bytes / stats.memory_limit_bytes) * 100)
    : 0

  return (
    <>
      <PageHeader title={server.name} description={`Server ${server.id}`}>
        <Button variant="outline" render={<Link href="/hosting"><ArrowLeft className="size-4" /> Back to fleet</Link>} />
      </PageHeader>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">Status</CardTitle>
              <GenericStatusBadge status={server.status} />
            </div>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>CPU</span>
                <span className="tabular-nums">{isRunning ? `${cpuPct.toFixed(1)}%` : '—'}</span>
              </div>
              <Progress value={isRunning ? cpuPct : 0} />
            </div>
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>Memory</span>
                <span className="tabular-nums">
                  {isRunning && stats
                    ? `${(stats.memory_used_bytes / 1024 / 1024).toFixed(0)} / ${(stats.memory_limit_bytes / 1024 / 1024).toFixed(0)} MB`
                    : '—'}
                </span>
              </div>
              <Progress value={memPct} />
            </div>
            <div className="flex flex-wrap gap-2 pt-2">
              <Button size="sm" variant="outline" disabled={busy} onClick={() => run('Start', () => start.mutateAsync(server.id))}>
                <Power className="size-4" /> Start
              </Button>
              <Button size="sm" variant="outline" disabled={busy} onClick={() => run('Stop', () => stop.mutateAsync({ serverId: server.id }))}>
                <Square className="size-4" /> Stop
              </Button>
              <Button size="sm" variant="outline" disabled={busy} onClick={() => run('Restart', () => restart.mutateAsync(server.id))}>
                <RefreshCw className="size-4" /> Restart
              </Button>
              <Button size="sm" variant="ghost" disabled={busy} onClick={() => run('Kill', () => kill.mutateAsync(server.id))} title="Force kill — no grace period">
                <Skull className="size-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Console</CardTitle>
          </CardHeader>
          <CardContent>
            <HostingConsole serverId={server.id} />
          </CardContent>
        </Card>
      </div>
    </>
  )
}
