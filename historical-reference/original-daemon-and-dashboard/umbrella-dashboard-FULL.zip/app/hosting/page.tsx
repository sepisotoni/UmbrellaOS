'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Plus, RefreshCw, Square, Power, Trash2, Skull } from 'lucide-react'
import { toast } from 'sonner'
import {
  useServersFleet, useNodes, useTemplates, useFreeAllocations,
  useCreateServer, useStartServer, useStopServer, useRestartServer, useKillServer, useDeleteServer,
} from '@/lib/hosting-queries'
import { PageHeader } from '@/components/page-header'
import { GenericStatusBadge } from '@/components/status-badge'
import type { HostedServer } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'

export default function HostingFleetPage() {
  const { data: servers, isLoading } = useServersFleet()

  return (
    <>
      <PageHeader
        title="Hosting"
        description="The multi-node, Docker-orchestrated server fleet — distinct from the legacy single-server Servers page."
      >
        <Button variant="outline" render={<Link href="/hosting/nodes">Manage nodes</Link>} />
        <CreateServerDialog />
      </PageHeader>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {isLoading || !servers
          ? Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-56 rounded-xl" />)
          : servers.length === 0
            ? <p className="text-sm text-muted-foreground col-span-full">No hosted servers yet — create one to get started.</p>
            : servers.map((s) => <HostedServerCard key={s.id} server={s} />)}
      </div>
    </>
  )
}

function HostedServerCard({ server }: { server: HostedServer }) {
  const start = useStartServer()
  const stop = useStopServer()
  const restart = useRestartServer()
  const kill = useKillServer()
  const del = useDeleteServer()

  const busy = start.isPending || stop.isPending || restart.isPending || kill.isPending || del.isPending

  async function run(label: string, fn: () => Promise<unknown>) {
    try {
      await fn()
      toast.success(`${label} succeeded`)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : `${label} failed`)
    }
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="font-mono text-base">
            <Link href={`/hosting/servers/${server.id}`} className="hover:underline">{server.name}</Link>
          </CardTitle>
          <GenericStatusBadge status={server.status} />
        </div>
        <p className="text-xs text-muted-foreground">
          {server.cpu_cores} vCPU · {(server.memory_bytes / 1024 / 1024 / 1024).toFixed(1)} GB RAM · template v{server.template_version}
        </p>
      </CardHeader>
      <CardContent className="flex flex-wrap items-center gap-2">
        <Button size="sm" variant="outline" disabled={busy} onClick={() => run('Start', () => start.mutateAsync(server.id))}>
          <Power className="size-4" /> Start
        </Button>
        <Button size="sm" variant="outline" disabled={busy} onClick={() => run('Stop', () => stop.mutateAsync({ serverId: server.id }))}>
          <Square className="size-4" /> Stop
        </Button>
        <Button size="sm" variant="outline" disabled={busy} onClick={() => run('Restart', () => restart.mutateAsync(server.id))}>
          <RefreshCw className="size-4" /> Restart
        </Button>
        <Button size="sm" variant="ghost" disabled={busy} onClick={() => run('Kill', () => kill.mutateAsync(server.id))} title="Force kill — no grace period">
          <Skull className="size-4" />
        </Button>
        <Button
          size="sm"
          variant="ghost"
          disabled={busy}
          onClick={() => {
            if (confirm(`Delete "${server.name}" permanently? This removes its container and cannot be undone.`)) {
              run('Delete', () => del.mutateAsync(server.id))
            }
          }}
          aria-label="Delete server"
        >
          <Trash2 className="size-4 text-destructive" />
        </Button>
      </CardContent>
    </Card>
  )
}

function CreateServerDialog() {
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const [nodeId, setNodeId] = useState('')
  const [templateId, setTemplateId] = useState('')
  const [allocationId, setAllocationId] = useState('')

  const { data: nodes } = useNodes()
  const { data: templates } = useTemplates()
  const { data: allocations } = useFreeAllocations(nodeId || undefined)
  const createServer = useCreateServer()

  async function handleCreate() {
    if (!name || !nodeId || !templateId || !allocationId) {
      toast.error('Fill in every field first')
      return
    }
    try {
      await createServer.mutateAsync({
        name, node_id: nodeId, template_id: templateId, allocation_ids: [allocationId],
      })
      toast.success(`Server "${name}" created`)
      setOpen(false)
      setName(''); setNodeId(''); setTemplateId(''); setAllocationId('')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to create server')
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger render={<Button><Plus className="size-4" /> New server</Button>} />
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create a server</DialogTitle>
          <DialogDescription>Pick a node, a template, and a free port allocation.</DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-4 py-2">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="server-name">Name</Label>
            <Input id="server-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Survival" />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label>Node</Label>
            <Select value={nodeId} onValueChange={(value) => { if (value) { setNodeId(value); setAllocationId('') } }}>
              <SelectTrigger><SelectValue placeholder="Choose a node" /></SelectTrigger>
              <SelectContent>
                {(nodes ?? []).map((n) => <SelectItem key={n.id} value={n.id}>{n.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-col gap-1.5">
            <Label>Template</Label>
            <Select value={templateId} onValueChange={(value) => { if (value) setTemplateId(value) }}>
              <SelectTrigger><SelectValue placeholder="Choose a template" /></SelectTrigger>
              <SelectContent>
                {(templates ?? []).map((t) => (
                  <SelectItem key={t.id} value={t.id}>{t.name} (v{t.version})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-col gap-1.5">
            <Label>Port allocation</Label>
            <Select value={allocationId} onValueChange={(value) => { if (value) setAllocationId(value) }}>
              <SelectTrigger><SelectValue placeholder={nodeId ? 'Choose a free port' : 'Choose a node first'} /></SelectTrigger>
              <SelectContent>
                {(allocations ?? []).map((a) => (
                  <SelectItem key={a.id} value={a.id}>{a.port}/{a.protocol}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button onClick={handleCreate} disabled={createServer.isPending}>Create</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
