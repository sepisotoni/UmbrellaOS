'use client'

import { useEffect, useState } from 'react'
import { Eye, EyeOff } from 'lucide-react'
import { toast } from 'sonner'
import { useSettings, useBridgeSettings, useUpdateBridgeSettings } from '@/lib/queries'
import { api } from '@/lib/api'
import { PageHeader } from '@/components/page-header'
import { StatusPill } from '@/components/status-badge'
import type { SettingItem, SettingsCategory, BridgeMode } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { Switch } from '@/components/ui/switch'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

export default function SettingsPage() {
  const { data, isLoading, isError, refetch } = useSettings()
  const [isSaving, setIsSaving] = useState(false)
  const [modifiedSettings, setModifiedSettings] = useState<Record<string, string>>({})

  if (isLoading) {
    return (
      <>
        <PageHeader title="Settings" description="Configure the Umbrella Core platform." />
        <Skeleton className="h-96 w-full rounded-xl" />
      </>
    )
  }

  if (isError || !data?.length) {
    return (
      <>
        <PageHeader title="Settings" description="Owner access required." />
        <p className="text-sm text-muted-foreground">Only the network owner can view and edit settings.</p>
      </>
    )
  }

  const handleSave = async () => {
    setIsSaving(true)
    try {
      const savePromises = Object.entries(modifiedSettings).map(([key, value]) =>
        api.updateSetting(key, value)
      )
      await Promise.all(savePromises)
      setModifiedSettings({})
      await refetch()
      toast.success('Settings saved successfully')
    } catch (error) {
      toast.error('Failed to save settings')
      console.error(error)
    } finally {
      setIsSaving(false)
    }
  }

  const hasChanges = Object.keys(modifiedSettings).length > 0

  return (
    <>
      <PageHeader title="Settings" description="Configure the Umbrella Core platform.">
        <Button size="sm" onClick={handleSave} disabled={!hasChanges || isSaving}>
          {isSaving ? 'Saving...' : hasChanges ? 'Save changes' : 'No changes'}
        </Button>
      </PageHeader>

      <Tabs defaultValue={data[0]?.id} className="w-full">
        <TabsList className="flex h-auto w-full flex-wrap justify-start gap-1">
          {data.map((cat) => (
            <TabsTrigger key={cat.id} value={cat.id}>
              {cat.label}
            </TabsTrigger>
          ))}
        </TabsList>
        {data.map((cat) => (
          <TabsContent key={cat.id} value={cat.id} className="mt-4">
            <CategoryPanel category={cat} modifiedSettings={modifiedSettings} onSettingChange={setModifiedSettings} />
          </TabsContent>
        ))}
      </Tabs>

      <Card className="mt-6">
        <CardContent className="p-6">
          <ChatBridgeSection />
        </CardContent>
      </Card>
    </>
  )
}

function CategoryPanel({ category, modifiedSettings, onSettingChange }: { category: SettingsCategory; modifiedSettings: Record<string, string>; onSettingChange: (settings: Record<string, string>) => void }) {
  return (
    <Card>
      <CardContent className="flex flex-col gap-1 p-0">
        {(category.items || []).map((item, i) => (
          <div key={item.key}>
            {i > 0 ? <div className="h-px bg-border" /> : null}
            <SettingRow item={item} modifiedSettings={modifiedSettings} onSettingChange={onSettingChange} />
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

function SettingRow({ item, modifiedSettings, onSettingChange }: { item: SettingItem; modifiedSettings: Record<string, string>; onSettingChange: (settings: Record<string, string>) => void }) {
  const currentValue = modifiedSettings[item.key] !== undefined ? modifiedSettings[item.key] : item.value

  return (
    <div className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <Label htmlFor={item.key} className="text-sm font-medium">
            {item.label}
          </Label>
          {item.restartRequired ? (
            <StatusPill tone="warning" dot={false} className="normal-case">
              Restart required
            </StatusPill>
          ) : null}
        </div>
        <p className="text-xs text-muted-foreground">{item.description}</p>
      </div>
      <div className="w-full sm:w-64">
        <SettingControl item={item} value={currentValue} onChange={(newValue) => {
          onSettingChange({ ...modifiedSettings, [item.key]: newValue })
        }} />
      </div>
    </div>
  )
}

function SettingControl({ item, value, onChange }: { item: SettingItem; value: string | number | boolean; onChange: (newValue: string) => void }) {
  const [reveal, setReveal] = useState(false)

  if (item.type === 'boolean') {
    return (
      <div className="flex sm:justify-end">
        <Switch
          id={item.key}
          checked={Boolean(value)}
          onCheckedChange={(checked) => onChange(String(checked))}
        />
      </div>
    )
  }

  if (item.type === 'select') {
    return (
      <Select
        value={String(value)}
        onValueChange={(val) => onChange(val)}
      >
        <SelectTrigger id={item.key} className="w-full capitalize">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {(item.options ?? []).map((opt) => (
            <SelectItem key={opt} value={opt} className="capitalize">
              {opt}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    )
  }

  if (item.type === 'secret') {
    return (
      <div className="relative">
        <Input
          id={item.key}
          type={reveal ? 'text' : 'password'}
          value={String(value)}
          onChange={(e) => onChange(e.target.value)}
          className="pr-9 font-mono"
        />
        <button
          type="button"
          onClick={() => setReveal((v) => !v)}
          className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
          aria-label={reveal ? 'Hide secret' : 'Reveal secret'}
        >
          {reveal ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
        </button>
      </div>
    )
  }

  return (
    <Input
      id={item.key}
      type={item.type === 'number' ? 'number' : 'text'}
      value={String(value)}
      onChange={(e) => onChange(e.target.value)}
    />
  )
}

function ChatBridgeSection() {
  const { data: bridgeSettings, isLoading } = useBridgeSettings()
  const updateBridgeSettings = useUpdateBridgeSettings()
  const [mode, setMode] = useState<BridgeMode>('off')
  const [mcToDiscord, setMcToDiscord] = useState(true)
  const [discordToMc, setDiscordToMc] = useState(true)
  const [showAvatars, setShowAvatars] = useState(true)
  const [discordChannelId, setDiscordChannelId] = useState('')

  useEffect(() => {
    if (bridgeSettings) {
      setMode(bridgeSettings.mode)
      setMcToDiscord(bridgeSettings.mc_to_discord)
      setDiscordToMc(bridgeSettings.discord_to_mc)
      setShowAvatars(bridgeSettings.show_avatars)
      setDiscordChannelId(bridgeSettings.discord_channel_id)
    }
  }, [bridgeSettings])

  const handleSave = async () => {
    try {
      await updateBridgeSettings.mutateAsync({
        mode,
        mc_to_discord: mcToDiscord,
        discord_to_mc: discordToMc,
        show_avatars: showAvatars,
        discord_channel_id: discordChannelId,
      })
      toast.success('Bridge settings saved')
    } catch (error) {
      toast.error('Failed to save bridge settings')
    }
  }

  if (isLoading) {
    return <Skeleton className="h-64 w-full" />
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h3 className="text-lg font-semibold">Chat Bridge</h3>
        <p className="text-sm text-muted-foreground">
          Configure the Minecraft-Discord chat bridge settings
        </p>
      </div>

      <div className="flex flex-col gap-4">
        <div className="flex flex-col gap-2">
          <Label className="text-sm font-medium">Bridge Mode</Label>
          <RadioGroup value={mode} onValueChange={(v) => setMode(v as BridgeMode)}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="off" id="mode-off" />
              <Label htmlFor="mode-off" className="text-sm">
                Off — no connection
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="partial" id="mode-partial" />
              <Label htmlFor="mode-partial" className="text-sm">
                Partial — players type /disc message to send to Discord
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="full" id="mode-full" />
              <Label htmlFor="mode-full" className="text-sm">
                Full — everything mirrors automatically
              </Label>
            </div>
          </RadioGroup>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex flex-col gap-1">
            <Label htmlFor="mc-to-discord" className="text-sm font-medium">
              Minecraft → Discord
            </Label>
            <p className="text-xs text-muted-foreground">
              Forward Minecraft chat to Discord
            </p>
          </div>
          <Switch
            id="mc-to-discord"
            checked={mcToDiscord}
            onCheckedChange={setMcToDiscord}
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="flex flex-col gap-1">
            <Label htmlFor="discord-to-mc" className="text-sm font-medium">
              Discord → Minecraft
            </Label>
            <p className="text-xs text-muted-foreground">
              Forward Discord chat to Minecraft
            </p>
          </div>
          <Switch
            id="discord-to-mc"
            checked={discordToMc}
            onCheckedChange={setDiscordToMc}
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="flex flex-col gap-1">
            <Label htmlFor="show-avatars" className="text-sm font-medium">
              Show player avatars
            </Label>
            <p className="text-xs text-muted-foreground">
              Display player avatars in bridged messages
            </p>
          </div>
          <Switch
            id="show-avatars"
            checked={showAvatars}
            onCheckedChange={setShowAvatars}
          />
        </div>

        <div className="flex flex-col gap-2">
          <Label htmlFor="discord-channel-id" className="text-sm font-medium">
            Discord Channel ID
          </Label>
          <Input
            id="discord-channel-id"
            value={discordChannelId}
            onChange={(e) => setDiscordChannelId(e.target.value)}
            placeholder="123456789012345678"
          />
        </div>

        <Button onClick={handleSave} className="w-fit">
          Save Bridge Settings
        </Button>
      </div>
    </div>
  )
}
