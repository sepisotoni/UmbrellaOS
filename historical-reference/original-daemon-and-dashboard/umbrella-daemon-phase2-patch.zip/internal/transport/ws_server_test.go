package transport

import (
	"bytes"
	"context"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/gorilla/websocket"

	"umbrella-daemon/internal/auth"
	"umbrella-daemon/internal/environment"
)

const testSecret = "transport-test-secret-at-least-32-bytes-long"

// fakeEnvironment is a test double implementing environment.Environment,
// used to verify the HTTP/WS adapter layer (routing, auth, request/response
// shape) independent of a real container runtime — the same pattern as
// internal/environment/docker_test.go's fakeDockerClient, one level up the
// stack.
type fakeEnvironment struct {
	createFn  func(ctx context.Context, spec environment.ContainerSpec) (environment.ContainerState, error)
	startFn   func(ctx context.Context, serverID string) (environment.ContainerState, error)
	stopFn    func(ctx context.Context, serverID string, grace time.Duration) (environment.ContainerState, error)
	killFn    func(ctx context.Context, serverID string) (environment.ContainerState, error)
	restartFn func(ctx context.Context, serverID string, grace time.Duration) (environment.ContainerState, error)
	removeFn  func(ctx context.Context, serverID string) error
	inspectFn func(ctx context.Context, serverID string) (environment.ContainerState, error)
	statsFn   func(ctx context.Context, serverID string) (environment.StatsSnapshot, error)
	attachFn  func(ctx context.Context, serverID string) (environment.ConsoleStream, error)
}

func (f *fakeEnvironment) Create(ctx context.Context, spec environment.ContainerSpec) (environment.ContainerState, error) {
	if f.createFn != nil {
		return f.createFn(ctx, spec)
	}
	return environment.ContainerState{}, nil
}
func (f *fakeEnvironment) Start(ctx context.Context, serverID string) (environment.ContainerState, error) {
	return f.startFn(ctx, serverID)
}
func (f *fakeEnvironment) Stop(ctx context.Context, serverID string, grace time.Duration) (environment.ContainerState, error) {
	return f.stopFn(ctx, serverID, grace)
}
func (f *fakeEnvironment) Kill(ctx context.Context, serverID string) (environment.ContainerState, error) {
	return f.killFn(ctx, serverID)
}
func (f *fakeEnvironment) Restart(ctx context.Context, serverID string, grace time.Duration) (environment.ContainerState, error) {
	return f.restartFn(ctx, serverID, grace)
}
func (f *fakeEnvironment) Remove(ctx context.Context, serverID string) error {
	if f.removeFn != nil {
		return f.removeFn(ctx, serverID)
	}
	return nil
}
func (f *fakeEnvironment) Inspect(ctx context.Context, serverID string) (environment.ContainerState, error) {
	return f.inspectFn(ctx, serverID)
}
func (f *fakeEnvironment) Stats(ctx context.Context, serverID string) (environment.StatsSnapshot, error) {
	return f.statsFn(ctx, serverID)
}
func (f *fakeEnvironment) Attach(ctx context.Context, serverID string) (environment.ConsoleStream, error) {
	return f.attachFn(ctx, serverID)
}

// fakeConsoleStream backs Attach with an in-memory pipe, same technique as
// internal/console/hub_test.go's fakeStream.
type fakeConsoleStream struct {
	pr      *io.PipeReader
	pw      *io.PipeWriter
	mu      sync.Mutex
	written bytes.Buffer
}

func newFakeConsoleStream() *fakeConsoleStream {
	pr, pw := io.Pipe()
	return &fakeConsoleStream{pr: pr, pw: pw}
}
func (f *fakeConsoleStream) Read(p []byte) (int, error) { return f.pr.Read(p) }
func (f *fakeConsoleStream) Write(p []byte) (int, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.written.Write(p)
}
func (f *fakeConsoleStream) Close() error {
	f.pw.CloseWithError(io.EOF)
	return f.pr.Close()
}

func testIssuer(t *testing.T) *auth.Issuer {
	t.Helper()
	issuer, err := auth.NewIssuer(testSecret)
	if err != nil {
		t.Fatalf("unexpected error constructing issuer: %v", err)
	}
	return issuer
}

func newTestServer(t *testing.T, env environment.Environment) (*Server, *auth.Issuer) {
	t.Helper()
	issuer := testIssuer(t)
	return NewServer(env, issuer, slog.New(slog.NewTextHandler(io.Discard, nil))), issuer
}

// --------------------------------------------------------------------------
// Auth middleware
// --------------------------------------------------------------------------

func TestHealthzRequiresNoAuth(t *testing.T) {
	server, _ := newTestServer(t, &fakeEnvironment{})
	req := httptest.NewRequest(http.MethodGet, "/healthz", nil)
	rec := httptest.NewRecorder()
	server.ServeHTTP(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", rec.Code)
	}
}

func TestProtectedRouteRejectsMissingAuthHeader(t *testing.T) {
	server, _ := newTestServer(t, &fakeEnvironment{})
	req := httptest.NewRequest(http.MethodGet, "/v1/servers/srv-1/state", nil)
	rec := httptest.NewRecorder()
	server.ServeHTTP(rec, req)

	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("expected 401, got %d", rec.Code)
	}
}

func TestProtectedRouteRejectsInvalidToken(t *testing.T) {
	server, _ := newTestServer(t, &fakeEnvironment{})
	req := httptest.NewRequest(http.MethodGet, "/v1/servers/srv-1/state", nil)
	req.Header.Set("Authorization", "Bearer garbage-token")
	rec := httptest.NewRecorder()
	server.ServeHTTP(rec, req)

	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("expected 401, got %d", rec.Code)
	}
}

func TestProtectedRouteAcceptsValidToken(t *testing.T) {
	env := &fakeEnvironment{
		inspectFn: func(ctx context.Context, serverID string) (environment.ContainerState, error) {
			return environment.ContainerState{ServerID: serverID, Status: environment.StatusRunning}, nil
		},
	}
	server, issuer := newTestServer(t, env)
	token, _ := issuer.IssueNodeToken("node-1", time.Hour)

	req := httptest.NewRequest(http.MethodGet, "/v1/servers/srv-1/state", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	server.ServeHTTP(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d: %s", rec.Code, rec.Body.String())
	}
	if !strings.Contains(rec.Body.String(), "running") {
		t.Fatalf("expected response to include running status, got %s", rec.Body.String())
	}
}

// --------------------------------------------------------------------------
// Lifecycle handlers
// --------------------------------------------------------------------------

func TestHandleStartDelegatesToEnvironment(t *testing.T) {
	var gotServerID string
	env := &fakeEnvironment{
		startFn: func(ctx context.Context, serverID string) (environment.ContainerState, error) {
			gotServerID = serverID
			return environment.ContainerState{ServerID: serverID, Status: environment.StatusRunning}, nil
		},
	}
	server, issuer := newTestServer(t, env)
	token, _ := issuer.IssueNodeToken("node-1", time.Hour)

	req := httptest.NewRequest(http.MethodPost, "/v1/servers/srv-42/start", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	server.ServeHTTP(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", rec.Code)
	}
	if gotServerID != "srv-42" {
		t.Fatalf("expected server ID 'srv-42' extracted from path, got %q", gotServerID)
	}
}

func TestHandleStopPassesGracePeriodFromBody(t *testing.T) {
	var gotGrace time.Duration
	env := &fakeEnvironment{
		stopFn: func(ctx context.Context, serverID string, grace time.Duration) (environment.ContainerState, error) {
			gotGrace = grace
			return environment.ContainerState{ServerID: serverID, Status: environment.StatusStopped}, nil
		},
	}
	server, issuer := newTestServer(t, env)
	token, _ := issuer.IssueNodeToken("node-1", time.Hour)

	req := httptest.NewRequest(http.MethodPost, "/v1/servers/srv-1/stop", strings.NewReader(`{"grace_period_seconds": 15}`))
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	server.ServeHTTP(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d: %s", rec.Code, rec.Body.String())
	}
	if gotGrace != 15*time.Second {
		t.Fatalf("expected a 15s grace period from the request body, got %v", gotGrace)
	}
}

func TestHandleStopUsesDefaultGraceWithoutBody(t *testing.T) {
	var gotGrace time.Duration
	env := &fakeEnvironment{
		stopFn: func(ctx context.Context, serverID string, grace time.Duration) (environment.ContainerState, error) {
			gotGrace = grace
			return environment.ContainerState{}, nil
		},
	}
	server, issuer := newTestServer(t, env)
	token, _ := issuer.IssueNodeToken("node-1", time.Hour)

	req := httptest.NewRequest(http.MethodPost, "/v1/servers/srv-1/stop", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	server.ServeHTTP(rec, req)

	if gotGrace != defaultGracePeriod {
		t.Fatalf("expected default grace period %v, got %v", defaultGracePeriod, gotGrace)
	}
}

func TestHandleStateReturns404WhenEnvironmentErrors(t *testing.T) {
	env := &fakeEnvironment{
		inspectFn: func(ctx context.Context, serverID string) (environment.ContainerState, error) {
			return environment.ContainerState{}, errFakeNotFound{}
		},
	}
	server, issuer := newTestServer(t, env)
	token, _ := issuer.IssueNodeToken("node-1", time.Hour)

	req := httptest.NewRequest(http.MethodGet, "/v1/servers/srv-missing/state", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	server.ServeHTTP(rec, req)

	if rec.Code != http.StatusNotFound {
		t.Fatalf("expected 404, got %d", rec.Code)
	}
}

type errFakeNotFound struct{}

func (errFakeNotFound) Error() string { return "not found" }

func TestHandleCreateBuildsSpecFromRequestBody(t *testing.T) {
	var gotSpec environment.ContainerSpec
	env := &fakeEnvironment{
		createFn: func(ctx context.Context, spec environment.ContainerSpec) (environment.ContainerState, error) {
			gotSpec = spec
			return environment.ContainerState{ServerID: spec.ServerID, Status: environment.StatusCreated}, nil
		},
	}
	server, issuer := newTestServer(t, env)
	token, _ := issuer.IssueNodeToken("node-1", time.Hour)

	body := `{
		"image": "itzg/minecraft-server:java21",
		"command": ["start"],
		"env": {"EULA": "TRUE"},
		"working_dir": "/srv/umbrella/srv-1",
		"memory_bytes": 2147483648,
		"cpu_cores": 1.5,
		"port_bindings": [{"container_port": 25565, "host_port": 30001, "protocol": "tcp"}]
	}`
	req := httptest.NewRequest(http.MethodPost, "/v1/servers/srv-1", strings.NewReader(body))
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	server.ServeHTTP(rec, req)

	if rec.Code != http.StatusCreated {
		t.Fatalf("expected 201, got %d: %s", rec.Code, rec.Body.String())
	}
	if gotSpec.ServerID != "srv-1" {
		t.Fatalf("expected ServerID from path 'srv-1', got %q", gotSpec.ServerID)
	}
	if gotSpec.Image != "itzg/minecraft-server:java21" {
		t.Fatalf("expected image from body, got %q", gotSpec.Image)
	}
	if gotSpec.Env["EULA"] != "TRUE" {
		t.Fatalf("expected env EULA=TRUE, got %v", gotSpec.Env)
	}
	if gotSpec.Limits.MemoryBytes != 2147483648 {
		t.Fatalf("expected memory limit from body, got %d", gotSpec.Limits.MemoryBytes)
	}
	if len(gotSpec.PortBindings) != 1 || gotSpec.PortBindings[0].HostPort != 30001 {
		t.Fatalf("expected port binding from body, got %v", gotSpec.PortBindings)
	}
}

func TestHandleCreateRejectsMissingImage(t *testing.T) {
	server, issuer := newTestServer(t, &fakeEnvironment{})
	token, _ := issuer.IssueNodeToken("node-1", time.Hour)

	req := httptest.NewRequest(http.MethodPost, "/v1/servers/srv-1", strings.NewReader(`{"working_dir": "/srv/x"}`))
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	server.ServeHTTP(rec, req)

	if rec.Code != http.StatusBadRequest {
		t.Fatalf("expected 400 for missing image, got %d", rec.Code)
	}
}

func TestHandleCreateRejectsInvalidJSON(t *testing.T) {
	server, issuer := newTestServer(t, &fakeEnvironment{})
	token, _ := issuer.IssueNodeToken("node-1", time.Hour)

	req := httptest.NewRequest(http.MethodPost, "/v1/servers/srv-1", strings.NewReader(`not json`))
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	server.ServeHTTP(rec, req)

	if rec.Code != http.StatusBadRequest {
		t.Fatalf("expected 400 for invalid JSON body, got %d", rec.Code)
	}
}

func TestHandleRemoveDelegatesToEnvironment(t *testing.T) {
	var gotServerID string
	env := &fakeEnvironment{
		removeFn: func(ctx context.Context, serverID string) error {
			gotServerID = serverID
			return nil
		},
	}
	server, issuer := newTestServer(t, env)
	token, _ := issuer.IssueNodeToken("node-1", time.Hour)

	req := httptest.NewRequest(http.MethodDelete, "/v1/servers/srv-1", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	server.ServeHTTP(rec, req)

	if rec.Code != http.StatusNoContent {
		t.Fatalf("expected 204, got %d", rec.Code)
	}
	if gotServerID != "srv-1" {
		t.Fatalf("expected server ID 'srv-1', got %q", gotServerID)
	}
}

func TestHandleRemoveRequiresAuth(t *testing.T) {
	server, _ := newTestServer(t, &fakeEnvironment{})
	req := httptest.NewRequest(http.MethodDelete, "/v1/servers/srv-1", nil)
	rec := httptest.NewRecorder()
	server.ServeHTTP(rec, req)

	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("expected 401, got %d", rec.Code)
	}
}

// --------------------------------------------------------------------------
// Console WebSocket
// --------------------------------------------------------------------------

func TestConsoleWebSocketRoundTrip(t *testing.T) {
	stream := newFakeConsoleStream()
	env := &fakeEnvironment{
		attachFn: func(ctx context.Context, serverID string) (environment.ConsoleStream, error) {
			return stream, nil
		},
	}
	server, issuer := newTestServer(t, env)
	token, _ := issuer.IssueNodeToken("node-1", time.Hour)

	httpServer := httptest.NewServer(server)
	defer httpServer.Close()

	wsURL := "ws" + strings.TrimPrefix(httpServer.URL, "http") + "/v1/servers/srv-1/console"
	header := http.Header{}
	header.Set("Authorization", "Bearer "+token)

	conn, resp, err := websocket.DefaultDialer.Dial(wsURL, header)
	if err != nil {
		t.Fatalf("unexpected error dialing websocket: %v", err)
	}
	defer conn.Close()
	if resp.StatusCode != http.StatusSwitchingProtocols {
		t.Fatalf("expected 101 Switching Protocols, got %d", resp.StatusCode)
	}

	// Container "outputs" something; client should receive it broadcast.
	stream.pw.Write([]byte("server started"))

	conn.SetReadDeadline(time.Now().Add(2 * time.Second))
	_, msg, err := conn.ReadMessage()
	if err != nil {
		t.Fatalf("unexpected error reading from websocket: %v", err)
	}
	if string(msg) != "server started" {
		t.Fatalf("expected %q, got %q", "server started", msg)
	}

	// Client sends a command; it should reach the container's stdin.
	if err := conn.WriteMessage(websocket.BinaryMessage, []byte("say hello\n")); err != nil {
		t.Fatalf("unexpected error writing to websocket: %v", err)
	}
	time.Sleep(50 * time.Millisecond) // allow the daemon's reader loop to process it

	stream.mu.Lock()
	written := stream.written.String()
	stream.mu.Unlock()
	if written != "say hello\n" {
		t.Fatalf("expected stdin to receive %q, got %q", "say hello\n", written)
	}
}

func TestConsoleWebSocketRejectsMissingAuth(t *testing.T) {
	env := &fakeEnvironment{
		attachFn: func(ctx context.Context, serverID string) (environment.ConsoleStream, error) {
			return newFakeConsoleStream(), nil
		},
	}
	server, _ := newTestServer(t, env)
	httpServer := httptest.NewServer(server)
	defer httpServer.Close()

	wsURL := "ws" + strings.TrimPrefix(httpServer.URL, "http") + "/v1/servers/srv-1/console"
	_, resp, err := websocket.DefaultDialer.Dial(wsURL, nil)
	if err == nil {
		t.Fatal("expected the dial to fail without an Authorization header")
	}
	if resp == nil || resp.StatusCode != http.StatusUnauthorized {
		status := 0
		if resp != nil {
			status = resp.StatusCode
		}
		t.Fatalf("expected 401, got %d", status)
	}
}
