module umbrella-daemon

go 1.22.2

require (
	github.com/distribution/reference v0.5.0 // indirect
	github.com/docker/distribution v2.8.2+incompatible // indirect
	github.com/docker/docker v24.0.9+incompatible
	github.com/docker/go-connections v0.5.0
	github.com/docker/go-units v0.5.0 // indirect
	github.com/gogo/protobuf v1.2.1 // indirect
	github.com/golang-jwt/jwt/v5 v5.2.1
	github.com/gorilla/websocket v1.5.3
	github.com/opencontainers/go-digest v1.0.0 // indirect
	github.com/opencontainers/image-spec v1.1.1
	github.com/pkg/errors v0.9.1 // indirect
)

replace golang.org/x/tools => github.com/golang/tools v0.1.12

replace golang.org/x/mod => github.com/golang/mod v0.8.0

replace golang.org/x/net => github.com/golang/net v0.17.0

replace golang.org/x/sys => github.com/golang/sys v0.13.0

replace golang.org/x/text => github.com/golang/text v0.13.0

replace golang.org/x/crypto => github.com/golang/crypto v0.14.0

replace golang.org/x/sync => github.com/golang/sync v0.4.0

replace golang.org/x/term => github.com/golang/term v0.13.0

replace golang.org/x/exp => github.com/golang/exp v0.0.0-20231006140011-7918f672742d
