package main

import (
	"fmt"
	"os"
)

// config is umbrella-daemon's runtime configuration, loaded entirely from
// environment variables — matching how the rest of UmbrellaOS's services
// (umbrella-core's config/settings.py) are configured, and keeping the
// daemon container-friendly (no config file to bind-mount for the common
// case).
type config struct {
	// ListenAddr is where the daemon's HTTP/WS API listens.
	ListenAddr string

	// NodeSigningSecret is the shared secret this node was registered with
	// — used to verify node tokens umbrella-core presents on every
	// request. Exchanged once, out-of-band, at registration time (see
	// docs/adr/0002); never transmitted on a per-request basis.
	NodeSigningSecret string

	// BackupDir is where this node stores backup archives — one
	// subdirectory per server, one file per backup. Phase 4.
	BackupDir string
}

func loadConfig() (config, error) {
	secret := os.Getenv("UMBRELLA_NODE_SIGNING_SECRET")
	if secret == "" {
		return config{}, fmt.Errorf("UMBRELLA_NODE_SIGNING_SECRET must be set")
	}

	addr := os.Getenv("UMBRELLA_DAEMON_LISTEN_ADDR")
	if addr == "" {
		addr = ":8443"
	}

	backupDir := os.Getenv("UMBRELLA_BACKUP_DIR")
	if backupDir == "" {
		backupDir = "/var/lib/umbrella/backups"
	}

	return config{
		ListenAddr:        addr,
		NodeSigningSecret: secret,
		BackupDir:         backupDir,
	}, nil
}
