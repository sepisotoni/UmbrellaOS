package main

import "testing"

func TestLoadConfigFailsWithoutSigningSecret(t *testing.T) {
	t.Setenv("UMBRELLA_NODE_SIGNING_SECRET", "")
	t.Setenv("UMBRELLA_DAEMON_LISTEN_ADDR", "")

	_, err := loadConfig()
	if err == nil {
		t.Fatal("expected an error when UMBRELLA_NODE_SIGNING_SECRET is unset")
	}
}

func TestLoadConfigUsesDefaultListenAddr(t *testing.T) {
	t.Setenv("UMBRELLA_NODE_SIGNING_SECRET", "a-signing-secret-at-least-32-bytes-long")
	t.Setenv("UMBRELLA_DAEMON_LISTEN_ADDR", "")
	t.Setenv("UMBRELLA_BACKUP_DIR", "")

	cfg, err := loadConfig()
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if cfg.ListenAddr != ":8443" {
		t.Fatalf("expected default listen addr ':8443', got %q", cfg.ListenAddr)
	}
	if cfg.BackupDir != "/var/lib/umbrella/backups" {
		t.Fatalf("expected default backup dir, got %q", cfg.BackupDir)
	}
}

func TestLoadConfigRespectsExplicitListenAddr(t *testing.T) {
	t.Setenv("UMBRELLA_NODE_SIGNING_SECRET", "a-signing-secret-at-least-32-bytes-long")
	t.Setenv("UMBRELLA_DAEMON_LISTEN_ADDR", ":9999")

	cfg, err := loadConfig()
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if cfg.ListenAddr != ":9999" {
		t.Fatalf("expected explicit listen addr ':9999', got %q", cfg.ListenAddr)
	}
}
