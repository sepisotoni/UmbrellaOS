// Command umbrella-daemon is the per-node agent: it owns Docker container
// lifecycle for the Minecraft servers scheduled onto this host, and
// exposes that control (plus console streaming and live stats) to
// umbrella-core over the authenticated HTTP/WS API in internal/transport.
package main

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/docker/docker/client"

	"umbrella-daemon/internal/auth"
	"umbrella-daemon/internal/environment"
	"umbrella-daemon/internal/transport"
)

func main() {
	logger := slog.New(slog.NewJSONHandler(os.Stdout, nil))

	cfg, err := loadConfig()
	if err != nil {
		logger.Error("invalid configuration", "error", err)
		os.Exit(1)
	}

	dockerCli, err := client.NewClientWithOpts(
		client.FromEnv,
		client.WithAPIVersionNegotiation(),
	)
	if err != nil {
		logger.Error("failed to construct Docker client", "error", err)
		os.Exit(1)
	}

	issuer, err := auth.NewIssuer(cfg.NodeSigningSecret)
	if err != nil {
		logger.Error("invalid node signing secret", "error", err)
		os.Exit(1)
	}

	env := environment.NewDockerEnvironment(dockerCli)
	server := transport.NewServer(env, issuer, logger, cfg.BackupDir)

	httpServer := &http.Server{
		Addr:              cfg.ListenAddr,
		Handler:           server,
		ReadHeaderTimeout: 10 * time.Second,
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	go func() {
		logger.Info("umbrella-daemon listening", "addr", cfg.ListenAddr)
		if err := httpServer.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			logger.Error("http server failed", "error", err)
			stop()
		}
	}()

	<-ctx.Done()
	logger.Info("shutting down umbrella-daemon")

	shutdownCtx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	if err := httpServer.Shutdown(shutdownCtx); err != nil {
		logger.Error("error during graceful shutdown", "error", err)
		os.Exit(1)
	}
}
