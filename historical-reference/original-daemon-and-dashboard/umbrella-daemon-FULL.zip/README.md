# umbrella-daemon

The per-node agent: owns Docker container lifecycle for the Minecraft servers scheduled onto this
host, and exposes control, console streaming, and live stats to `umbrella-core` over an authenticated
HTTP/WebSocket API. See `docs/adr/0002-daemon-environment-abstraction.md` for the design rationale.

## Package layout

```
cmd/daemon/                 Entrypoint: config loading, wiring, graceful shutdown
internal/environment/       Environment interface + the Docker implementation
internal/console/           Fan-out console I/O hub (one per running server)
internal/ringbuffer/        Bounded byte buffer backing console scrollback
internal/stats/             Pure CPU%/memory/network calculations from raw stats
internal/crash/             Exit-state classification (clean stop vs. crash, and why)
internal/auth/              Signed node-token issuance/verification (JWT)
internal/transport/         The HTTP/WS API surface itself
```

## Running it

```bash
export UMBRELLA_NODE_SIGNING_SECRET="<at least 32 bytes, shared with umbrella-core at registration>"
export UMBRELLA_DAEMON_LISTEN_ADDR=":8443"  # optional, defaults to :8443
go run ./cmd/daemon
```

Requires a reachable Docker daemon (`DOCKER_HOST`, or the default `/var/run/docker.sock`).

## API surface

All routes except `/healthz` require `Authorization: Bearer <node-token>`.

| Method | Path | Purpose |
|---|---|---|
| GET | `/healthz` | Liveness, unauthenticated |
| POST | `/v1/servers/{id}/start` | Start a previously-created container |
| POST | `/v1/servers/{id}/stop` | Graceful stop; body `{"grace_period_seconds": N}` optional |
| POST | `/v1/servers/{id}/kill` | Hard SIGKILL, no grace period |
| POST | `/v1/servers/{id}/restart` | Stop then start as one operation |
| GET | `/v1/servers/{id}/state` | Current lifecycle state |
| GET | `/v1/servers/{id}/stats` | One CPU/memory/network snapshot |
| GET (WS) | `/v1/servers/{id}/console` | Bidirectional console stream; sends scrollback on connect |

`Create` and `Remove` are on the `Environment` interface (see `internal/environment/environment.go`)
but not yet exposed over HTTP — Phase 2's hosting control plane is what actually calls `Create` (with
a fully-specified `ContainerSpec` built from a server template/allocation), so that route lands
alongside that phase rather than being guessed at here.

## Testing

```bash
go test ./...              # unit tests — no external dependencies required
go test ./... -race        # same, with the race detector (recommended; console/ringbuffer are
                            # concurrency-sensitive and are tested under -race deliberately)
go test ./... -run TestIntegration -v   # Docker integration tests — skip automatically without
                                          # a reachable Docker daemon; run for real coverage of
                                          # internal/environment against actual Docker behavior
```

76 unit/integration tests as of Phase 1, all passing; the two `TestIntegration_*` tests in
`internal/environment/docker_integration_test.go` require and exercise a genuine Docker daemon and
will skip (not fail, not fake a pass) wherever one isn't reachable.

## What Phase 1 deliberately does not include

- **`Create`/`Remove` HTTP routes** — arrive with Phase 2, once there's a real `ContainerSpec` source
  (the hosting control plane's templates/allocations) to build them from.
- **Network bandwidth limits and disk quota enforcement** — represented in `ResourceLimits` but not
  enforced by the Docker driver; see ADR-0002's trade-offs section for why, honestly, rather than
  faked with a no-op.
- **A non-Docker `Environment` implementation** — the interface is designed for one to be additive
  later; none is built speculatively now.
- **Kubernetes-style clustering/scheduling across nodes** — Phase 9's concern; this daemon governs one
  host.
