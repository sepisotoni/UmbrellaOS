# Phase 1 — umbrella-daemon: Daemon Core & Environment Abstraction

New component: `umbrella-daemon`, a Go service (this is the first phase to produce non-Python code —
see ADR-0002 for why Go specifically, carried over from the master roadmap's original reasoning).

## What exists now

```
cmd/daemon/main.go            Entrypoint: config, wiring, graceful shutdown on SIGINT/SIGTERM
cmd/daemon/config.go          Env-var configuration loading

internal/environment/
  environment.go               Environment interface + domain types (ContainerSpec, ContainerState,
                                ResourceLimits, StatsSnapshot) — runtime-agnostic
  docker.go                    The Docker implementation: create/start/stop/kill/restart/remove/
                                inspect/stats/attach, spec translation, state mapping

internal/console/
  hub.go                       Fan-out console I/O: one Hub per running server, N subscribers,
                                bounded per-subscriber buffering (drops, doesn't block, on a slow client)

internal/ringbuffer/
  ringbuffer.go                Thread-safe bounded byte buffer backing console scrollback

internal/stats/
  calculator.go                Pure CPU%/memory/network calculations from raw Docker stats shape

internal/crash/
  detector.go                  Exit-state classification: clean stop vs. OOM-killed vs. killed-by-
                                signal vs. non-zero-exit vs. unrequested-zero-exit (treated as a crash)

internal/auth/
  node_token.go                Signed (HMAC/JWT), short-lived, scoped node tokens — replaces a shared
                                static secret on every request with a secret exchanged once at
                                registration

internal/transport/
  ws_server.go                 The daemon's HTTP/WS API: lifecycle routes, stats, and a bidirectional
                                console WebSocket with scrollback replay on connect

docs/adr/0002-daemon-environment-abstraction.md   Architecture decision record for this phase
README.md                                          Developer guide: running, API surface, testing
```

## Verification performed

- **76 tests, 0 failures**, run with `-race` across all 8 packages.
- Every package that doesn't require a live Docker daemon is tested for real: the ring buffer under
  concurrent writers, the console hub's fan-out/broadcast/backpressure behavior against a real
  `io.Pipe`-backed fake stream, the stats calculator against realistic sample values (including the
  cgroup v1 vs. v2 cache-accounting difference), the crash classifier against every branch, node-token
  issuance/verification including an `alg: none` bypass regression test, and the HTTP/WS transport
  layer including a genuine WebSocket round-trip test.
- **Docker-dependent logic is tested twice, honestly**: `docker_test.go` proves `DockerEnvironment`'s
  own logic (spec translation, state mapping, error handling) against a fake client;
  `docker_integration_test.go` proves the same logic against a *real* Docker daemon, and correctly
  skips (not fakes a pass) in any environment without one reachable — including the sandbox this phase
  was authored in. Confirmed the skip path actually fires rather than assumed.
- **The compiled binary was actually run**, not just unit-tested: started with a real config, hit
  `/healthz` (200), hit an unauthenticated protected route (401 as expected), and shut down cleanly on
  SIGTERM.

## Two real mistakes caught and fixed during this phase, not glossed over

1. First draft of `toHostConfig`'s port-binding translation was a no-op stub that silently discarded
   port bindings entirely — caught before it shipped by reviewing the diff, not by a test (there was
   no test yet), and fixed with a real `nat.PortMap`-based implementation, now covered by
   `TestToHostConfigAppliesPortBindings`.
2. A left-over `var _ = strings.TrimSpace` "reserved for later" placeholder trick (used to silence an
   unused-import error while a helper function was still half-written) — removed along with the
   unused import once the surrounding code was actually finished, rather than shipped as a marker for
   future work.

## Known follow-ups (explicitly not built now)

- `Create`/`Remove` aren't exposed over HTTP yet — they need a real `ContainerSpec` source, which is
  Phase 2's hosting control plane (templates + allocations), not something to guess the shape of here.
- `ResourceLimits.NetworkBpsLimit` and `.DiskBytes` are modeled but not enforced by the Docker driver —
  documented honestly in ADR-0002 rather than faked.
- No non-Docker `Environment` implementation — the interface is designed for one to be additive later.
- Per-node registration flow (how a node first obtains its signing secret from `umbrella-core`) is a
  Phase 2 concern — Phase 1 assumes the secret is already configured.

## Environment note

Building this phase required working around this sandbox's network allowlist (only `github.com` and a
handful of package registries, not `golang.org` or `proxy.golang.org`). Used `GOPROXY=direct` plus
`replace` directives redirecting `golang.org/x/*` to their `github.com/golang/*` mirrors — documented
in `go.mod` itself via the `replace` block. This is a sandbox-specific workaround; a normal CI/dev
environment with unrestricted network access wouldn't need it, but it's left in `go.mod` since it's
harmless there too (the replace targets are the canonical mirrors, not forks).
