# ADR-0002: umbrella-daemon's Environment abstraction and node authentication

**Status:** Accepted, implemented (Phase 1).

## Context

Phase 1 needed a per-node agent that owns Docker container lifecycle, console streaming, and stats
for the Minecraft servers scheduled onto a host, and exposes that control to `umbrella-core` over an
authenticated channel. The ecosystem architecture discussion committed to keeping the daemon's runtime
pluggable (Docker today, potentially a different driver later) without adopting Kubernetes now, and to
"no shared static secrets between daemon and core."

## Decision

**Runtime abstraction.** Every daemon package (`internal/console`, `internal/transport`,
`internal/crash`) depends on the `environment.Environment` interface (`internal/environment/environment.go`),
never on Docker types directly. `internal/environment/docker.go` is the one implementation Phase 1
ships. The interface's own `DockerClient` sub-interface (the subset of `*client.Client` the
implementation actually calls) is what makes `docker.go`'s own logic — spec translation, state
mapping, error wrapping — unit-testable against a fake client, with a separate,
honestly-gated integration test suite (`docker_integration_test.go`, tagged to skip when no real
Docker daemon is reachable) proving the same logic against genuine Docker wire behavior.

**Container identity.** Containers are named `umbrella-<serverID>` rather than the daemon persisting
its own serverID-to-Docker-container-ID mapping. The name *is* the mapping, and it survives a daemon
restart for free — there is no local state file to get out of sync with reality.

**Console via TTY.** Containers are created with `Tty: true`. Game server processes are interactive
console applications, not services with meaningfully separate stdout/stderr — a TTY gives a single
combined output stream without Docker's `stdcopy` multiplexing framing, which is what
`internal/console.Hub` expects to read directly. This is the same choice Wings makes, for the
identical reason.

**Docker's own restart policy is disabled** (`RestartPolicy: "no"`). umbrella-daemon's own
`internal/crash` classification and Phase 4's self-healing policy own restart decisions — letting
Docker's restart policy also fire would race with, and hide crash information from, that policy.

**Node authentication: signed, short-lived tokens, not a shared static secret per request.**
`internal/auth` issues HMAC-signed JWTs asserting a node's identity, verified on every request via
`internal/transport`'s auth middleware. The signing secret itself is exchanged once, out-of-band, at
node registration — every subsequent request presents a token derived from it, not the secret. Token
verification explicitly checks the signing algorithm (rejecting the classic "alg: none" bypass) and
the token's scope, not just its signature validity.

**Broadcast semantics favor liveness over delivery guarantees.** `internal/console.Hub` drops chunks
for a subscriber whose buffer is full rather than blocking the read loop or other subscribers. Console
output is a live view; durable history is scrollback (bounded, in-memory, for reattachment) and, in
Phase 9, the log-aggregation pipeline — not this broadcast path.

## Consequences

**What this buys:**
- A future non-Docker `Environment` implementation is additive, not a rewrite — every consumer of the
  interface is already runtime-agnostic.
- The daemon has no shared static secret exposed on the wire on every request, closing the gap Phase
  1's requirements explicitly called out.
- A slow or stalled console client (a dashboard tab left open, a dropped connection not yet detected)
  cannot degrade console streaming for every other client or block the container's own I/O loop.

**Trade-offs accepted, explicitly:**
- `ResourceLimits.NetworkBpsLimit` and `.DiskBytes` are represented in the domain model but not
  enforced by the Docker driver in Phase 1 — Docker has no native per-container bandwidth cap without
  an additional `tc`/`netem` layer, and no first-class disk quota without a quota-capable storage
  driver. This is reported honestly in `environment.go`'s doc comments rather than silently ignored or
  faked with a no-op that looks like enforcement.
- The CLI/daemon integration tests require a real Docker daemon and are skipped in any environment
  without one (including the sandbox this phase was built in) — by design, not as a gap: a fake Docker
  client can prove `DockerEnvironment`'s own logic is internally consistent, but only real Docker wire
  behavior can prove it's actually correct against Docker itself.

## Alternatives considered

- **Kubernetes as the runtime driver**: rejected for the reasons already recorded in the ecosystem
  roadmap discussion — operational overhead unsuited to a self-hosted, one-to-dozens-of-nodes target,
  for processes that are long-lived and stateful rather than horizontally-scaled microservices.
- **A shared static admin secret for daemon-core auth** (mirroring `umbrella-core`'s own
  `X-Admin-Key` bootstrap tier): rejected specifically for node-to-node traffic — a key transmitted on
  every request is a larger blast radius if intercepted than a short-lived, per-issuance token, and
  Phase 1's requirements explicitly ruled this pattern out for the daemon.
