// Package files implements a sandboxed file manager scoped to exactly one
// server's working directory. Every operation takes a path relative to
// that root and is rejected if it would resolve outside it — this is the
// daemon-enforced path jail Phase 1's roadmap entry promised (as opposed
// to a UI-only restriction, which a direct API call could simply bypass).
package files

import (
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

// MaxReadableFileBytes caps how much of a file ReadFile will return in one
// call — large log/world files exist inside a server's working directory,
// and this manager's job is config/small-file editing, not a bulk data
// transfer path (backups, package internal/backup, handle that case with
// streaming, not this API).
const MaxReadableFileBytes = 8 * 1024 * 1024 // 8MB

// Entry describes one file or directory listing result.
type Entry struct {
	Name       string
	IsDir      bool
	SizeBytes  int64
	ModifiedAt time.Time
}

// Manager is scoped to a single, fixed root directory for its entire
// lifetime — there is no method to change the root after construction,
// which is what makes "this Manager can only ever touch this one server's
// files" true for the lifetime of the value, not just at construction time.
type Manager struct {
	root string // absolute, cleaned
}

// NewManager scopes a Manager to root, which must already exist and be a
// directory. Returns an error rather than creating it — a missing working
// directory is the caller's problem to have set up (server creation, see
// umbrella-core's ServerService), not something this manager should paper
// over by silently creating directories at unexpected times.
func NewManager(root string) (*Manager, error) {
	abs, err := filepath.Abs(root)
	if err != nil {
		return nil, fmt.Errorf("files: resolving root %q: %w", root, err)
	}
	info, err := os.Stat(abs)
	if err != nil {
		return nil, fmt.Errorf("files: root %q: %w", root, err)
	}
	if !info.IsDir() {
		return nil, fmt.Errorf("files: root %q is not a directory", root)
	}
	return &Manager{root: filepath.Clean(abs)}, nil
}

// resolve is the security-critical function: it turns a caller-supplied
// relative path into an absolute path guaranteed to be inside m.root, or
// returns an error. Every exported method goes through this — there is no
// other place in this package that builds a filesystem path from a
// relative input.
func (m *Manager) resolve(relPath string) (string, error) {
	if relPath == "" {
		relPath = "."
	}
	if filepath.IsAbs(relPath) {
		return "", fmt.Errorf("files: path must be relative to the server's working directory, got %q", relPath)
	}

	joined := filepath.Join(m.root, relPath)
	cleaned := filepath.Clean(joined)

	if cleaned != m.root && !strings.HasPrefix(cleaned, m.root+string(filepath.Separator)) {
		return "", fmt.Errorf("files: path %q escapes the server's working directory", relPath)
	}

	// A symlink inside the working directory can point anywhere on the
	// host filesystem — resolving one blindly would defeat the prefix
	// check above. If the target already exists, resolve symlinks and
	// re-verify containment. A non-existent target (the common case for
	// WriteFile creating a new file) has nothing to resolve, so this is
	// skipped rather than treated as an error.
	if resolved, err := filepath.EvalSymlinks(cleaned); err == nil {
		if resolved != m.root && !strings.HasPrefix(resolved, m.root+string(filepath.Separator)) {
			return "", fmt.Errorf("files: path %q is a symlink escaping the server's working directory", relPath)
		}
	}

	return cleaned, nil
}

// List returns the contents of the directory at relPath (relative to the
// server's working directory; "" or "." means the root itself).
func (m *Manager) List(relPath string) ([]Entry, error) {
	dir, err := m.resolve(relPath)
	if err != nil {
		return nil, err
	}
	items, err := os.ReadDir(dir)
	if err != nil {
		return nil, fmt.Errorf("files: listing %q: %w", relPath, err)
	}

	entries := make([]Entry, 0, len(items))
	for _, item := range items {
		info, err := item.Info()
		if err != nil {
			continue // a file removed between ReadDir and Info — skip it, don't fail the whole listing
		}
		entries = append(entries, Entry{
			Name:       item.Name(),
			IsDir:      item.IsDir(),
			SizeBytes:  info.Size(),
			ModifiedAt: info.ModTime(),
		})
	}
	sort.Slice(entries, func(i, j int) bool { return entries[i].Name < entries[j].Name })
	return entries, nil
}

// ReadFile returns the contents of the file at relPath, up to
// MaxReadableFileBytes.
func (m *Manager) ReadFile(relPath string) ([]byte, error) {
	path, err := m.resolve(relPath)
	if err != nil {
		return nil, err
	}
	info, err := os.Stat(path)
	if err != nil {
		return nil, fmt.Errorf("files: reading %q: %w", relPath, err)
	}
	if info.IsDir() {
		return nil, fmt.Errorf("files: %q is a directory, not a file", relPath)
	}
	if info.Size() > MaxReadableFileBytes {
		return nil, fmt.Errorf(
			"files: %q is %d bytes, exceeding the %d byte limit for this API",
			relPath, info.Size(), MaxReadableFileBytes,
		)
	}

	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("files: opening %q: %w", relPath, err)
	}
	defer f.Close()

	return io.ReadAll(io.LimitReader(f, MaxReadableFileBytes+1))
}

// WriteFile writes data to relPath, creating parent directories within the
// sandbox as needed. Overwrites an existing file.
func (m *Manager) WriteFile(relPath string, data []byte) error {
	path, err := m.resolve(relPath)
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return fmt.Errorf("files: preparing directory for %q: %w", relPath, err)
	}
	if err := os.WriteFile(path, data, 0o644); err != nil {
		return fmt.Errorf("files: writing %q: %w", relPath, err)
	}
	return nil
}

// Delete removes the file or (non-recursively empty-checked) directory at
// relPath. Refuses to delete the root itself — "delete this server's
// entire working directory" is a server-deletion concern
// (umbrella-core's ServerService.delete_server), not a file-manager
// operation.
func (m *Manager) Delete(relPath string) error {
	path, err := m.resolve(relPath)
	if err != nil {
		return err
	}
	if path == m.root {
		return fmt.Errorf("files: refusing to delete the server's working directory root")
	}
	if err := os.RemoveAll(path); err != nil {
		return fmt.Errorf("files: deleting %q: %w", relPath, err)
	}
	return nil
}

// Mkdir creates a directory (and any missing parents within the sandbox)
// at relPath.
func (m *Manager) Mkdir(relPath string) error {
	path, err := m.resolve(relPath)
	if err != nil {
		return err
	}
	if err := os.MkdirAll(path, 0o755); err != nil {
		return fmt.Errorf("files: creating directory %q: %w", relPath, err)
	}
	return nil
}

// Move renames/moves a file or directory from fromRelPath to toRelPath,
// both resolved and sandbox-checked independently — a move can't be used
// to smuggle a file out of the sandbox via one path being valid and the
// other not checked.
func (m *Manager) Move(fromRelPath, toRelPath string) error {
	from, err := m.resolve(fromRelPath)
	if err != nil {
		return fmt.Errorf("files: source: %w", err)
	}
	to, err := m.resolve(toRelPath)
	if err != nil {
		return fmt.Errorf("files: destination: %w", err)
	}
	if err := os.MkdirAll(filepath.Dir(to), 0o755); err != nil {
		return fmt.Errorf("files: preparing destination directory: %w", err)
	}
	if err := os.Rename(from, to); err != nil {
		return fmt.Errorf("files: moving %q to %q: %w", fromRelPath, toRelPath, err)
	}
	return nil
}

// Root returns the absolute path this manager is scoped to — used by
// internal/backup to know what to archive, not for building paths outside
// this package.
func (m *Manager) Root() string {
	return m.root
}
