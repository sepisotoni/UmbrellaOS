package files

import (
	"os"
	"path/filepath"
	"testing"
)

func newTestManager(t *testing.T) (*Manager, string) {
	t.Helper()
	root := t.TempDir()
	m, err := NewManager(root)
	if err != nil {
		t.Fatalf("unexpected error constructing Manager: %v", err)
	}
	resolvedRoot, _ := filepath.EvalSymlinks(root)
	return m, resolvedRoot
}

func TestNewManagerRejectsMissingRoot(t *testing.T) {
	_, err := NewManager("/does/not/exist/at/all")
	if err == nil {
		t.Fatal("expected an error for a nonexistent root")
	}
}

func TestNewManagerRejectsFileAsRoot(t *testing.T) {
	dir := t.TempDir()
	filePath := filepath.Join(dir, "not-a-dir.txt")
	os.WriteFile(filePath, []byte("x"), 0o644)

	_, err := NewManager(filePath)
	if err == nil {
		t.Fatal("expected an error when root is a file, not a directory")
	}
}

func TestWriteAndReadFileRoundTrip(t *testing.T) {
	m, _ := newTestManager(t)
	if err := m.WriteFile("config.yml", []byte("hello: world")); err != nil {
		t.Fatalf("unexpected error writing file: %v", err)
	}
	got, err := m.ReadFile("config.yml")
	if err != nil {
		t.Fatalf("unexpected error reading file: %v", err)
	}
	if string(got) != "hello: world" {
		t.Fatalf("expected %q, got %q", "hello: world", got)
	}
}

func TestWriteFileCreatesParentDirectories(t *testing.T) {
	m, _ := newTestManager(t)
	if err := m.WriteFile("plugins/config/settings.yml", []byte("x")); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	got, err := m.ReadFile("plugins/config/settings.yml")
	if err != nil || string(got) != "x" {
		t.Fatalf("expected to read back the written file, got %q, err=%v", got, err)
	}
}

func TestListReturnsSortedEntries(t *testing.T) {
	m, _ := newTestManager(t)
	m.WriteFile("b.txt", []byte("b"))
	m.WriteFile("a.txt", []byte("a"))
	m.Mkdir("c-dir")

	entries, err := m.List(".")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(entries) != 3 {
		t.Fatalf("expected 3 entries, got %d", len(entries))
	}
	if entries[0].Name != "a.txt" || entries[1].Name != "b.txt" || entries[2].Name != "c-dir" {
		t.Fatalf("expected sorted order a.txt, b.txt, c-dir, got %v", entries)
	}
	if !entries[2].IsDir {
		t.Fatal("expected c-dir to be reported as a directory")
	}
}

func TestDeleteRemovesFile(t *testing.T) {
	m, _ := newTestManager(t)
	m.WriteFile("temp.txt", []byte("x"))
	if err := m.Delete("temp.txt"); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if _, err := m.ReadFile("temp.txt"); err == nil {
		t.Fatal("expected reading a deleted file to fail")
	}
}

func TestDeleteRefusesToDeleteRoot(t *testing.T) {
	m, _ := newTestManager(t)
	if err := m.Delete("."); err == nil {
		t.Fatal("expected an error attempting to delete the sandbox root itself")
	}
	if err := m.Delete(""); err == nil {
		t.Fatal("expected an error attempting to delete the sandbox root itself (empty path)")
	}
}

func TestMoveRelocatesFile(t *testing.T) {
	m, _ := newTestManager(t)
	m.WriteFile("old.txt", []byte("content"))
	if err := m.Move("old.txt", "renamed/new.txt"); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	got, err := m.ReadFile("renamed/new.txt")
	if err != nil || string(got) != "content" {
		t.Fatalf("expected moved file to be readable at new path, got %q, err=%v", got, err)
	}
	if _, err := m.ReadFile("old.txt"); err == nil {
		t.Fatal("expected the old path to no longer exist after a move")
	}
}

func TestReadFileRejectsOversizedFile(t *testing.T) {
	m, _ := newTestManager(t)
	big := make([]byte, MaxReadableFileBytes+1)
	m.WriteFile("huge.bin", big)

	_, err := m.ReadFile("huge.bin")
	if err == nil {
		t.Fatal("expected an error reading a file over the size limit")
	}
}

// --------------------------------------------------------------------------
// Security boundary: path traversal and symlink escape
// --------------------------------------------------------------------------

func TestResolveRejectsDotDotTraversal(t *testing.T) {
	m, _ := newTestManager(t)
	_, err := m.ReadFile("../../../../etc/passwd")
	if err == nil {
		t.Fatal("expected a '..' traversal attempt to be rejected")
	}
}

func TestResolveRejectsDotDotTraversalEvenWhenDisguised(t *testing.T) {
	m, _ := newTestManager(t)
	attempts := []string{
		"subdir/../../outside.txt",
		"a/b/../../../outside.txt",
		"./../outside.txt",
	}
	for _, attempt := range attempts {
		if _, err := m.ReadFile(attempt); err == nil {
			t.Fatalf("expected traversal attempt %q to be rejected", attempt)
		}
	}
}

func TestResolveRejectsAbsolutePaths(t *testing.T) {
	m, _ := newTestManager(t)
	_, err := m.ReadFile("/etc/passwd")
	if err == nil {
		t.Fatal("expected an absolute path to be rejected")
	}
}

func TestResolveAllowsRootItself(t *testing.T) {
	m, _ := newTestManager(t)
	m.WriteFile("file.txt", []byte("x"))
	entries, err := m.List("")
	if err != nil {
		t.Fatalf("unexpected error listing root via empty string: %v", err)
	}
	if len(entries) != 1 {
		t.Fatalf("expected 1 entry, got %d", len(entries))
	}

	entries, err = m.List(".")
	if err != nil {
		t.Fatalf("unexpected error listing root via '.': %v", err)
	}
	if len(entries) != 1 {
		t.Fatalf("expected 1 entry, got %d", len(entries))
	}
}

func TestResolveRejectsSymlinkEscapingSandbox(t *testing.T) {
	m, root := newTestManager(t)

	outsideDir := t.TempDir()
	secretFile := filepath.Join(outsideDir, "secret.txt")
	os.WriteFile(secretFile, []byte("outside secret"), 0o644)

	symlinkPath := filepath.Join(root, "escape-link")
	if err := os.Symlink(outsideDir, symlinkPath); err != nil {
		t.Skipf("symlinks not supported in this test environment: %v", err)
	}

	_, err := m.ReadFile("escape-link/secret.txt")
	if err == nil {
		t.Fatal("expected reading through a symlink escaping the sandbox to be rejected")
	}
}

func TestMoveChecksBothSourceAndDestinationIndependently(t *testing.T) {
	m, _ := newTestManager(t)
	m.WriteFile("legit.txt", []byte("x"))

	// A valid source must not let an invalid (escaping) destination through.
	if err := m.Move("legit.txt", "../../../escaped.txt"); err == nil {
		t.Fatal("expected Move to reject an escaping destination even with a valid source")
	}
}
