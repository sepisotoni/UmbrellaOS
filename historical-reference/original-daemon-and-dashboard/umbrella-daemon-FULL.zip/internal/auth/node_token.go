// Package auth issues and verifies the signed tokens umbrella-core and
// umbrella-daemon use to authenticate each other — replacing the shared
// static-secret pattern (a single admin key both sides know) with per-node,
// per-issuance, expiring, scoped tokens, per Phase 1's "no shared static
// secrets between daemon and core" requirement.
package auth

import (
	"errors"
	"fmt"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

// NodeClaims is what a node token asserts about itself. Embedding
// jwt.RegisteredClaims gives us standard exp/iat/nbf handling for free
// rather than reimplementing expiry checks by hand.
type NodeClaims struct {
	NodeID string `json:"node_id"`
	// Scope is deliberately a single value in Phase 1 ("node") rather than
	// a list of fine-grained scopes — there is exactly one kind of
	// node-to-core and core-to-node interaction right now (control-plane
	// commands and stats/console streaming). A richer scope model is worth
	// introducing when there's a second, genuinely different capability to
	// distinguish, not speculatively now.
	Scope string `json:"scope"`
	jwt.RegisteredClaims
}

// Issuer signs and verifies node tokens using a single HMAC secret shared
// only between umbrella-core and this daemon's registration process — the
// secret itself is exchanged once, out-of-band, at node registration time
// (an operator pastes it into the daemon's config), and every subsequent
// token is a short-lived, verifiable credential derived from it, not the
// secret itself passed around on every request.
type Issuer struct {
	secret []byte
}

// NewIssuer builds an Issuer from the shared registration secret. Returns
// an error rather than accepting an empty secret silently — an
// accidentally-empty signing key would make every token trivially forgeable.
func NewIssuer(secret string) (*Issuer, error) {
	if len(secret) < 32 {
		return nil, fmt.Errorf("auth: signing secret must be at least 32 bytes, got %d", len(secret))
	}
	return &Issuer{secret: []byte(secret)}, nil
}

// IssueNodeToken produces a signed token asserting nodeID, valid for ttl.
// Short-lived by design (see docs/adr/0002) — a compromised in-flight
// token is only useful for its remaining lifetime, not indefinitely.
func (i *Issuer) IssueNodeToken(nodeID string, ttl time.Duration) (string, error) {
	if nodeID == "" {
		return "", errors.New("auth: nodeID must not be empty")
	}
	now := time.Now()
	claims := NodeClaims{
		NodeID: nodeID,
		Scope:  "node",
		RegisteredClaims: jwt.RegisteredClaims{
			IssuedAt:  jwt.NewNumericDate(now),
			NotBefore: jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(now.Add(ttl)),
			Issuer:    "umbrella-core",
			Subject:   nodeID,
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString(i.secret)
}

// VerifyNodeToken parses and validates a token, returning its claims if
// valid. Explicitly checks the signing method matches what we issue —
// accepting whatever algorithm a token happens to claim ("alg: none" or an
// asymmetric algorithm confused for HMAC) is a well-known JWT
// vulnerability class, not a hypothetical concern.
func (i *Issuer) VerifyNodeToken(tokenString string) (*NodeClaims, error) {
	claims := &NodeClaims{}
	token, err := jwt.ParseWithClaims(tokenString, claims, func(t *jwt.Token) (interface{}, error) {
		if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("auth: unexpected signing method %v", t.Header["alg"])
		}
		return i.secret, nil
	})
	if err != nil {
		return nil, fmt.Errorf("auth: token invalid: %w", err)
	}
	if !token.Valid {
		return nil, errors.New("auth: token failed validation")
	}
	if claims.Scope != "node" {
		return nil, fmt.Errorf("auth: unexpected token scope %q", claims.Scope)
	}
	return claims, nil
}
