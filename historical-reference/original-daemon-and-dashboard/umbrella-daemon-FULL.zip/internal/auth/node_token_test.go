package auth

import (
	"strings"
	"testing"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

const testSecret = "this-is-a-test-secret-at-least-32-bytes-long"

// jwtFutureDate returns a NumericDate an hour from now, for hand-built test
// claims that need a valid (non-expired) expiry.
func jwtFutureDate() *jwt.NumericDate {
	return jwt.NewNumericDate(time.Now().Add(time.Hour))
}

// signRawClaims signs arbitrary NodeClaims directly, bypassing
// Issuer.IssueNodeToken's own field-population — used only to construct
// test tokens with claim combinations IssueNodeToken itself would never
// produce (e.g. a bad scope), so VerifyNodeToken's own checks can be
// exercised independently of IssueNodeToken's correctness.
func signRawClaims(issuer *Issuer, claims NodeClaims) (string, error) {
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString(issuer.secret)
}

func TestNewIssuerRejectsShortSecret(t *testing.T) {
	_, err := NewIssuer("too-short")
	if err == nil {
		t.Fatal("expected an error for a secret under 32 bytes, got none")
	}
}

func TestIssueAndVerifyRoundTrip(t *testing.T) {
	issuer, err := NewIssuer(testSecret)
	if err != nil {
		t.Fatalf("unexpected error constructing issuer: %v", err)
	}

	token, err := issuer.IssueNodeToken("node-abc", time.Hour)
	if err != nil {
		t.Fatalf("unexpected error issuing token: %v", err)
	}
	if token == "" {
		t.Fatal("expected a non-empty token")
	}

	claims, err := issuer.VerifyNodeToken(token)
	if err != nil {
		t.Fatalf("unexpected error verifying token: %v", err)
	}
	if claims.NodeID != "node-abc" {
		t.Fatalf("expected NodeID 'node-abc', got %q", claims.NodeID)
	}
	if claims.Scope != "node" {
		t.Fatalf("expected scope 'node', got %q", claims.Scope)
	}
}

func TestIssueNodeTokenRejectsEmptyNodeID(t *testing.T) {
	issuer, _ := NewIssuer(testSecret)
	_, err := issuer.IssueNodeToken("", time.Hour)
	if err == nil {
		t.Fatal("expected an error for an empty nodeID, got none")
	}
}

func TestVerifyExpiredTokenFails(t *testing.T) {
	issuer, _ := NewIssuer(testSecret)
	token, err := issuer.IssueNodeToken("node-abc", -time.Second) // already expired
	if err != nil {
		t.Fatalf("unexpected error issuing token: %v", err)
	}

	_, err = issuer.VerifyNodeToken(token)
	if err == nil {
		t.Fatal("expected an error verifying an expired token, got none")
	}
}

func TestVerifyRejectsTokenSignedWithDifferentSecret(t *testing.T) {
	issuerA, _ := NewIssuer(testSecret)
	issuerB, _ := NewIssuer("a-completely-different-secret-value-1234567")

	token, err := issuerA.IssueNodeToken("node-abc", time.Hour)
	if err != nil {
		t.Fatalf("unexpected error issuing token: %v", err)
	}

	_, err = issuerB.VerifyNodeToken(token)
	if err == nil {
		t.Fatal("expected verification to fail against a token signed with a different secret")
	}
}

func TestVerifyRejectsGarbageToken(t *testing.T) {
	issuer, _ := NewIssuer(testSecret)
	_, err := issuer.VerifyNodeToken("not.a.validtoken")
	if err == nil {
		t.Fatal("expected an error verifying a garbage token string")
	}
}

func TestVerifyRejectsAlgNoneToken(t *testing.T) {
	// Regression test for the classic JWT "alg: none" bypass — a token
	// that claims it needs no signature verification at all must still be
	// rejected outright, not accepted because "there's nothing to check."
	issuer, _ := NewIssuer(testSecret)

	// Handcrafted alg:none token: header {"alg":"none","typ":"JWT"},
	// payload {"node_id":"node-abc","scope":"node"}, empty signature.
	header := "eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0"
	payload := "eyJub2RlX2lkIjoibm9kZS1hYmMiLCJzY29wZSI6Im5vZGUifQ"
	forged := header + "." + payload + "."

	_, err := issuer.VerifyNodeToken(forged)
	if err == nil {
		t.Fatal("expected alg:none token to be rejected")
	}
}

func TestVerifyRejectsWrongScope(t *testing.T) {
	// Constructs a token with the right secret/signing method but a scope
	// other than "node" — must be rejected even though the signature is
	// technically valid, since scope-checking is part of this package's
	// contract, not an afterthought layered on by callers.
	issuer, _ := NewIssuer(testSecret)

	claims := NodeClaims{
		NodeID: "node-abc",
		Scope:  "something-else",
	}
	claims.ExpiresAt = jwtFutureDate()
	tokenString, err := signRawClaims(issuer, claims)
	if err != nil {
		t.Fatalf("unexpected error signing test token: %v", err)
	}

	_, err = issuer.VerifyNodeToken(tokenString)
	if err == nil {
		t.Fatal("expected an error for a token with an unexpected scope")
	}
	if !strings.Contains(err.Error(), "scope") {
		t.Fatalf("expected error to mention scope, got: %v", err)
	}
}
