// Package console multiplexes one container's console I/O to any number of
// subscribers (a dashboard's xterm.js session, the CLI's `logs follow`,
// and — later phases — the Discord console bridge) while retaining
// scrollback for clients that attach mid-session.
//
// This is the "live console streaming" piece of Phase 1's DoD: one
// underlying environment.ConsoleStream per running container, fanned out
// to N readers, with writes (stdin) accepted from any subscriber that has
// permission to send them (permission enforcement itself is the
// Capability Registry's job at the call site that invokes Write, not this
// package's).
package console

import (
	"context"
	"io"
	"sync"

	"umbrella-daemon/internal/environment"
	"umbrella-daemon/internal/ringbuffer"
)

// subscriberBufferSize is how many not-yet-delivered chunks a slow
// subscriber can accumulate before being dropped (see Subscribe). Sized
// generously for console output, which is bursty but not high-throughput.
const subscriberBufferSize = 256

// Hub owns one running container's console stream and fans it out.
type Hub struct {
	stream     environment.ConsoleStream
	scrollback *ringbuffer.Buffer

	mu          sync.Mutex
	subscribers map[int]chan []byte
	nextID      int
	closed      bool
	runErr      error
}

// NewHub wraps a live console stream. scrollbackCapacity controls how many
// bytes of recent output are retained for clients that subscribe after the
// stream has already produced output.
func NewHub(stream environment.ConsoleStream, scrollbackCapacity int) *Hub {
	return &Hub{
		stream:      stream,
		scrollback:  ringbuffer.New(scrollbackCapacity),
		subscribers: make(map[int]chan []byte),
	}
}

// Run reads from the underlying stream until it errors, returns EOF, or ctx
// is cancelled, broadcasting every chunk read to all current subscribers
// and appending it to scrollback. Blocks the calling goroutine — callers
// run this in its own goroutine per container.
func (h *Hub) Run(ctx context.Context) error {
	buf := make([]byte, 32*1024)
	done := make(chan struct{})
	defer close(done)

	// Closing the stream on ctx cancellation unblocks the Read below, since
	// io.Reader has no context-aware variant to select against directly.
	go func() {
		select {
		case <-ctx.Done():
			h.stream.Close()
		case <-done:
		}
	}()

	for {
		n, err := h.stream.Read(buf)
		if n > 0 {
			chunk := make([]byte, n)
			copy(chunk, buf[:n])
			h.scrollback.Write(chunk)
			h.broadcast(chunk)
		}
		if err != nil {
			h.mu.Lock()
			h.closed = true
			if err != io.EOF {
				h.runErr = err
			}
			h.mu.Unlock()
			h.closeAllSubscribers()
			if err == io.EOF {
				return nil
			}
			return err
		}
	}
}

func (h *Hub) broadcast(chunk []byte) {
	h.mu.Lock()
	defer h.mu.Unlock()
	for id, ch := range h.subscribers {
		select {
		case ch <- chunk:
		default:
			// Subscriber is behind and its buffer is full. Dropping this
			// chunk for this one subscriber (not disconnecting it, not
			// blocking every other subscriber and the read loop itself)
			// is a deliberate choice: console output is a live view, not a
			// delivery-guaranteed log — durable history is scrollback (for
			// reattachment) and, in a later phase, the log-aggregation
			// pipeline, not this broadcast path.
			_ = id
		}
	}
}

func (h *Hub) closeAllSubscribers() {
	h.mu.Lock()
	defer h.mu.Unlock()
	for _, ch := range h.subscribers {
		close(ch)
	}
	h.subscribers = make(map[int]chan []byte)
}

// Subscribe registers a new listener and returns a channel of console
// output chunks going forward, plus an unsubscribe function the caller
// must call when done (e.g. when a WebSocket connection closes) to avoid
// leaking the channel and goroutine state.
//
// Does NOT replay scrollback onto the returned channel — callers that want
// history should call Scrollback() once, before subscribing, and render
// both; conflating the two here would require buffering "everything since
// scrollback started" into the channel, defeating the bounded-memory point
// of a fixed-size subscriber buffer.
func (h *Hub) Subscribe() (<-chan []byte, func()) {
	h.mu.Lock()
	defer h.mu.Unlock()

	id := h.nextID
	h.nextID++
	ch := make(chan []byte, subscriberBufferSize)

	if h.closed {
		// Stream already ended before this subscriber arrived: hand back a
		// closed channel immediately rather than one that would never
		// receive anything and never signal completion either.
		close(ch)
		return ch, func() {}
	}

	h.subscribers[id] = ch

	unsubscribe := func() {
		h.mu.Lock()
		defer h.mu.Unlock()
		if existing, ok := h.subscribers[id]; ok {
			close(existing)
			delete(h.subscribers, id)
		}
	}
	return ch, unsubscribe
}

// Scrollback returns a copy of the recent console output retained so far.
func (h *Hub) Scrollback() []byte {
	return h.scrollback.Bytes()
}

// Write sends p to the container's stdin.
func (h *Hub) Write(p []byte) (int, error) {
	return h.stream.Write(p)
}

// Err returns the error Run terminated with, if any (nil for a clean EOF
// or if Run hasn't finished yet).
func (h *Hub) Err() error {
	h.mu.Lock()
	defer h.mu.Unlock()
	return h.runErr
}
