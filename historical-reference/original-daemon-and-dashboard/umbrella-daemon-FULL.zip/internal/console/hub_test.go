package console

import (
	"bytes"
	"context"
	"io"
	"sync"
	"testing"
	"time"
)

// fakeStream is a minimal, in-memory environment.ConsoleStream double used
// only to drive Hub's fan-out/broadcast logic under test, independent of a
// real Docker container. This is test infrastructure for a unit test, not
// a production stand-in for the Docker environment implementation (which
// is real, in internal/environment/docker.go) — the distinction the
// project's "never fake business logic" rule is about.
type fakeStream struct {
	pr *io.PipeReader
	pw *io.PipeWriter

	mu      sync.Mutex
	written bytes.Buffer
	closed  bool
}

func newFakeStream() *fakeStream {
	pr, pw := io.Pipe()
	return &fakeStream{pr: pr, pw: pw}
}

func (f *fakeStream) Read(p []byte) (int, error) {
	return f.pr.Read(p)
}

func (f *fakeStream) Write(p []byte) (int, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.written.Write(p)
}

func (f *fakeStream) Close() error {
	f.mu.Lock()
	f.closed = true
	f.mu.Unlock()
	f.pw.CloseWithError(io.EOF)
	return f.pr.Close()
}

// simulateOutput writes p as if the container produced it on stdout/stderr.
func (f *fakeStream) simulateOutput(p []byte) {
	f.pw.Write(p)
}

func (f *fakeStream) writtenBytes() []byte {
	f.mu.Lock()
	defer f.mu.Unlock()
	out := make([]byte, f.written.Len())
	copy(out, f.written.Bytes())
	return out
}

func recvWithTimeout(t *testing.T, ch <-chan []byte, timeout time.Duration) []byte {
	t.Helper()
	select {
	case chunk, ok := <-ch:
		if !ok {
			t.Fatal("channel closed unexpectedly while waiting for a chunk")
		}
		return chunk
	case <-time.After(timeout):
		t.Fatal("timed out waiting for broadcast chunk")
		return nil
	}
}

func TestSubscriberReceivesBroadcastOutput(t *testing.T) {
	stream := newFakeStream()
	hub := NewHub(stream, 4096)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	runDone := make(chan error, 1)
	go func() { runDone <- hub.Run(ctx) }()

	ch, unsubscribe := hub.Subscribe()
	defer unsubscribe()

	stream.simulateOutput([]byte("hello console"))

	got := recvWithTimeout(t, ch, time.Second)
	if string(got) != "hello console" {
		t.Fatalf("expected %q, got %q", "hello console", got)
	}

	cancel()
	<-runDone
}

func TestScrollbackAccumulatesOutput(t *testing.T) {
	stream := newFakeStream()
	hub := NewHub(stream, 4096)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	runDone := make(chan error, 1)
	go func() { runDone <- hub.Run(ctx) }()

	// No subscriber at all — scrollback must still accumulate independent
	// of whether anyone is currently listening.
	stream.simulateOutput([]byte("line one\n"))
	time.Sleep(20 * time.Millisecond) // allow Run's goroutine to process
	stream.simulateOutput([]byte("line two\n"))
	time.Sleep(20 * time.Millisecond)

	got := string(hub.Scrollback())
	if got != "line one\nline two\n" {
		t.Fatalf("expected accumulated scrollback, got %q", got)
	}

	cancel()
	<-runDone
}

func TestLateSubscriberDoesNotReceiveScrollbackOnChannel(t *testing.T) {
	// Documents the deliberate design: Subscribe() is forward-only. A late
	// subscriber must read Scrollback() separately for history.
	stream := newFakeStream()
	hub := NewHub(stream, 4096)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runDone := make(chan error, 1)
	go func() { runDone <- hub.Run(ctx) }()

	stream.simulateOutput([]byte("before subscribing"))
	time.Sleep(20 * time.Millisecond)

	ch, unsubscribe := hub.Subscribe()
	defer unsubscribe()

	stream.simulateOutput([]byte("after subscribing"))
	got := recvWithTimeout(t, ch, time.Second)
	if string(got) != "after subscribing" {
		t.Fatalf("expected only post-subscribe output on the channel, got %q", got)
	}

	if !bytes.Contains(hub.Scrollback(), []byte("before subscribing")) {
		t.Fatal("expected scrollback to still contain pre-subscribe output")
	}

	cancel()
	<-runDone
}

func TestMultipleSubscribersEachReceiveBroadcast(t *testing.T) {
	stream := newFakeStream()
	hub := NewHub(stream, 4096)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runDone := make(chan error, 1)
	go func() { runDone <- hub.Run(ctx) }()

	ch1, unsub1 := hub.Subscribe()
	ch2, unsub2 := hub.Subscribe()
	defer unsub1()
	defer unsub2()

	stream.simulateOutput([]byte("broadcast to all"))

	got1 := recvWithTimeout(t, ch1, time.Second)
	got2 := recvWithTimeout(t, ch2, time.Second)
	if string(got1) != "broadcast to all" || string(got2) != "broadcast to all" {
		t.Fatalf("expected both subscribers to receive the same chunk, got %q and %q", got1, got2)
	}

	cancel()
	<-runDone
}

func TestUnsubscribeStopsFurtherDelivery(t *testing.T) {
	stream := newFakeStream()
	hub := NewHub(stream, 4096)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runDone := make(chan error, 1)
	go func() { runDone <- hub.Run(ctx) }()

	ch, unsubscribe := hub.Subscribe()
	stream.simulateOutput([]byte("first"))
	recvWithTimeout(t, ch, time.Second)

	unsubscribe()

	// After unsubscribe, the channel must be closed (not silently stall).
	select {
	case _, ok := <-ch:
		if ok {
			t.Fatal("expected channel to be closed after unsubscribe")
		}
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for channel to close after unsubscribe")
	}

	cancel()
	<-runDone
}

func TestWriteSendsToUnderlyingStreamStdin(t *testing.T) {
	stream := newFakeStream()
	hub := NewHub(stream, 4096)

	n, err := hub.Write([]byte("say hello\n"))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if n != len("say hello\n") {
		t.Fatalf("expected %d bytes written, got %d", len("say hello\n"), n)
	}
	if string(stream.writtenBytes()) != "say hello\n" {
		t.Fatalf("expected stdin to receive the write, got %q", stream.writtenBytes())
	}
}

func TestRunReturnsNilOnCleanEOF(t *testing.T) {
	stream := newFakeStream()
	hub := NewHub(stream, 4096)

	runDone := make(chan error, 1)
	go func() { runDone <- hub.Run(context.Background()) }()

	stream.pw.Close() // clean EOF, not an error

	select {
	case err := <-runDone:
		if err != nil {
			t.Fatalf("expected nil error on clean EOF, got %v", err)
		}
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for Run to return")
	}
}

func TestSubscribeAfterStreamClosedReturnsClosedChannel(t *testing.T) {
	stream := newFakeStream()
	hub := NewHub(stream, 4096)

	runDone := make(chan error, 1)
	go func() { runDone <- hub.Run(context.Background()) }()
	stream.pw.Close()
	<-runDone

	ch, unsubscribe := hub.Subscribe()
	defer unsubscribe()

	select {
	case _, ok := <-ch:
		if ok {
			t.Fatal("expected an already-closed hub to hand back a closed channel")
		}
	case <-time.After(time.Second):
		t.Fatal("timed out — expected immediate close, not a hang")
	}
}

func TestSlowSubscriberDoesNotBlockBroadcastOrOtherSubscribers(t *testing.T) {
	stream := newFakeStream()
	hub := NewHub(stream, 4096)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runDone := make(chan error, 1)
	go func() { runDone <- hub.Run(ctx) }()

	slowCh, unsubSlow := hub.Subscribe() // never read from — simulates a stalled client
	defer unsubSlow()
	fastCh, unsubFast := hub.Subscribe()
	defer unsubFast()

	// Send more chunks than the slow subscriber's buffer can hold.
	for i := 0; i < subscriberBufferSize+10; i++ {
		stream.simulateOutput([]byte("x"))
	}

	// The fast subscriber must still be able to drain chunks without the
	// broadcaster ever blocking on the slow one.
	select {
	case <-fastCh:
	case <-time.After(2 * time.Second):
		t.Fatal("fast subscriber did not receive any chunk — broadcast may be blocking on the slow subscriber")
	}

	_ = slowCh // intentionally never drained
	cancel()
	<-runDone
}
