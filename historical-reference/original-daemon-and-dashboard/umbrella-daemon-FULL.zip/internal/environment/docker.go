// Package environment (docker.go) — the Docker implementation of the
// Environment interface. This is the one driver Phase 1 ships; see
// environment.go's package doc and docs/adr/0002-daemon-environment-abstraction.md
// for why the interface exists separately from this implementation.
package environment

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"time"

	"github.com/docker/docker/api/types"
	"github.com/docker/docker/api/types/container"
	"github.com/docker/docker/api/types/network"
	"github.com/docker/go-connections/nat"
	ocispec "github.com/opencontainers/image-spec/specs-go/v1"

	dstats "umbrella-daemon/internal/stats"
)

// containerNamePrefix namespaces every container umbrella-daemon manages,
// so Inspect/Start/Stop/etc. can address a container by
// "umbrella-<serverID>" without the daemon needing to persist its own
// serverID -> Docker-container-ID mapping — the name itself is that
// mapping, and it survives a daemon restart for free.
const containerNamePrefix = "umbrella-"

func containerName(serverID string) string {
	return containerNamePrefix + serverID
}

// DockerClient is the subset of *client.Client this package depends on.
// Declared as an interface — not a dependency on *client.Client directly —
// specifically so DockerEnvironment's own logic (name construction, spec
// translation, state mapping) is unit-testable against a fake
// implementation of just these methods, without requiring a real Docker
// daemon for tests that aren't actually testing the Docker wire protocol
// itself. Integration tests against a real daemon (docker_integration_test.go)
// use the genuine *client.Client, which satisfies this interface as-is.
type DockerClient interface {
	ContainerCreate(ctx context.Context, config *container.Config, hostConfig *container.HostConfig, networkingConfig *network.NetworkingConfig, platform *ocispec.Platform, containerName string) (container.CreateResponse, error)
	ContainerStart(ctx context.Context, containerID string, options types.ContainerStartOptions) error
	ContainerStop(ctx context.Context, containerID string, options container.StopOptions) error
	ContainerKill(ctx context.Context, containerID, signal string) error
	ContainerRestart(ctx context.Context, containerID string, options container.StopOptions) error
	ContainerRemove(ctx context.Context, containerID string, options types.ContainerRemoveOptions) error
	ContainerInspect(ctx context.Context, containerID string) (types.ContainerJSON, error)
	ContainerStatsOneShot(ctx context.Context, containerID string) (types.ContainerStats, error)
	ContainerAttach(ctx context.Context, containerID string, options types.ContainerAttachOptions) (types.HijackedResponse, error)
	ImagePull(ctx context.Context, refStr string, options types.ImagePullOptions) (io.ReadCloser, error)
}

// DockerEnvironment implements Environment using the Docker Engine API.
type DockerEnvironment struct {
	cli DockerClient
}

// NewDockerEnvironment wraps an already-constructed Docker client. Taking
// the client as a parameter (rather than constructing one internally)
// keeps this package testable against a fake DockerClient and keeps
// daemon-wide concerns (TLS config, connection to a remote Docker host,
// API version negotiation) in cmd/daemon's wiring, not duplicated here.
func NewDockerEnvironment(cli DockerClient) *DockerEnvironment {
	return &DockerEnvironment{cli: cli}
}

var _ Environment = (*DockerEnvironment)(nil)

// --------------------------------------------------------------------------
// Spec translation
// --------------------------------------------------------------------------

func toContainerConfig(spec ContainerSpec) *container.Config {
	env := make([]string, 0, len(spec.Env))
	for k, v := range spec.Env {
		env = append(env, k+"="+v)
	}

	exposedPorts := make(nat.PortSet, len(spec.PortBindings))
	for _, pb := range spec.PortBindings {
		port, err := nat.NewPort(protocolOrDefault(pb.Protocol), fmt.Sprintf("%d", pb.ContainerPort))
		if err != nil {
			// A malformed port spec here is a caller bug (Phase 2's
			// hosting control plane is responsible for validating
			// allocations before they ever reach the daemon) — skip it
			// rather than fail container creation over one bad entry, but
			// this should never happen with validated input.
			continue
		}
		exposedPorts[port] = struct{}{}
	}

	return &container.Config{
		Image:        spec.Image,
		Cmd:          spec.Command,
		Env:          env,
		ExposedPorts: exposedPorts,
		// Tty is enabled deliberately: game server processes (Minecraft
		// chief among them) are interactive console applications, not
		// services that separate stdout/stderr meaningfully. A TTY gives
		// us a single combined output stream without Docker's stdcopy
		// multiplexing framing, which is what internal/console's Hub
		// expects to read directly. This mirrors the same choice Wings
		// makes for the identical reason, not a novel risk.
		Tty:          true,
		OpenStdin:    true,
		AttachStdin:  true,
		AttachStdout: true,
		AttachStderr: true,
		Labels: map[string]string{
			"umbrella.managed":   "true",
			"umbrella.server_id": spec.ServerID,
		},
	}
}

func protocolOrDefault(proto string) string {
	if proto == "" {
		return "tcp"
	}
	return proto
}

func toHostConfig(spec ContainerSpec) *container.HostConfig {
	portBindings := make(nat.PortMap, len(spec.PortBindings))
	for _, pb := range spec.PortBindings {
		port, err := nat.NewPort(protocolOrDefault(pb.Protocol), fmt.Sprintf("%d", pb.ContainerPort))
		if err != nil {
			continue // see the matching skip in toContainerConfig for why
		}
		portBindings[port] = append(portBindings[port], nat.PortBinding{
			HostPort: fmt.Sprintf("%d", pb.HostPort),
		})
	}

	return &container.HostConfig{
		Binds: []string{
			fmt.Sprintf("%s:/data", spec.WorkingDir),
		},
		PortBindings: portBindings,
		RestartPolicy: container.RestartPolicy{
			// Explicitly "no": umbrella-daemon's own crash-detection and
			// Phase 4 self-healing policy own restart decisions. Letting
			// Docker's own restart policy also fire would race with (and
			// hide crash information from) that policy — two independent
			// systems deciding whether to restart a container is strictly
			// worse than one, and the daemon is the one with the crash
			// classification (internal/crash) to decide correctly.
			Name: "no",
		},
		Resources: container.Resources{
			Memory:   spec.Limits.MemoryBytes,
			NanoCPUs: int64(spec.Limits.CPUCores * 1_000_000_000),
		},
	}
}

// --------------------------------------------------------------------------
// State mapping
// --------------------------------------------------------------------------

func mapContainerJSONToState(serverID string, cj types.ContainerJSON) ContainerState {
	state := ContainerState{
		ServerID:  serverID,
		RuntimeID: cj.ID,
		Status:    StatusUnknown,
	}

	if cj.State == nil {
		return state
	}

	state.OOMKilled = cj.State.OOMKilled
	exitCode := cj.State.ExitCode
	state.ExitCode = &exitCode

	if startedAt, err := time.Parse(time.RFC3339Nano, cj.State.StartedAt); err == nil && !startedAt.IsZero() {
		state.StartedAt = &startedAt
	}
	if finishedAt, err := time.Parse(time.RFC3339Nano, cj.State.FinishedAt); err == nil && !finishedAt.IsZero() {
		state.FinishedAt = &finishedAt
	}

	switch {
	case cj.State.Running && cj.State.Restarting:
		state.Status = StatusStarting
	case cj.State.Running:
		state.Status = StatusRunning
	case cj.State.Dead:
		state.Status = StatusCrashed
	case cj.State.Status == "created":
		state.Status = StatusCreated
	case cj.State.Status == "exited":
		if cj.State.ExitCode != 0 || cj.State.OOMKilled {
			state.Status = StatusCrashed
		} else {
			state.Status = StatusStopped
		}
	default:
		state.Status = StatusUnknown
	}

	return state
}

// --------------------------------------------------------------------------
// Environment implementation
// --------------------------------------------------------------------------

func (d *DockerEnvironment) Create(ctx context.Context, spec ContainerSpec) (ContainerState, error) {
	if err := d.ensureImage(ctx, spec.Image); err != nil {
		return ContainerState{}, fmt.Errorf("environment: pulling image %q: %w", spec.Image, err)
	}

	resp, err := d.cli.ContainerCreate(
		ctx,
		toContainerConfig(spec),
		toHostConfig(spec),
		&network.NetworkingConfig{},
		&ocispec.Platform{},
		containerName(spec.ServerID),
	)
	if err != nil {
		return ContainerState{}, fmt.Errorf("environment: creating container for server %q: %w", spec.ServerID, err)
	}

	return ContainerState{
		ServerID:  spec.ServerID,
		RuntimeID: resp.ID,
		Status:    StatusCreated,
	}, nil
}

// ensureImage pulls spec.Image if the daemon doesn't already have it.
// ContainerCreate itself would fail with a "no such image" error rather
// than pulling automatically — this makes "create a server from a template
// whose image isn't cached yet" work without a separate, explicit pull step
// callers would otherwise need to remember.
func (d *DockerEnvironment) ensureImage(ctx context.Context, imageRef string) error {
	reader, err := d.cli.ImagePull(ctx, imageRef, types.ImagePullOptions{})
	if err != nil {
		return err
	}
	defer reader.Close()
	// Docker streams pull progress as newline-delimited JSON; we don't
	// surface per-layer progress in Phase 1, but must drain the stream —
	// the pull isn't actually complete until EOF.
	_, err = io.Copy(io.Discard, reader)
	return err
}

func (d *DockerEnvironment) Start(ctx context.Context, serverID string) (ContainerState, error) {
	name := containerName(serverID)
	if err := d.cli.ContainerStart(ctx, name, types.ContainerStartOptions{}); err != nil {
		return ContainerState{}, fmt.Errorf("environment: starting server %q: %w", serverID, err)
	}
	return d.Inspect(ctx, serverID)
}

func (d *DockerEnvironment) Stop(ctx context.Context, serverID string, gracePeriod time.Duration) (ContainerState, error) {
	name := containerName(serverID)
	seconds := int(gracePeriod.Seconds())
	if err := d.cli.ContainerStop(ctx, name, container.StopOptions{Timeout: &seconds}); err != nil {
		return ContainerState{}, fmt.Errorf("environment: stopping server %q: %w", serverID, err)
	}
	return d.Inspect(ctx, serverID)
}

func (d *DockerEnvironment) Kill(ctx context.Context, serverID string) (ContainerState, error) {
	name := containerName(serverID)
	if err := d.cli.ContainerKill(ctx, name, "SIGKILL"); err != nil {
		return ContainerState{}, fmt.Errorf("environment: killing server %q: %w", serverID, err)
	}
	return d.Inspect(ctx, serverID)
}

func (d *DockerEnvironment) Restart(ctx context.Context, serverID string, gracePeriod time.Duration) (ContainerState, error) {
	name := containerName(serverID)
	seconds := int(gracePeriod.Seconds())
	if err := d.cli.ContainerRestart(ctx, name, container.StopOptions{Timeout: &seconds}); err != nil {
		return ContainerState{}, fmt.Errorf("environment: restarting server %q: %w", serverID, err)
	}
	return d.Inspect(ctx, serverID)
}

func (d *DockerEnvironment) Remove(ctx context.Context, serverID string) error {
	name := containerName(serverID)
	err := d.cli.ContainerRemove(ctx, name, types.ContainerRemoveOptions{Force: true})
	if err != nil {
		return fmt.Errorf("environment: removing server %q: %w", serverID, err)
	}
	return nil
}

func (d *DockerEnvironment) Inspect(ctx context.Context, serverID string) (ContainerState, error) {
	name := containerName(serverID)
	cj, err := d.cli.ContainerInspect(ctx, name)
	if err != nil {
		return ContainerState{}, fmt.Errorf("environment: inspecting server %q: %w", serverID, err)
	}
	return mapContainerJSONToState(serverID, cj), nil
}

func (d *DockerEnvironment) Stats(ctx context.Context, serverID string) (StatsSnapshot, error) {
	name := containerName(serverID)
	raw, err := d.cli.ContainerStatsOneShot(ctx, name)
	if err != nil {
		return StatsSnapshot{}, fmt.Errorf("environment: fetching stats for server %q: %w", serverID, err)
	}
	defer raw.Body.Close()

	var parsed types.StatsJSON
	if err := json.NewDecoder(raw.Body).Decode(&parsed); err != nil {
		return StatsSnapshot{}, fmt.Errorf("environment: decoding stats for server %q: %w", serverID, err)
	}

	return toStatsSnapshot(parsed), nil
}

func toStatsSnapshot(parsed types.StatsJSON) StatsSnapshot {
	cpu := dstats.CPUStats{
		TotalUsage:        parsed.CPUStats.CPUUsage.TotalUsage,
		SystemCPUUsage:    parsed.CPUStats.SystemUsage,
		OnlineCPUs:        parsed.CPUStats.OnlineCPUs,
		PreTotalUsage:     parsed.PreCPUStats.CPUUsage.TotalUsage,
		PreSystemCPUUsage: parsed.PreCPUStats.SystemUsage,
	}

	mem := dstats.MemoryStats{
		Usage: parsed.MemoryStats.Usage,
		Limit: parsed.MemoryStats.Limit,
	}
	// cgroup v1 exposes page cache as memory_stats.stats["cache"]; cgroup v2
	// exposes it as ["inactive_file"] instead. Checked in that order,
	// defaulting to 0 (report raw usage unadjusted) rather than guessing —
	// an unadjusted-but-honest number beats a wrong correction.
	if cache, ok := parsed.MemoryStats.Stats["cache"]; ok {
		mem.CacheBytes = cache
	} else if inactiveFile, ok := parsed.MemoryStats.Stats["inactive_file"]; ok {
		mem.CacheBytes = inactiveFile
	}

	networks := make(map[string]dstats.NetworkStats, len(parsed.Networks))
	for iface, n := range parsed.Networks {
		networks[iface] = dstats.NetworkStats{RxBytes: n.RxBytes, TxBytes: n.TxBytes}
	}

	rx, tx := dstats.SumNetworkBytes(networks)

	return StatsSnapshot{
		Timestamp:        parsed.Read,
		CPUPercent:       dstats.CalculateCPUPercent(cpu),
		MemoryUsedBytes:  dstats.CalculateMemoryUsedBytes(mem),
		MemoryLimitBytes: int64(mem.Limit),
		NetworkRxBytes:   rx,
		NetworkTxBytes:   tx,
	}
}

// WorkingDir returns the host-side source path of the "/data" bind mount
// for serverID's container — the single fixed mount target toHostConfig
// always uses, so finding it is a lookup, not a guess.
func (d *DockerEnvironment) WorkingDir(ctx context.Context, serverID string) (string, error) {
	name := containerName(serverID)
	cj, err := d.cli.ContainerInspect(ctx, name)
	if err != nil {
		return "", fmt.Errorf("environment: inspecting server %q for working dir: %w", serverID, err)
	}
	for _, mount := range cj.Mounts {
		if mount.Destination == "/data" {
			return mount.Source, nil
		}
	}
	return "", fmt.Errorf("environment: server %q has no /data mount", serverID)
}

func (d *DockerEnvironment) Attach(ctx context.Context, serverID string) (ConsoleStream, error) {
	name := containerName(serverID)
	hijacked, err := d.cli.ContainerAttach(ctx, name, types.ContainerAttachOptions{
		Stream: true,
		Stdin:  true,
		Stdout: true,
		Stderr: true,
	})
	if err != nil {
		return nil, fmt.Errorf("environment: attaching to server %q: %w", serverID, err)
	}
	return &dockerConsoleStream{hijacked: hijacked}, nil
}

// dockerConsoleStream adapts a types.HijackedResponse (Docker's raw attach
// connection) to the ConsoleStream interface the rest of the daemon
// depends on, so nothing outside this file needs to know Docker's attach
// API shape.
type dockerConsoleStream struct {
	hijacked types.HijackedResponse
}

func (s *dockerConsoleStream) Read(p []byte) (int, error) {
	return s.hijacked.Reader.Read(p)
}

func (s *dockerConsoleStream) Write(p []byte) (int, error) {
	return s.hijacked.Conn.Write(p)
}

func (s *dockerConsoleStream) Close() error {
	s.hijacked.Close()
	return nil
}
