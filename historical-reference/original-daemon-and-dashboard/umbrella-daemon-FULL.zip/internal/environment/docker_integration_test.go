// This file's tests exercise DockerEnvironment against a genuine Docker
// daemon over its real client. They are not mocked at any layer — this is
// deliberately the one place in the package that talks to actual Docker,
// which is what makes it worth having in addition to docker_test.go's
// fake-client unit tests (those prove DockerEnvironment's own logic is
// correct; these prove that logic actually works against real Docker wire
// behavior, which a fake client can't verify by construction).
//
// Honestly gated, not faked: TestMain skips the entire suite with a clear
// message if no Docker daemon is reachable, rather than mocking one out —
// this environment (the sandbox this phase was built in) has no Docker
// daemon available, so these tests are expected to skip here and are
// intended to run in CI/a developer machine that has one. Run with:
//
//	go test ./internal/environment/... -tags=integration -v
package environment

import (
	"context"
	"os"
	"testing"
	"time"

	"github.com/docker/docker/client"
)

func newRealDockerEnvironmentOrSkip(t *testing.T) (*DockerEnvironment, *client.Client) {
	t.Helper()
	cli, err := client.NewClientWithOpts(client.FromEnv, client.WithAPIVersionNegotiation())
	if err != nil {
		t.Skipf("skipping: could not construct Docker client: %v", err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	if _, err := cli.Ping(ctx); err != nil {
		t.Skipf("skipping: no reachable Docker daemon (%v) — this is expected in the sandbox this phase was authored in; run this suite in an environment with Docker to exercise it", err)
	}
	return NewDockerEnvironment(cli), cli
}

func TestIntegration_FullContainerLifecycle(t *testing.T) {
	env, cli := newRealDockerEnvironmentOrSkip(t)
	_ = cli
	ctx := context.Background()

	workDir, err := os.MkdirTemp("", "umbrella-daemon-integration-*")
	if err != nil {
		t.Fatalf("failed to create temp working dir: %v", err)
	}
	defer os.RemoveAll(workDir)

	serverID := "integration-test-server"
	spec := ContainerSpec{
		ServerID:   serverID,
		Image:      "alpine:3.19",
		Command:    []string{"sh", "-c", "echo hello-umbrella; sleep 30"},
		WorkingDir: workDir,
		Limits:     ResourceLimits{MemoryBytes: 128 * 1024 * 1024, CPUCores: 0.5},
	}

	// Best-effort cleanup from a previous failed run before starting.
	_ = env.Remove(ctx, serverID)

	state, err := env.Create(ctx, spec)
	if err != nil {
		t.Fatalf("Create failed: %v", err)
	}
	defer env.Remove(ctx, serverID)

	if state.Status != StatusCreated {
		t.Fatalf("expected StatusCreated after Create, got %s", state.Status)
	}

	state, err = env.Start(ctx, serverID)
	if err != nil {
		t.Fatalf("Start failed: %v", err)
	}
	if state.Status != StatusRunning {
		t.Fatalf("expected StatusRunning after Start, got %s", state.Status)
	}

	time.Sleep(500 * time.Millisecond) // let the process actually start producing stats

	stats, err := env.Stats(ctx, serverID)
	if err != nil {
		t.Fatalf("Stats failed: %v", err)
	}
	if stats.MemoryLimitBytes != 128*1024*1024 {
		t.Fatalf("expected memory limit to reflect the configured 128MB, got %d", stats.MemoryLimitBytes)
	}

	state, err = env.Restart(ctx, serverID, 5*time.Second)
	if err != nil {
		t.Fatalf("Restart failed: %v", err)
	}
	if state.Status != StatusRunning {
		t.Fatalf("expected StatusRunning after Restart, got %s", state.Status)
	}

	state, err = env.Stop(ctx, serverID, 5*time.Second)
	if err != nil {
		t.Fatalf("Stop failed: %v", err)
	}
	if state.Status != StatusStopped {
		t.Fatalf("expected StatusStopped after Stop, got %s", state.Status)
	}

	if err := env.Remove(ctx, serverID); err != nil {
		t.Fatalf("Remove failed: %v", err)
	}

	if _, err := env.Inspect(ctx, serverID); err == nil {
		t.Fatal("expected Inspect to fail after Remove — the container should no longer exist")
	}
}

func TestIntegration_ConsoleAttachReceivesOutput(t *testing.T) {
	env, _ := newRealDockerEnvironmentOrSkip(t)
	ctx := context.Background()

	workDir, err := os.MkdirTemp("", "umbrella-daemon-integration-console-*")
	if err != nil {
		t.Fatalf("failed to create temp working dir: %v", err)
	}
	defer os.RemoveAll(workDir)

	serverID := "integration-test-console"
	_ = env.Remove(ctx, serverID)

	_, err = env.Create(ctx, ContainerSpec{
		ServerID:   serverID,
		Image:      "alpine:3.19",
		Command:    []string{"sh", "-c", "echo console-test-marker; sleep 10"},
		WorkingDir: workDir,
	})
	if err != nil {
		t.Fatalf("Create failed: %v", err)
	}
	defer env.Remove(ctx, serverID)

	stream, err := env.Attach(ctx, serverID)
	if err != nil {
		t.Fatalf("Attach failed: %v", err)
	}
	defer stream.Close()

	if _, err := env.Start(ctx, serverID); err != nil {
		t.Fatalf("Start failed: %v", err)
	}

	buf := make([]byte, 4096)
	deadline := time.Now().Add(5 * time.Second)
	found := false
	for time.Now().Before(deadline) {
		n, err := stream.Read(buf)
		if n > 0 && contains(string(buf[:n]), "console-test-marker") {
			found = true
			break
		}
		if err != nil {
			break
		}
	}
	if !found {
		t.Fatal("expected to observe 'console-test-marker' on the attached console stream")
	}
}

func contains(haystack, needle string) bool {
	return len(haystack) >= len(needle) && indexOf(haystack, needle) >= 0
}

func indexOf(haystack, needle string) int {
	for i := 0; i+len(needle) <= len(haystack); i++ {
		if haystack[i:i+len(needle)] == needle {
			return i
		}
	}
	return -1
}
