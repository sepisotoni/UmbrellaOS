package environment

import (
	"testing"
	"time"

	"github.com/docker/docker/api/types"
)

func TestToStatsSnapshotComputesExpectedValues(t *testing.T) {
	now := time.Date(2026, 7, 6, 12, 0, 0, 0, time.UTC)

	parsed := types.StatsJSON{
		Stats: types.Stats{
			Read: now,
			CPUStats: types.CPUStats{
				CPUUsage:    types.CPUUsage{TotalUsage: 1_200_000_000},
				SystemUsage: 22_000_000_000,
				OnlineCPUs:  4,
			},
			PreCPUStats: types.CPUStats{
				CPUUsage:    types.CPUUsage{TotalUsage: 1_000_000_000},
				SystemUsage: 20_000_000_000,
			},
			MemoryStats: types.MemoryStats{
				Usage: 500_000_000,
				Limit: 2_000_000_000,
				Stats: map[string]uint64{"cache": 150_000_000},
			},
		},
		Networks: map[string]types.NetworkStats{
			"eth0": {RxBytes: 1000, TxBytes: 500},
		},
	}

	snap := toStatsSnapshot(parsed)

	if snap.Timestamp != now {
		t.Fatalf("expected timestamp to be carried through, got %v", snap.Timestamp)
	}
	wantCPU := 40.0
	if snap.CPUPercent != wantCPU {
		t.Fatalf("expected CPUPercent %.2f, got %.2f", wantCPU, snap.CPUPercent)
	}
	wantMem := int64(350_000_000)
	if snap.MemoryUsedBytes != wantMem {
		t.Fatalf("expected MemoryUsedBytes %d, got %d", wantMem, snap.MemoryUsedBytes)
	}
	if snap.MemoryLimitBytes != 2_000_000_000 {
		t.Fatalf("expected MemoryLimitBytes 2000000000, got %d", snap.MemoryLimitBytes)
	}
	if snap.NetworkRxBytes != 1000 || snap.NetworkTxBytes != 500 {
		t.Fatalf("expected rx=1000 tx=500, got rx=%d tx=%d", snap.NetworkRxBytes, snap.NetworkTxBytes)
	}
}

func TestToStatsSnapshotFallsBackToInactiveFileForCgroupV2(t *testing.T) {
	parsed := types.StatsJSON{
		Stats: types.Stats{
			MemoryStats: types.MemoryStats{
				Usage: 500_000_000,
				Limit: 2_000_000_000,
				// cgroup v2 hosts report page cache under "inactive_file",
				// not "cache" — this must still be subtracted correctly.
				Stats: map[string]uint64{"inactive_file": 100_000_000},
			},
		},
	}
	snap := toStatsSnapshot(parsed)
	wantMem := int64(400_000_000)
	if snap.MemoryUsedBytes != wantMem {
		t.Fatalf("expected MemoryUsedBytes %d using inactive_file fallback, got %d", wantMem, snap.MemoryUsedBytes)
	}
}

func TestToStatsSnapshotHandlesMissingCacheStatsGracefully(t *testing.T) {
	parsed := types.StatsJSON{
		Stats: types.Stats{
			MemoryStats: types.MemoryStats{
				Usage: 500_000_000,
				Limit: 2_000_000_000,
				Stats: map[string]uint64{}, // neither key present
			},
		},
	}
	snap := toStatsSnapshot(parsed)
	// No cache figure available: report raw usage unadjusted rather than
	// guessing — see the comment in toStatsSnapshot for why an honest
	// unadjusted number beats a fabricated correction.
	if snap.MemoryUsedBytes != 500_000_000 {
		t.Fatalf("expected raw usage when no cache stat is available, got %d", snap.MemoryUsedBytes)
	}
}
