package environment

import (
	"context"
	"errors"
	"io"
	"strings"
	"testing"
	"time"

	"github.com/docker/docker/api/types"
	"github.com/docker/docker/api/types/container"
	"github.com/docker/docker/api/types/network"
	ocispec "github.com/opencontainers/image-spec/specs-go/v1"
)

// fakeDockerClient is a test double implementing exactly the DockerClient
// interface, used to verify DockerEnvironment's own logic (name
// construction, spec translation, error wrapping) without a real Docker
// daemon. The genuine implementation this substitutes for in production is
// *client.Client from the Docker SDK, used as-is in cmd/daemon's wiring and
// exercised for real in docker_integration_test.go.
type fakeDockerClient struct {
	createFn     func(ctx context.Context, config *container.Config, hostConfig *container.HostConfig, name string) (container.CreateResponse, error)
	startFn      func(ctx context.Context, containerID string) error
	stopFn       func(ctx context.Context, containerID string, opts container.StopOptions) error
	killFn       func(ctx context.Context, containerID, signal string) error
	restartFn    func(ctx context.Context, containerID string, opts container.StopOptions) error
	removeFn     func(ctx context.Context, containerID string, opts types.ContainerRemoveOptions) error
	inspectFn    func(ctx context.Context, containerID string) (types.ContainerJSON, error)
	statsFn      func(ctx context.Context, containerID string) (types.ContainerStats, error)
	attachFn     func(ctx context.Context, containerID string) (types.HijackedResponse, error)
	imagePullFn  func(ctx context.Context, ref string) (io.ReadCloser, error)
	lastImageRef string
}

func (f *fakeDockerClient) ContainerCreate(ctx context.Context, config *container.Config, hostConfig *container.HostConfig, _ *network.NetworkingConfig, _ *ocispec.Platform, name string) (container.CreateResponse, error) {
	return f.createFn(ctx, config, hostConfig, name)
}
func (f *fakeDockerClient) ContainerStart(ctx context.Context, containerID string, _ types.ContainerStartOptions) error {
	return f.startFn(ctx, containerID)
}
func (f *fakeDockerClient) ContainerStop(ctx context.Context, containerID string, opts container.StopOptions) error {
	return f.stopFn(ctx, containerID, opts)
}
func (f *fakeDockerClient) ContainerKill(ctx context.Context, containerID, signal string) error {
	return f.killFn(ctx, containerID, signal)
}
func (f *fakeDockerClient) ContainerRestart(ctx context.Context, containerID string, opts container.StopOptions) error {
	return f.restartFn(ctx, containerID, opts)
}
func (f *fakeDockerClient) ContainerRemove(ctx context.Context, containerID string, opts types.ContainerRemoveOptions) error {
	return f.removeFn(ctx, containerID, opts)
}
func (f *fakeDockerClient) ContainerInspect(ctx context.Context, containerID string) (types.ContainerJSON, error) {
	return f.inspectFn(ctx, containerID)
}
func (f *fakeDockerClient) ContainerStatsOneShot(ctx context.Context, containerID string) (types.ContainerStats, error) {
	return f.statsFn(ctx, containerID)
}
func (f *fakeDockerClient) ContainerAttach(ctx context.Context, containerID string, _ types.ContainerAttachOptions) (types.HijackedResponse, error) {
	return f.attachFn(ctx, containerID)
}
func (f *fakeDockerClient) ImagePull(ctx context.Context, refStr string, _ types.ImagePullOptions) (io.ReadCloser, error) {
	f.lastImageRef = refStr
	return f.imagePullFn(ctx, refStr)
}

func emptyPullReader() io.ReadCloser {
	return io.NopCloser(strings.NewReader(""))
}

// --------------------------------------------------------------------------
// Spec translation
// --------------------------------------------------------------------------

func TestToContainerConfigSetsExpectedFields(t *testing.T) {
	spec := ContainerSpec{
		ServerID: "srv-1",
		Image:    "itzg/minecraft-server:java21",
		Command:  []string{"start"},
		Env:      map[string]string{"EULA": "TRUE"},
		PortBindings: []PortBinding{
			{ContainerPort: 25565, HostPort: 30001, Protocol: "tcp"},
		},
	}
	cfg := toContainerConfig(spec)

	if cfg.Image != spec.Image {
		t.Fatalf("expected image %q, got %q", spec.Image, cfg.Image)
	}
	if !cfg.Tty || !cfg.OpenStdin || !cfg.AttachStdin || !cfg.AttachStdout || !cfg.AttachStderr {
		t.Fatal("expected Tty+stdin/stdout/stderr attach all enabled for console streaming")
	}
	if len(cfg.Env) != 1 || cfg.Env[0] != "EULA=TRUE" {
		t.Fatalf("expected Env to contain EULA=TRUE, got %v", cfg.Env)
	}
	if cfg.Labels["umbrella.server_id"] != "srv-1" {
		t.Fatalf("expected umbrella.server_id label to be set, got %v", cfg.Labels)
	}
	if len(cfg.ExposedPorts) != 1 {
		t.Fatalf("expected exactly one exposed port, got %d", len(cfg.ExposedPorts))
	}
}

func TestToContainerConfigSkipsMalformedPortWithoutFailing(t *testing.T) {
	spec := ContainerSpec{
		ServerID: "srv-1",
		Image:    "test",
		PortBindings: []PortBinding{
			{ContainerPort: 0, HostPort: 30001, Protocol: "bogus-protocol!!"},
		},
	}
	// Must not panic despite a malformed protocol string.
	cfg := toContainerConfig(spec)
	_ = cfg
}

func TestToHostConfigSetsResourceLimitsAndBindMount(t *testing.T) {
	spec := ContainerSpec{
		ServerID:   "srv-1",
		WorkingDir: "/srv/umbrella/srv-1",
		Limits: ResourceLimits{
			MemoryBytes: 4_000_000_000,
			CPUCores:    2.5,
		},
	}
	hc := toHostConfig(spec)

	if len(hc.Binds) != 1 || hc.Binds[0] != "/srv/umbrella/srv-1:/data" {
		t.Fatalf("expected working dir bind mount, got %v", hc.Binds)
	}
	if hc.Resources.Memory != 4_000_000_000 {
		t.Fatalf("expected Memory 4000000000, got %d", hc.Resources.Memory)
	}
	if hc.Resources.NanoCPUs != 2_500_000_000 {
		t.Fatalf("expected NanoCPUs 2500000000 for 2.5 cores, got %d", hc.Resources.NanoCPUs)
	}
	if hc.RestartPolicy.Name != "no" {
		t.Fatalf("expected RestartPolicy 'no' (daemon owns restart decisions), got %q", hc.RestartPolicy.Name)
	}
}

func TestToHostConfigAppliesPortBindings(t *testing.T) {
	spec := ContainerSpec{
		ServerID: "srv-1",
		PortBindings: []PortBinding{
			{ContainerPort: 25565, HostPort: 30001, Protocol: "tcp"},
			{ContainerPort: 19132, HostPort: 30002, Protocol: "udp"},
		},
	}
	hc := toHostConfig(spec)

	if len(hc.PortBindings) != 2 {
		t.Fatalf("expected 2 port binding entries, got %d", len(hc.PortBindings))
	}
	found := false
	for port, bindings := range hc.PortBindings {
		if port.Port() == "25565" && port.Proto() == "tcp" {
			found = true
			if len(bindings) != 1 || bindings[0].HostPort != "30001" {
				t.Fatalf("expected host port 30001 bound to 25565/tcp, got %v", bindings)
			}
		}
	}
	if !found {
		t.Fatal("expected to find a binding for 25565/tcp")
	}
}

// --------------------------------------------------------------------------
// State mapping
// --------------------------------------------------------------------------

func containerJSONWithState(state *types.ContainerState) types.ContainerJSON {
	return types.ContainerJSON{
		ContainerJSONBase: &types.ContainerJSONBase{
			ID:    "docker-id-123",
			State: state,
		},
	}
}

func TestMapContainerJSONToStateRunning(t *testing.T) {
	cj := containerJSONWithState(&types.ContainerState{
		Status:    "running",
		Running:   true,
		StartedAt: time.Now().Format(time.RFC3339Nano),
	})
	state := mapContainerJSONToState("srv-1", cj)
	if state.Status != StatusRunning {
		t.Fatalf("expected StatusRunning, got %s", state.Status)
	}
	if state.RuntimeID != "docker-id-123" {
		t.Fatalf("expected RuntimeID to be carried through, got %s", state.RuntimeID)
	}
	if state.StartedAt == nil {
		t.Fatal("expected StartedAt to be parsed")
	}
}

func TestMapContainerJSONToStateCleanExit(t *testing.T) {
	cj := containerJSONWithState(&types.ContainerState{
		Status:     "exited",
		ExitCode:   0,
		FinishedAt: time.Now().Format(time.RFC3339Nano),
	})
	state := mapContainerJSONToState("srv-1", cj)
	if state.Status != StatusStopped {
		t.Fatalf("expected StatusStopped for a clean exit, got %s", state.Status)
	}
	if state.ExitCode == nil || *state.ExitCode != 0 {
		t.Fatalf("expected ExitCode 0, got %v", state.ExitCode)
	}
}

func TestMapContainerJSONToStateCrashedNonZeroExit(t *testing.T) {
	cj := containerJSONWithState(&types.ContainerState{
		Status:   "exited",
		ExitCode: 1,
	})
	state := mapContainerJSONToState("srv-1", cj)
	if state.Status != StatusCrashed {
		t.Fatalf("expected StatusCrashed for a non-zero exit, got %s", state.Status)
	}
}

func TestMapContainerJSONToStateOOMKilledIsCrashedEvenWithZeroExit(t *testing.T) {
	cj := containerJSONWithState(&types.ContainerState{
		Status:    "exited",
		ExitCode:  0,
		OOMKilled: true,
	})
	state := mapContainerJSONToState("srv-1", cj)
	if state.Status != StatusCrashed {
		t.Fatalf("expected StatusCrashed for an OOM-killed container even with exit code 0, got %s", state.Status)
	}
	if !state.OOMKilled {
		t.Fatal("expected OOMKilled to be true")
	}
}

func TestMapContainerJSONToStateCreated(t *testing.T) {
	cj := containerJSONWithState(&types.ContainerState{Status: "created"})
	state := mapContainerJSONToState("srv-1", cj)
	if state.Status != StatusCreated {
		t.Fatalf("expected StatusCreated, got %s", state.Status)
	}
}

func TestMapContainerJSONToStateNilStateReturnsUnknown(t *testing.T) {
	cj := containerJSONWithState(nil)
	state := mapContainerJSONToState("srv-1", cj)
	if state.Status != StatusUnknown {
		t.Fatalf("expected StatusUnknown for a nil State, got %s", state.Status)
	}
}

// --------------------------------------------------------------------------
// DockerEnvironment method wiring (delegation + error handling)
// --------------------------------------------------------------------------

func TestCreatePullsImageThenCreatesContainer(t *testing.T) {
	pullCalled := false
	fake := &fakeDockerClient{
		imagePullFn: func(ctx context.Context, ref string) (io.ReadCloser, error) {
			pullCalled = true
			return emptyPullReader(), nil
		},
		createFn: func(ctx context.Context, cfg *container.Config, hc *container.HostConfig, name string) (container.CreateResponse, error) {
			if name != "umbrella-srv-1" {
				t.Fatalf("expected container name 'umbrella-srv-1', got %q", name)
			}
			return container.CreateResponse{ID: "docker-id-1"}, nil
		},
	}
	env := NewDockerEnvironment(fake)

	state, err := env.Create(context.Background(), ContainerSpec{ServerID: "srv-1", Image: "test-image"})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !pullCalled {
		t.Fatal("expected image pull to be attempted before create")
	}
	if state.RuntimeID != "docker-id-1" {
		t.Fatalf("expected RuntimeID from create response, got %s", state.RuntimeID)
	}
	if state.Status != StatusCreated {
		t.Fatalf("expected StatusCreated, got %s", state.Status)
	}
}

func TestCreateFailsIfImagePullFails(t *testing.T) {
	fake := &fakeDockerClient{
		imagePullFn: func(ctx context.Context, ref string) (io.ReadCloser, error) {
			return nil, errors.New("no such image")
		},
	}
	env := NewDockerEnvironment(fake)

	_, err := env.Create(context.Background(), ContainerSpec{ServerID: "srv-1", Image: "does-not-exist"})
	if err == nil {
		t.Fatal("expected an error when image pull fails")
	}
}

func TestStartInspectsAfterStarting(t *testing.T) {
	inspectCalled := false
	fake := &fakeDockerClient{
		startFn: func(ctx context.Context, containerID string) error {
			if containerID != "umbrella-srv-1" {
				t.Fatalf("expected container name 'umbrella-srv-1', got %q", containerID)
			}
			return nil
		},
		inspectFn: func(ctx context.Context, containerID string) (types.ContainerJSON, error) {
			inspectCalled = true
			return containerJSONWithState(&types.ContainerState{Status: "running", Running: true}), nil
		},
	}
	env := NewDockerEnvironment(fake)

	state, err := env.Start(context.Background(), "srv-1")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !inspectCalled {
		t.Fatal("expected Start to inspect the container afterward for the returned state")
	}
	if state.Status != StatusRunning {
		t.Fatalf("expected StatusRunning, got %s", state.Status)
	}
}

func TestStartWrapsUnderlyingError(t *testing.T) {
	fake := &fakeDockerClient{
		startFn: func(ctx context.Context, containerID string) error {
			return errors.New("container not found")
		},
	}
	env := NewDockerEnvironment(fake)

	_, err := env.Start(context.Background(), "srv-missing")
	if err == nil {
		t.Fatal("expected an error")
	}
	if !strings.Contains(err.Error(), "srv-missing") {
		t.Fatalf("expected error to reference the server ID for debuggability, got: %v", err)
	}
}

func TestStopPassesGracePeriodAsTimeoutSeconds(t *testing.T) {
	var gotTimeout *int
	fake := &fakeDockerClient{
		stopFn: func(ctx context.Context, containerID string, opts container.StopOptions) error {
			gotTimeout = opts.Timeout
			return nil
		},
		inspectFn: func(ctx context.Context, containerID string) (types.ContainerJSON, error) {
			return containerJSONWithState(&types.ContainerState{Status: "exited"}), nil
		},
	}
	env := NewDockerEnvironment(fake)

	_, err := env.Stop(context.Background(), "srv-1", 30*time.Second)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if gotTimeout == nil || *gotTimeout != 30 {
		t.Fatalf("expected a 30-second timeout to be passed through, got %v", gotTimeout)
	}
}

func TestKillUsesSIGKILL(t *testing.T) {
	var gotSignal string
	fake := &fakeDockerClient{
		killFn: func(ctx context.Context, containerID, signal string) error {
			gotSignal = signal
			return nil
		},
		inspectFn: func(ctx context.Context, containerID string) (types.ContainerJSON, error) {
			return containerJSONWithState(&types.ContainerState{Status: "exited"}), nil
		},
	}
	env := NewDockerEnvironment(fake)

	_, err := env.Kill(context.Background(), "srv-1")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if gotSignal != "SIGKILL" {
		t.Fatalf("expected SIGKILL, got %q", gotSignal)
	}
}

func TestRemoveForcesRemoval(t *testing.T) {
	var gotOpts types.ContainerRemoveOptions
	fake := &fakeDockerClient{
		removeFn: func(ctx context.Context, containerID string, opts types.ContainerRemoveOptions) error {
			gotOpts = opts
			return nil
		},
	}
	env := NewDockerEnvironment(fake)

	if err := env.Remove(context.Background(), "srv-1"); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !gotOpts.Force {
		t.Fatal("expected Remove to force-remove (a still-running container shouldn't block cleanup)")
	}
}

func TestInspectWrapsError(t *testing.T) {
	fake := &fakeDockerClient{
		inspectFn: func(ctx context.Context, containerID string) (types.ContainerJSON, error) {
			return types.ContainerJSON{}, errors.New("no such container")
		},
	}
	env := NewDockerEnvironment(fake)

	_, err := env.Inspect(context.Background(), "srv-1")
	if err == nil {
		t.Fatal("expected an error")
	}
}

func TestWorkingDirFindsDataMountSource(t *testing.T) {
	fake := &fakeDockerClient{
		inspectFn: func(ctx context.Context, containerID string) (types.ContainerJSON, error) {
			return types.ContainerJSON{
				ContainerJSONBase: &types.ContainerJSONBase{
					ID: "docker-id-1",
				},
				Mounts: []types.MountPoint{
					{Destination: "/other", Source: "/host/other"},
					{Destination: "/data", Source: "/srv/umbrella/servers/srv-1"},
				},
			}, nil
		},
	}
	env := NewDockerEnvironment(fake)

	dir, err := env.WorkingDir(context.Background(), "srv-1")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if dir != "/srv/umbrella/servers/srv-1" {
		t.Fatalf("expected the /data mount's source, got %q", dir)
	}
}

func TestWorkingDirErrorsWhenNoDataMountPresent(t *testing.T) {
	fake := &fakeDockerClient{
		inspectFn: func(ctx context.Context, containerID string) (types.ContainerJSON, error) {
			return types.ContainerJSON{
				ContainerJSONBase: &types.ContainerJSONBase{ID: "docker-id-1"},
				Mounts:            []types.MountPoint{{Destination: "/other", Source: "/host/other"}},
			}, nil
		},
	}
	env := NewDockerEnvironment(fake)

	_, err := env.WorkingDir(context.Background(), "srv-1")
	if err == nil {
		t.Fatal("expected an error when no /data mount is present")
	}
}
