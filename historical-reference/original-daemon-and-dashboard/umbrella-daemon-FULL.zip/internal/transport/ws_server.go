// Package transport is umbrella-daemon's control-plane surface: the HTTP/WS
// API umbrella-core calls to create/start/stop/restart servers, fetch
// stats, and stream console I/O. Every handler here does one thing:
// translate an authenticated HTTP/WS request into a call against
// environment.Environment (or a server's console.Hub) — no business logic
// beyond that translation lives in this package, matching the same
// "adapters don't contain logic" principle umbrella-core's Capability
// Registry established for its own adapters.
package transport

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/gorilla/websocket"

	"umbrella-daemon/internal/auth"
	"umbrella-daemon/internal/backup"
	"umbrella-daemon/internal/console"
	"umbrella-daemon/internal/environment"
	"umbrella-daemon/internal/files"
)

const (
	defaultScrollbackCapacity = 64 * 1024 // 64KB of console history per server
	defaultGracePeriod        = 30 * time.Second
	defaultStopTimeout        = 60 * time.Second
)

// Server is umbrella-daemon's HTTP/WS API.
type Server struct {
	env    environment.Environment
	issuer *auth.Issuer
	logger *slog.Logger

	mu       sync.Mutex
	hubs     map[string]*console.Hub // serverID -> active console hub, only present while attached
	mux      *http.ServeMux
	upgrader websocket.Upgrader

	// backupDir is where this node stores backup archives, one
	// subdirectory per server. Phase 4.
	backupDir string
}

// NewServer builds the daemon's HTTP handler. issuer verifies the node
// tokens umbrella-core presents on every request (see internal/auth) —
// there is no unauthenticated path except /healthz, which deliberately
// exposes nothing about any server's state. backupDir is where backup
// archives are stored on this node (Phase 4).
func NewServer(env environment.Environment, issuer *auth.Issuer, logger *slog.Logger, backupDir string) *Server {
	if logger == nil {
		logger = slog.Default()
	}
	s := &Server{
		env:       env,
		issuer:    issuer,
		logger:    logger,
		backupDir: backupDir,
		hubs:      make(map[string]*console.Hub),
		upgrader: websocket.Upgrader{
			// Origin checking is core-to-daemon, not browser-to-daemon —
			// umbrella-core is the only intended WS client, connecting
			// node-to-node over infrastructure it controls, not a browser
			// subject to CORS/CSRF-style origin concerns. Left permissive
			// here and documented rather than silently defaulting to
			// gorilla's same-origin check, which would reject the actual
			// intended caller.
			CheckOrigin: func(r *http.Request) bool { return true },
		},
	}
	s.mux = s.routes()
	return s
}

func (s *Server) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	s.mux.ServeHTTP(w, r)
}

func (s *Server) routes() *http.ServeMux {
	mux := http.NewServeMux()

	mux.HandleFunc("GET /healthz", s.handleHealthz)

	mux.Handle("POST /v1/servers/{id}", s.authenticated(s.handleCreate))
	mux.Handle("DELETE /v1/servers/{id}", s.authenticated(s.handleRemove))
	mux.Handle("POST /v1/servers/{id}/start", s.authenticated(s.handleStart))
	mux.Handle("POST /v1/servers/{id}/stop", s.authenticated(s.handleStop))
	mux.Handle("POST /v1/servers/{id}/kill", s.authenticated(s.handleKill))
	mux.Handle("POST /v1/servers/{id}/restart", s.authenticated(s.handleRestart))
	mux.Handle("GET /v1/servers/{id}/state", s.authenticated(s.handleState))
	mux.Handle("GET /v1/servers/{id}/stats", s.authenticated(s.handleStats))
	mux.Handle("GET /v1/servers/{id}/console", s.authenticated(s.handleConsole))

	mux.Handle("GET /v1/servers/{id}/files/list", s.authenticated(s.handleFilesList))
	mux.Handle("GET /v1/servers/{id}/files/read", s.authenticated(s.handleFilesRead))
	mux.Handle("PUT /v1/servers/{id}/files/write", s.authenticated(s.handleFilesWrite))
	mux.Handle("DELETE /v1/servers/{id}/files", s.authenticated(s.handleFilesDelete))
	mux.Handle("POST /v1/servers/{id}/files/mkdir", s.authenticated(s.handleFilesMkdir))
	mux.Handle("POST /v1/servers/{id}/files/move", s.authenticated(s.handleFilesMove))

	mux.Handle("POST /v1/servers/{id}/backups", s.authenticated(s.handleBackupCreate))
	mux.Handle("POST /v1/servers/{id}/backups/{backup_id}/restore", s.authenticated(s.handleBackupRestore))
	mux.Handle("DELETE /v1/servers/{id}/backups/{backup_id}", s.authenticated(s.handleBackupDelete))

	return mux
}

// --------------------------------------------------------------------------
// Auth middleware
// --------------------------------------------------------------------------

func (s *Server) authenticated(next http.HandlerFunc) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		authHeader := r.Header.Get("Authorization")
		const prefix = "Bearer "
		if !strings.HasPrefix(authHeader, prefix) {
			writeError(w, http.StatusUnauthorized, "missing or malformed Authorization header")
			return
		}
		token := strings.TrimPrefix(authHeader, prefix)

		claims, err := s.issuer.VerifyNodeToken(token)
		if err != nil {
			writeError(w, http.StatusUnauthorized, "invalid node token: "+err.Error())
			return
		}

		r = r.WithContext(context.WithValue(r.Context(), nodeClaimsContextKey{}, claims))
		next.ServeHTTP(w, r)
	})
}

type nodeClaimsContextKey struct{}

// --------------------------------------------------------------------------
// Handlers
// --------------------------------------------------------------------------

func (s *Server) handleHealthz(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}

// createServerRequest is the JSON body for POST /v1/servers/{id} — a wire
// representation of environment.ContainerSpec. Kept as a distinct type
// (rather than reusing ContainerSpec's Go struct tags directly) so this
// package's wire contract can evolve independently of the Environment
// interface's internal shape — umbrella-core is a separate process/language
// and this is the one place that boundary is explicit.
type createServerRequest struct {
	Image        string            `json:"image"`
	Command      []string          `json:"command"`
	Env          map[string]string `json:"env"`
	WorkingDir   string            `json:"working_dir"`
	MemoryBytes  int64             `json:"memory_bytes"`
	CPUCores     float64           `json:"cpu_cores"`
	DiskBytes    int64             `json:"disk_bytes"`
	PortBindings []portBindingJSON `json:"port_bindings"`
}

type portBindingJSON struct {
	ContainerPort int    `json:"container_port"`
	HostPort      int    `json:"host_port"`
	Protocol      string `json:"protocol"`
}

func (s *Server) handleCreate(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")

	var body createServerRequest
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeError(w, http.StatusBadRequest, "invalid request body: "+err.Error())
		return
	}
	if body.Image == "" {
		writeError(w, http.StatusBadRequest, "image is required")
		return
	}
	if body.WorkingDir == "" {
		writeError(w, http.StatusBadRequest, "working_dir is required")
		return
	}

	portBindings := make([]environment.PortBinding, 0, len(body.PortBindings))
	for _, pb := range body.PortBindings {
		portBindings = append(portBindings, environment.PortBinding{
			ContainerPort: pb.ContainerPort,
			HostPort:      pb.HostPort,
			Protocol:      pb.Protocol,
		})
	}

	spec := environment.ContainerSpec{
		ServerID:   serverID,
		Image:      body.Image,
		Command:    body.Command,
		Env:        body.Env,
		WorkingDir: body.WorkingDir,
		Limits: environment.ResourceLimits{
			MemoryBytes: body.MemoryBytes,
			CPUCores:    body.CPUCores,
			DiskBytes:   body.DiskBytes,
		},
		PortBindings: portBindings,
	}

	state, err := s.env.Create(r.Context(), spec)
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	writeJSON(w, http.StatusCreated, state)
}

func (s *Server) handleRemove(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")
	if err := s.env.Remove(r.Context(), serverID); err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) handleStart(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")
	state, err := s.env.Start(r.Context(), serverID)
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, state)
}

type stopRequest struct {
	GracePeriodSeconds *int `json:"grace_period_seconds"`
}

func (s *Server) handleStop(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")
	grace := defaultGracePeriod

	var body stopRequest
	if r.Body != nil {
		if err := json.NewDecoder(r.Body).Decode(&body); err == nil && body.GracePeriodSeconds != nil {
			grace = time.Duration(*body.GracePeriodSeconds) * time.Second
		}
	}

	state, err := s.env.Stop(r.Context(), serverID, grace)
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, state)
}

func (s *Server) handleKill(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")
	state, err := s.env.Kill(r.Context(), serverID)
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, state)
}

func (s *Server) handleRestart(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")
	state, err := s.env.Restart(r.Context(), serverID, defaultGracePeriod)
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, state)
}

func (s *Server) handleState(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")
	state, err := s.env.Inspect(r.Context(), serverID)
	if err != nil {
		writeError(w, http.StatusNotFound, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, state)
}

func (s *Server) handleStats(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")
	snap, err := s.env.Stats(r.Context(), serverID)
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, snap)
}

// handleConsole upgrades to a WebSocket and streams a server's console
// bidirectionally: binary frames from the client are written to the
// container's stdin; everything the container writes to its console is
// broadcast to this and every other currently-attached client. On connect,
// sends one initial text frame containing recent scrollback so a client
// attaching mid-session isn't looking at a blank screen.
func (s *Server) handleConsole(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")

	hub, err := s.hubForServer(r.Context(), serverID)
	if err != nil {
		writeError(w, http.StatusBadGateway, "attaching console: "+err.Error())
		return
	}

	conn, err := s.upgrader.Upgrade(w, r, nil)
	if err != nil {
		s.logger.Error("websocket upgrade failed", "server_id", serverID, "error", err)
		return
	}
	defer conn.Close()

	if scrollback := hub.Scrollback(); len(scrollback) > 0 {
		_ = conn.WriteMessage(websocket.BinaryMessage, scrollback)
	}

	sub, unsubscribe := hub.Subscribe()
	defer unsubscribe()

	// Writer goroutine: hub broadcasts -> WS client.
	writerDone := make(chan struct{})
	go func() {
		defer close(writerDone)
		for chunk := range sub {
			if err := conn.WriteMessage(websocket.BinaryMessage, chunk); err != nil {
				return
			}
		}
	}()

	// Reader loop: WS client -> container stdin. Runs on this goroutine;
	// returning from it (on any read error, including normal client
	// disconnect) triggers the deferred unsubscribe/close above.
	for {
		msgType, data, err := conn.ReadMessage()
		if err != nil {
			break
		}
		if msgType == websocket.BinaryMessage || msgType == websocket.TextMessage {
			if _, err := hub.Write(data); err != nil {
				s.logger.Warn("failed writing to container stdin", "server_id", serverID, "error", err)
				break
			}
		}
	}

	<-writerDone
}

// hubForServer returns the existing console.Hub for serverID if one is
// already running, or attaches a new one. Hubs are torn down when a
// server's container stops (cmd/daemon's lifecycle watcher calls
// removeHub) — not on the last WebSocket client disconnecting, since
// console output (and therefore scrollback) should keep accumulating for
// the next client to attach even if nobody is watching right now.
func (s *Server) hubForServer(ctx context.Context, serverID string) (*console.Hub, error) {
	s.mu.Lock()
	if hub, ok := s.hubs[serverID]; ok {
		s.mu.Unlock()
		return hub, nil
	}
	s.mu.Unlock()

	stream, err := s.env.Attach(ctx, serverID)
	if err != nil {
		return nil, err
	}

	hub := console.NewHub(stream, defaultScrollbackCapacity)

	s.mu.Lock()
	s.hubs[serverID] = hub
	s.mu.Unlock()

	go func() {
		if err := hub.Run(context.Background()); err != nil {
			s.logger.Warn("console hub terminated with error", "server_id", serverID, "error", err)
		}
		s.mu.Lock()
		delete(s.hubs, serverID)
		s.mu.Unlock()
	}()

	return hub, nil
}

// --------------------------------------------------------------------------
// File manager (Phase 4)
// --------------------------------------------------------------------------

// managerFor builds a sandboxed files.Manager scoped to serverID's actual
// current working directory (derived from the running container's mount,
// see environment.Environment.WorkingDir) — never a path the caller
// supplies, which is what makes the sandbox boundary meaningful rather
// than advisory.
func (s *Server) managerFor(ctx context.Context, serverID string) (*files.Manager, error) {
	workingDir, err := s.env.WorkingDir(ctx, serverID)
	if err != nil {
		return nil, fmt.Errorf("resolving working directory: %w", err)
	}
	return files.NewManager(workingDir)
}

func (s *Server) handleFilesList(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")
	mgr, err := s.managerFor(r.Context(), serverID)
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	entries, err := mgr.List(r.URL.Query().Get("path"))
	if err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, entries)
}

func (s *Server) handleFilesRead(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")
	mgr, err := s.managerFor(r.Context(), serverID)
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	data, err := mgr.ReadFile(r.URL.Query().Get("path"))
	if err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	w.Header().Set("Content-Type", "application/octet-stream")
	w.WriteHeader(http.StatusOK)
	w.Write(data)
}

func (s *Server) handleFilesWrite(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")
	mgr, err := s.managerFor(r.Context(), serverID)
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	data, err := readBodyLimited(r, files.MaxReadableFileBytes)
	if err != nil {
		writeError(w, http.StatusBadRequest, "reading request body: "+err.Error())
		return
	}
	if err := mgr.WriteFile(r.URL.Query().Get("path"), data); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, map[string]bool{"written": true})
}

func (s *Server) handleFilesDelete(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")
	mgr, err := s.managerFor(r.Context(), serverID)
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	if err := mgr.Delete(r.URL.Query().Get("path")); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) handleFilesMkdir(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")
	mgr, err := s.managerFor(r.Context(), serverID)
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	if err := mgr.Mkdir(r.URL.Query().Get("path")); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, map[string]bool{"created": true})
}

type moveRequest struct {
	From string `json:"from"`
	To   string `json:"to"`
}

func (s *Server) handleFilesMove(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")
	mgr, err := s.managerFor(r.Context(), serverID)
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	var body moveRequest
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeError(w, http.StatusBadRequest, "invalid request body: "+err.Error())
		return
	}
	if err := mgr.Move(body.From, body.To); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, map[string]bool{"moved": true})
}

func readBodyLimited(r *http.Request, limit int64) ([]byte, error) {
	defer r.Body.Close()
	data, err := io.ReadAll(io.LimitReader(r.Body, limit+1))
	if err != nil {
		return nil, err
	}
	if int64(len(data)) > limit {
		return nil, fmt.Errorf("request body exceeds the %d byte limit", limit)
	}
	return data, nil
}

// --------------------------------------------------------------------------
// Backups (Phase 4)
// --------------------------------------------------------------------------

func (s *Server) backupPath(serverID, backupID string) string {
	return filepath.Join(s.backupDir, serverID, backupID+".tar.gz")
}

type createBackupRequest struct {
	BackupID string `json:"backup_id"`
}

type backupResult struct {
	BackupID  string `json:"backup_id"`
	SizeBytes int64  `json:"size_bytes"`
}

func (s *Server) handleBackupCreate(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")

	var body createBackupRequest
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil || body.BackupID == "" {
		writeError(w, http.StatusBadRequest, "backup_id is required")
		return
	}

	workingDir, err := s.env.WorkingDir(r.Context(), serverID)
	if err != nil {
		writeError(w, http.StatusBadGateway, "resolving working directory: "+err.Error())
		return
	}

	destPath := s.backupPath(serverID, body.BackupID)
	if err := os.MkdirAll(filepath.Dir(destPath), 0o755); err != nil {
		writeError(w, http.StatusInternalServerError, "preparing backup directory: "+err.Error())
		return
	}

	if err := backup.Create(workingDir, destPath); err != nil {
		writeError(w, http.StatusInternalServerError, "creating backup: "+err.Error())
		return
	}

	info, err := os.Stat(destPath)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "reading backup file info: "+err.Error())
		return
	}

	writeJSON(w, http.StatusCreated, backupResult{BackupID: body.BackupID, SizeBytes: info.Size()})
}

func (s *Server) handleBackupRestore(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")
	backupID := r.PathValue("backup_id")

	workingDir, err := s.env.WorkingDir(r.Context(), serverID)
	if err != nil {
		writeError(w, http.StatusBadGateway, "resolving working directory: "+err.Error())
		return
	}

	archivePath := s.backupPath(serverID, backupID)
	if _, err := os.Stat(archivePath); err != nil {
		writeError(w, http.StatusNotFound, "no such backup: "+err.Error())
		return
	}

	// Restoring into a running container's working directory while the
	// server process holds files open is the caller's problem to avoid —
	// this handler does not stop the server first. umbrella-core's
	// ServerService is expected to stop, restore, then (optionally)
	// restart, in that order — matching the same "the daemon executes,
	// the control plane sequences" split established since Phase 1.
	if err := backup.Restore(archivePath, workingDir); err != nil {
		writeError(w, http.StatusInternalServerError, "restoring backup: "+err.Error())
		return
	}

	writeJSON(w, http.StatusOK, map[string]bool{"restored": true})
}

func (s *Server) handleBackupDelete(w http.ResponseWriter, r *http.Request) {
	serverID := r.PathValue("id")
	backupID := r.PathValue("backup_id")

	archivePath := s.backupPath(serverID, backupID)
	if err := os.Remove(archivePath); err != nil {
		if os.IsNotExist(err) {
			writeError(w, http.StatusNotFound, "no such backup")
			return
		}
		writeError(w, http.StatusInternalServerError, err.Error())
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// --------------------------------------------------------------------------
// Response helpers
// --------------------------------------------------------------------------

func writeJSON(w http.ResponseWriter, status int, body interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(body)
}

type errorResponse struct {
	Error string `json:"error"`
}

func writeError(w http.ResponseWriter, status int, message string) {
	writeJSON(w, status, errorResponse{Error: message})
}
