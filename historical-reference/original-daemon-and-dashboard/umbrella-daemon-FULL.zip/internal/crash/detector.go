// Package crash decides whether a container's exit was a clean stop or a
// crash worth reporting/acting on, and classifies *why* — the distinction
// the Phase 4 automation engine's self-healing policy (restart / restore
// backup / escalate) needs, and what Phase 5's crash-root-cause-analysis
// capability will consume as its starting signal.
package crash

import "time"

// Reason classifies why a container stopped.
type Reason string

const (
	// ReasonCleanStop: the process exited 0 after an operator- or
	// scheduler-initiated stop — expected, not a crash.
	ReasonCleanStop Reason = "clean_stop"

	// ReasonNonZeroExit: the process exited on its own with a non-zero
	// code — a crash, but not one killed by an external signal or OOM.
	ReasonNonZeroExit Reason = "non_zero_exit"

	// ReasonOOMKilled: the kernel OOM-killed the process — a crash
	// specifically caused by exceeding its memory limit, distinguished
	// because the correct auto-response (raise the memory limit, or flag
	// a leak) differs from a generic crash's response.
	ReasonOOMKilled Reason = "oom_killed"

	// ReasonKilledBySignal: the process was terminated by a signal other
	// than what a graceful Stop sends — e.g. it was still running when a
	// hard Kill was issued after Stop's grace period expired.
	ReasonKilledBySignal Reason = "killed_by_signal"

	// ReasonUnknown: insufficient information to classify — reported
	// honestly as unknown rather than guessed at, since a wrong
	// classification would misdirect the self-healing policy.
	ReasonUnknown Reason = "unknown"
)

// ExitInfo is what the Environment layer knows about how a container
// stopped — deliberately small and Docker-shape-agnostic (see
// environment.ContainerState, which this is derived from) so this
// package's classification logic has no Docker dependency at all.
type ExitInfo struct {
	ExitCode int

	// OOMKilled is true if the runtime reports the kernel OOM-killed this
	// container's main process.
	OOMKilled bool

	// WasGracefulStopRequested is true if an operator/scheduler-initiated
	// Stop was in progress for this container when it exited — the single
	// piece of context that turns "process exited" into "this was
	// expected," which the raw exit code alone can't tell you (a
	// well-behaved server also exits 0 when it crashes into a handled
	// shutdown path).
	WasGracefulStopRequested bool

	// SignaledKill is true if the daemon itself issued a Kill (hard
	// termination) for this container, e.g. because Stop's grace period
	// expired.
	SignaledKill bool
}

// Report is the classified result.
type Report struct {
	ServerID  string
	Reason    Reason
	ExitCode  int
	OOMKilled bool
	// IsCrash is false only for ReasonCleanStop — every other Reason
	// represents a crash the self-healing/notification path should act on.
	IsCrash    bool
	OccurredAt time.Time
}

// Classify turns raw exit information into a Report. This is intentionally
// simple, ordered decision logic rather than a black box — each branch is
// individually testable and the ordering (OOM checked before generic
// non-zero-exit) is itself a documented decision, not an accident of
// switch-case ordering.
func Classify(serverID string, info ExitInfo, occurredAt time.Time) Report {
	report := Report{
		ServerID:   serverID,
		ExitCode:   info.ExitCode,
		OOMKilled:  info.OOMKilled,
		OccurredAt: occurredAt,
	}

	switch {
	case info.WasGracefulStopRequested && info.ExitCode == 0:
		report.Reason = ReasonCleanStop
		report.IsCrash = false

	case info.OOMKilled:
		report.Reason = ReasonOOMKilled
		report.IsCrash = true

	case info.SignaledKill:
		report.Reason = ReasonKilledBySignal
		report.IsCrash = true

	case info.ExitCode != 0:
		report.Reason = ReasonNonZeroExit
		report.IsCrash = true

	case info.ExitCode == 0 && !info.WasGracefulStopRequested:
		// Exited 0 with nobody having asked it to stop — treated as a
		// crash, not a clean stop: an unattended graceful exit (e.g. a
		// Minecraft server hitting `/stop` from an unmonitored source, or
		// exiting due to an unhandled condition it happens to catch
		// cleanly) is exactly the kind of "quietly went down" case the
		// self-healing/crash-notification path exists to catch. Silently
		// treating unexpected-but-zero exits as fine would create a class
		// of outage nobody gets alerted to.
		report.Reason = ReasonUnknown
		report.IsCrash = true

	default:
		report.Reason = ReasonUnknown
		report.IsCrash = true
	}

	return report
}
