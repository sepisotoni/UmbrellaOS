package crash

import (
	"testing"
	"time"
)

var now = time.Date(2026, 7, 6, 12, 0, 0, 0, time.UTC)

func TestClassifyCleanStop(t *testing.T) {
	info := ExitInfo{ExitCode: 0, WasGracefulStopRequested: true}
	r := Classify("srv-1", info, now)
	if r.Reason != ReasonCleanStop {
		t.Fatalf("expected ReasonCleanStop, got %s", r.Reason)
	}
	if r.IsCrash {
		t.Fatal("a requested, zero-exit stop must not be classified as a crash")
	}
}

func TestClassifyOOMKilledTakesPriorityOverExitCode(t *testing.T) {
	// Even if exit code happens to be 0 (some OOM killer / init interactions
	// can produce this), OOMKilled must win — it's the more specific and
	// more actionable signal.
	info := ExitInfo{ExitCode: 0, OOMKilled: true}
	r := Classify("srv-1", info, now)
	if r.Reason != ReasonOOMKilled {
		t.Fatalf("expected ReasonOOMKilled, got %s", r.Reason)
	}
	if !r.IsCrash {
		t.Fatal("an OOM kill must always be classified as a crash")
	}
}

func TestClassifyOOMKilledTakesPriorityOverGracefulStopFlag(t *testing.T) {
	// Even if a graceful stop happened to be in flight, an actual OOM kill
	// is not the graceful stop completing — it must still be reported.
	info := ExitInfo{ExitCode: 137, OOMKilled: true, WasGracefulStopRequested: true}
	r := Classify("srv-1", info, now)
	if r.Reason != ReasonOOMKilled {
		t.Fatalf("expected ReasonOOMKilled even with a graceful stop flag set, got %s", r.Reason)
	}
}

func TestClassifyKilledBySignal(t *testing.T) {
	info := ExitInfo{ExitCode: 137, SignaledKill: true}
	r := Classify("srv-1", info, now)
	if r.Reason != ReasonKilledBySignal {
		t.Fatalf("expected ReasonKilledBySignal, got %s", r.Reason)
	}
	if !r.IsCrash {
		t.Fatal("a hard kill must be classified as a crash")
	}
}

func TestClassifyNonZeroExit(t *testing.T) {
	info := ExitInfo{ExitCode: 1}
	r := Classify("srv-1", info, now)
	if r.Reason != ReasonNonZeroExit {
		t.Fatalf("expected ReasonNonZeroExit, got %s", r.Reason)
	}
	if !r.IsCrash {
		t.Fatal("a non-zero exit must be classified as a crash")
	}
}

func TestClassifyUnrequestedZeroExitIsTreatedAsCrash(t *testing.T) {
	// The important, easy-to-get-wrong case: exit code 0, but nobody asked
	// for a stop. This must NOT be silently treated as fine.
	info := ExitInfo{ExitCode: 0, WasGracefulStopRequested: false}
	r := Classify("srv-1", info, now)
	if !r.IsCrash {
		t.Fatal("an unrequested zero-exit must be treated as a crash, not silently accepted")
	}
	if r.Reason != ReasonUnknown {
		t.Fatalf("expected ReasonUnknown for an unrequested clean-looking exit, got %s", r.Reason)
	}
}

func TestReportCarriesInputFieldsThrough(t *testing.T) {
	info := ExitInfo{ExitCode: 42, OOMKilled: false}
	r := Classify("srv-42", info, now)
	if r.ServerID != "srv-42" {
		t.Fatalf("expected ServerID to be carried through, got %s", r.ServerID)
	}
	if r.ExitCode != 42 {
		t.Fatalf("expected ExitCode 42, got %d", r.ExitCode)
	}
	if r.OccurredAt != now {
		t.Fatalf("expected OccurredAt to be carried through, got %v", r.OccurredAt)
	}
}
