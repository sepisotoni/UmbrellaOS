package stats

import (
	"math"
	"testing"
)

func floatsClose(a, b, epsilon float64) bool {
	return math.Abs(a-b) <= epsilon
}

func TestCalculateCPUPercentTypicalCase(t *testing.T) {
	// Realistic deltas: container used 200ms of CPU time while the system
	// clock advanced 2000ms total, on a 4-core host -> container used 10%
	// of one core's worth of system time, scaled by 4 cores = 40%.
	c := CPUStats{
		TotalUsage:        1_200_000_000, // ns
		PreTotalUsage:     1_000_000_000,
		SystemCPUUsage:    22_000_000_000,
		PreSystemCPUUsage: 20_000_000_000,
		OnlineCPUs:        4,
	}
	got := CalculateCPUPercent(c)
	want := 40.0
	if !floatsClose(got, want, 0.001) {
		t.Fatalf("expected %.4f%%, got %.4f%%", want, got)
	}
}

func TestCalculateCPUPercentZeroOnFirstSample(t *testing.T) {
	// A container's very first stats sample has no meaningful "previous"
	// values — Docker reports these as zero, and dividing by a zero
	// systemDelta must not happen.
	c := CPUStats{
		TotalUsage:        500_000_000,
		PreTotalUsage:     0,
		SystemCPUUsage:    0,
		PreSystemCPUUsage: 0,
		OnlineCPUs:        2,
	}
	got := CalculateCPUPercent(c)
	if got != 0 {
		t.Fatalf("expected 0 on a zero systemDelta, got %v", got)
	}
}

func TestCalculateCPUPercentNegativeDeltaReturnsZero(t *testing.T) {
	// A counter reset (e.g. container restarted between samples with stale
	// precpu values) can produce a negative delta — must clamp to 0, not
	// return a negative percentage.
	c := CPUStats{
		TotalUsage:        100,
		PreTotalUsage:     500, // "previous" higher than "current"
		SystemCPUUsage:    10_000,
		PreSystemCPUUsage: 5_000,
		OnlineCPUs:        1,
	}
	got := CalculateCPUPercent(c)
	if got != 0 {
		t.Fatalf("expected 0 on negative cpuDelta, got %v", got)
	}
}

func TestCalculateCPUPercentDefaultsToOneCoreWhenOnlineCPUsUnset(t *testing.T) {
	// Some Docker API versions/cgroup drivers don't populate online_cpus;
	// treat that as 1 core rather than multiplying by zero and reporting
	// 0% regardless of actual usage.
	c := CPUStats{
		TotalUsage:        200,
		PreTotalUsage:     100,
		SystemCPUUsage:    2_000,
		PreSystemCPUUsage: 1_000,
		OnlineCPUs:        0,
	}
	got := CalculateCPUPercent(c)
	want := 10.0 // (100/1000) * 1 * 100
	if !floatsClose(got, want, 0.001) {
		t.Fatalf("expected %.4f%%, got %.4f%%", want, got)
	}
}

func TestCalculateMemoryUsedBytesSubtractsCache(t *testing.T) {
	m := MemoryStats{Usage: 500_000_000, CacheBytes: 150_000_000}
	got := CalculateMemoryUsedBytes(m)
	want := int64(350_000_000)
	if got != want {
		t.Fatalf("expected %d, got %d", want, got)
	}
}

func TestCalculateMemoryUsedBytesClampsToZero(t *testing.T) {
	// Pathological/misreported input where cache exceeds usage must not
	// produce a negative "used memory" value.
	m := MemoryStats{Usage: 100, CacheBytes: 500}
	got := CalculateMemoryUsedBytes(m)
	if got != 0 {
		t.Fatalf("expected clamped 0, got %d", got)
	}
}

func TestSumNetworkBytesAggregatesMultipleInterfaces(t *testing.T) {
	networks := map[string]NetworkStats{
		"eth0": {RxBytes: 1000, TxBytes: 500},
		"eth1": {RxBytes: 200, TxBytes: 100},
	}
	rx, tx := SumNetworkBytes(networks)
	if rx != 1200 {
		t.Fatalf("expected rx=1200, got %d", rx)
	}
	if tx != 600 {
		t.Fatalf("expected tx=600, got %d", tx)
	}
}

func TestSumNetworkBytesEmptyReturnsZero(t *testing.T) {
	rx, tx := SumNetworkBytes(map[string]NetworkStats{})
	if rx != 0 || tx != 0 {
		t.Fatalf("expected zero for both, got rx=%d tx=%d", rx, tx)
	}
}
