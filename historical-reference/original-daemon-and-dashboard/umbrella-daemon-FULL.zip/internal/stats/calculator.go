// Package stats computes normalized resource-usage snapshots from a
// runtime's raw stats payload. Kept as pure functions operating on plain
// structs (not on a live Docker client) specifically so this math — which
// is the part most worth getting right and easiest to get subtly wrong —
// is unit-testable without a running container or daemon.
package stats

// RawSample is the subset of Docker's `/containers/{id}/stats` JSON
// response this package needs. Field names/shapes mirror Docker's actual
// API (see moby/moby api/types/container.StatsResponse) — deliberately not
// the full upstream struct, so this package doesn't take a dependency on
// docker/docker just to do arithmetic on a handful of fields.
type RawSample struct {
	CPU      CPUStats
	Memory   MemoryStats
	Networks map[string]NetworkStats
}

type CPUStats struct {
	TotalUsage        uint64 // cpu_stats.cpu_usage.total_usage
	SystemCPUUsage    uint64 // cpu_stats.system_cpu_usage
	OnlineCPUs        uint32 // cpu_stats.online_cpus
	PreTotalUsage     uint64 // precpu_stats.cpu_usage.total_usage (previous sample)
	PreSystemCPUUsage uint64 // precpu_stats.system_cpu_usage (previous sample)
}

type MemoryStats struct {
	Usage      uint64 // memory_stats.usage
	Limit      uint64 // memory_stats.limit
	CacheBytes uint64 // memory_stats.stats.cache — subtracted, see CalculateMemoryUsedBytes
}

type NetworkStats struct {
	RxBytes uint64
	TxBytes uint64
}

// CalculateCPUPercent replicates the standard Docker CLI algorithm for
// `docker stats`' CPU % column: the fraction of total available CPU time
// consumed by this container since the previous sample, scaled by the
// number of online CPUs so multi-core usage can exceed 100%.
//
// Returns 0 if either delta is non-positive (no elapsed CPU time to
// measure yet — the container's first sample, or a clock/counter reset)
// rather than dividing by zero or returning a misleading negative number.
func CalculateCPUPercent(c CPUStats) float64 {
	cpuDelta := float64(c.TotalUsage) - float64(c.PreTotalUsage)
	systemDelta := float64(c.SystemCPUUsage) - float64(c.PreSystemCPUUsage)

	if cpuDelta <= 0 || systemDelta <= 0 {
		return 0
	}

	onlineCPUs := float64(c.OnlineCPUs)
	if onlineCPUs == 0 {
		onlineCPUs = 1
	}

	return (cpuDelta / systemDelta) * onlineCPUs * 100.0
}

// CalculateMemoryUsedBytes returns "actual" memory usage, i.e. usage minus
// page cache. Docker's raw `memory_stats.usage` includes page cache pages
// the kernel would reclaim under pressure before OOM-killing anything —
// reporting it unadjusted systematically overstates a server's real memory
// pressure (this is the same correction `docker stats` itself applies, not
// an UmbrellaOS-specific heuristic).
func CalculateMemoryUsedBytes(m MemoryStats) int64 {
	used := int64(m.Usage) - int64(m.CacheBytes)
	if used < 0 {
		return 0
	}
	return used
}

// SumNetworkBytes aggregates per-interface network counters (a container
// can have more than one, e.g. eth0 + a loopback) into total rx/tx.
func SumNetworkBytes(networks map[string]NetworkStats) (rx int64, tx int64) {
	for _, n := range networks {
		rx += int64(n.RxBytes)
		tx += int64(n.TxBytes)
	}
	return rx, tx
}
