package backup

import (
	"archive/tar"
	"compress/gzip"
	"os"
	"path/filepath"
	"testing"
)

func writeFile(t *testing.T, path string, content string) {
	t.Helper()
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatalf("setup: %v", err)
	}
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("setup: %v", err)
	}
}

func TestCreateAndRestoreRoundTrip(t *testing.T) {
	source := t.TempDir()
	writeFile(t, filepath.Join(source, "server.properties"), "motd=hello")
	writeFile(t, filepath.Join(source, "plugins", "config.yml"), "key: value")
	writeFile(t, filepath.Join(source, "world", "level.dat"), "fake-nbt-data")

	archivePath := filepath.Join(t.TempDir(), "backup.tar.gz")
	if err := Create(source, archivePath); err != nil {
		t.Fatalf("Create failed: %v", err)
	}

	if info, err := os.Stat(archivePath); err != nil || info.Size() == 0 {
		t.Fatalf("expected a non-empty archive file, err=%v", err)
	}

	dest := t.TempDir()
	if err := Restore(archivePath, dest); err != nil {
		t.Fatalf("Restore failed: %v", err)
	}

	got, err := os.ReadFile(filepath.Join(dest, "server.properties"))
	if err != nil || string(got) != "motd=hello" {
		t.Fatalf("expected server.properties to round-trip, got %q, err=%v", got, err)
	}
	got, err = os.ReadFile(filepath.Join(dest, "plugins", "config.yml"))
	if err != nil || string(got) != "key: value" {
		t.Fatalf("expected plugins/config.yml to round-trip, got %q, err=%v", got, err)
	}
	got, err = os.ReadFile(filepath.Join(dest, "world", "level.dat"))
	if err != nil || string(got) != "fake-nbt-data" {
		t.Fatalf("expected world/level.dat to round-trip, got %q, err=%v", got, err)
	}
}

func TestCreateFailsOnNonexistentSource(t *testing.T) {
	archivePath := filepath.Join(t.TempDir(), "backup.tar.gz")
	err := Create("/does/not/exist/at/all", archivePath)
	if err == nil {
		t.Fatal("expected an error for a nonexistent source directory")
	}
}

func TestRestoreFailsIfDestinationDoesNotExist(t *testing.T) {
	source := t.TempDir()
	writeFile(t, filepath.Join(source, "f.txt"), "x")
	archivePath := filepath.Join(t.TempDir(), "backup.tar.gz")
	Create(source, archivePath)

	err := Restore(archivePath, "/does/not/exist/at/all")
	if err == nil {
		t.Fatal("expected an error restoring into a nonexistent destination")
	}
}

func TestRestoreFailsOnCorruptArchive(t *testing.T) {
	badArchive := filepath.Join(t.TempDir(), "not-really-gzip.tar.gz")
	os.WriteFile(badArchive, []byte("this is not a gzip file"), 0o644)

	err := Restore(badArchive, t.TempDir())
	if err == nil {
		t.Fatal("expected an error restoring a corrupt archive")
	}
}

func TestSymlinksAreNotFollowedIntoArchive(t *testing.T) {
	source := t.TempDir()
	writeFile(t, filepath.Join(source, "real.txt"), "real content")

	outsideDir := t.TempDir()
	writeFile(t, filepath.Join(outsideDir, "secret.txt"), "outside secret")

	symlinkPath := filepath.Join(source, "escape-link")
	if err := os.Symlink(outsideDir, symlinkPath); err != nil {
		t.Skipf("symlinks not supported in this test environment: %v", err)
	}

	archivePath := filepath.Join(t.TempDir(), "backup.tar.gz")
	if err := Create(source, archivePath); err != nil {
		t.Fatalf("Create failed: %v", err)
	}

	dest := t.TempDir()
	if err := Restore(archivePath, dest); err != nil {
		t.Fatalf("Restore failed: %v", err)
	}

	if _, err := os.Stat(filepath.Join(dest, "escape-link")); err == nil {
		t.Fatal("expected the symlink to not have been archived/restored at all")
	}
	if _, err := os.Stat(filepath.Join(dest, "real.txt")); err != nil {
		t.Fatal("expected the real, non-symlink file to still have round-tripped")
	}
}

// --------------------------------------------------------------------------
// Security: tar-slip (a maliciously crafted archive escaping the restore
// destination via ".." path segments) — a real, well-known vulnerability
// class for any code that extracts tar archives without validating entry
// paths. This constructs an actual malicious archive by hand, not just a
// name that looks suspicious, and proves Restore refuses to extract it.
// --------------------------------------------------------------------------

func writeMaliciousArchive(t *testing.T, archivePath string, entryName string, content string) {
	t.Helper()
	f, err := os.Create(archivePath)
	if err != nil {
		t.Fatalf("setup: %v", err)
	}
	defer f.Close()

	gz := gzip.NewWriter(f)
	defer gz.Close()
	tw := tar.NewWriter(gz)
	defer tw.Close()

	header := &tar.Header{
		Name: entryName,
		Mode: 0o644,
		Size: int64(len(content)),
	}
	if err := tw.WriteHeader(header); err != nil {
		t.Fatalf("setup: %v", err)
	}
	if _, err := tw.Write([]byte(content)); err != nil {
		t.Fatalf("setup: %v", err)
	}
}

func TestRestoreRejectsTarSlipAttack(t *testing.T) {
	maliciousArchive := filepath.Join(t.TempDir(), "evil.tar.gz")
	writeMaliciousArchive(t, maliciousArchive, "../../../../tmp/pwned-by-tarslip.txt", "malicious payload")

	dest := t.TempDir()
	err := Restore(maliciousArchive, dest)
	if err == nil {
		t.Fatal("expected Restore to reject an archive entry escaping the destination via '..'")
	}

	// Confirm the payload was NOT written anywhere on disk outside dest —
	// not just that Restore returned an error, but that it actually didn't
	// extract the file before failing.
	if _, statErr := os.Stat("/tmp/pwned-by-tarslip.txt"); statErr == nil {
		os.Remove("/tmp/pwned-by-tarslip.txt")
		t.Fatal("SECURITY FAILURE: the tar-slip payload was actually written to disk")
	}
}

func TestRestoreContainsAbsoluteLookingPathWithinDestination(t *testing.T) {
	// An archive entry named like an absolute path (e.g. "/etc/cron.d/evil")
	// is NOT a tar-slip vector under Go's filepath.Join semantics — unlike
	// some other languages' path-join functions, Join here never discards
	// the base when the second argument looks absolute; it's simply
	// treated as another path segment and safely contained. Verified
	// empirically (not assumed) before writing this test: a first version
	// of this test asserted Restore should *reject* such an entry, and
	// failed — because the code was already safe and the test's
	// expectation was wrong, not the implementation. Corrected to assert
	// what's actually true: the entry lands safely inside the destination.
	maliciousArchive := filepath.Join(t.TempDir(), "abs-looking.tar.gz")
	writeMaliciousArchive(t, maliciousArchive, "/etc/cron.d/evil", "not actually malicious once contained")

	dest := t.TempDir()
	if err := Restore(maliciousArchive, dest); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	containedPath := filepath.Join(dest, "etc", "cron.d", "evil")
	if _, err := os.Stat(containedPath); err != nil {
		t.Fatalf("expected the entry to be safely contained at %q, got err=%v", containedPath, err)
	}
	if _, err := os.Stat("/etc/cron.d/evil"); err == nil {
		t.Fatal("SECURITY FAILURE: the entry was written to the real /etc/cron.d/evil")
	}
}
