// Package backup archives and restores a server's working directory as a
// gzip-compressed tar file. This is the daemon-side execution half of
// Phase 4's backup capability — umbrella-core owns backup *metadata* and
// *scheduling* (which backup exists, when it was taken, when the next one
// runs); this package only knows how to actually produce and consume the
// archive bytes on the host where the data lives.
package backup

import (
	"archive/tar"
	"compress/gzip"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
)

// Create archives every file under sourceDir into a new gzip-compressed
// tar file at destPath. destPath's parent directory must already exist.
func Create(sourceDir, destPath string) (err error) {
	absSource, err := filepath.Abs(sourceDir)
	if err != nil {
		return fmt.Errorf("backup: resolving source %q: %w", sourceDir, err)
	}

	out, err := os.Create(destPath)
	if err != nil {
		return fmt.Errorf("backup: creating archive file %q: %w", destPath, err)
	}
	defer func() {
		closeErr := out.Close()
		if err == nil {
			err = closeErr
		}
	}()

	gz := gzip.NewWriter(out)
	defer func() {
		closeErr := gz.Close()
		if err == nil {
			err = closeErr
		}
	}()

	tw := tar.NewWriter(gz)
	defer func() {
		closeErr := tw.Close()
		if err == nil {
			err = closeErr
		}
	}()

	walkErr := filepath.Walk(absSource, func(path string, info os.FileInfo, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}

		relPath, err := filepath.Rel(absSource, path)
		if err != nil {
			return err
		}
		if relPath == "." {
			return nil // don't write an entry for the root itself
		}

		// Only regular files and directories are archived — symlinks
		// inside a server's working directory are not followed into the
		// archive, matching the same "don't silently escape the sandbox"
		// posture internal/files takes for the same underlying directory.
		if info.Mode()&os.ModeSymlink != 0 {
			return nil
		}

		header, err := tar.FileInfoHeader(info, "")
		if err != nil {
			return err
		}
		header.Name = filepath.ToSlash(relPath)
		if info.IsDir() {
			header.Name += "/"
		}

		if err := tw.WriteHeader(header); err != nil {
			return err
		}
		if info.IsDir() {
			return nil
		}

		f, err := os.Open(path)
		if err != nil {
			return err
		}
		defer f.Close()

		_, err = io.Copy(tw, f)
		return err
	})
	if walkErr != nil {
		return fmt.Errorf("backup: archiving %q: %w", sourceDir, walkErr)
	}

	return nil
}

// Restore extracts the gzip-compressed tar file at archivePath into
// destDir, which must already exist. Every entry's path is validated to
// resolve inside destDir before being written — a maliciously (or simply
// corrupted) crafted archive containing a path like "../../etc/cron.d/x"
// (a "tar-slip" / "zip-slip" attack) is rejected rather than followed,
// exactly the same class of defense internal/files applies to its own
// sandbox for the same underlying directory.
func Restore(archivePath, destDir string) (err error) {
	absDest, err := filepath.Abs(destDir)
	if err != nil {
		return fmt.Errorf("backup: resolving destination %q: %w", destDir, err)
	}
	if info, statErr := os.Stat(absDest); statErr != nil || !info.IsDir() {
		return fmt.Errorf("backup: destination %q must already exist and be a directory", destDir)
	}

	in, err := os.Open(archivePath)
	if err != nil {
		return fmt.Errorf("backup: opening archive %q: %w", archivePath, err)
	}
	defer in.Close()

	gz, err := gzip.NewReader(in)
	if err != nil {
		return fmt.Errorf("backup: reading gzip stream: %w", err)
	}
	defer gz.Close()

	tr := tar.NewReader(gz)
	destPrefix := absDest + string(filepath.Separator)

	for {
		header, err := tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return fmt.Errorf("backup: reading tar entry: %w", err)
		}

		targetPath := filepath.Join(absDest, filepath.FromSlash(header.Name))
		cleaned := filepath.Clean(targetPath)
		if cleaned != absDest && !strings.HasPrefix(cleaned, destPrefix) {
			return fmt.Errorf("backup: archive entry %q escapes the restore destination — refusing to extract", header.Name)
		}

		switch header.Typeflag {
		case tar.TypeDir:
			if err := os.MkdirAll(cleaned, 0o755); err != nil {
				return fmt.Errorf("backup: creating directory %q: %w", header.Name, err)
			}
		case tar.TypeReg:
			if err := os.MkdirAll(filepath.Dir(cleaned), 0o755); err != nil {
				return fmt.Errorf("backup: preparing directory for %q: %w", header.Name, err)
			}
			if err := extractFile(tr, cleaned, os.FileMode(header.Mode)); err != nil {
				return fmt.Errorf("backup: extracting %q: %w", header.Name, err)
			}
		default:
			// Symlinks, device files, etc. from the archive are skipped —
			// backups produced by Create never contain them (see Create's
			// symlink skip above); an archive that does contain one is
			// either hand-crafted or from an incompatible source, and
			// silently extracting it is not this function's job.
			continue
		}
	}

	return nil
}

func extractFile(r io.Reader, destPath string, mode os.FileMode) (err error) {
	f, err := os.OpenFile(destPath, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, mode)
	if err != nil {
		return err
	}
	defer func() {
		closeErr := f.Close()
		if err == nil {
			err = closeErr
		}
	}()
	_, err = io.Copy(f, r)
	return err
}
