// Package ringbuffer provides a fixed-capacity, thread-safe byte ring buffer
// used to hold console scrollback for a running server — enough history
// that a dashboard/CLI client attaching mid-session sees recent output
// immediately, without the daemon needing to retain a server's entire
// lifetime of console output in memory.
package ringbuffer

import "sync"

// Buffer is a fixed-capacity ring buffer of bytes. Writes beyond capacity
// overwrite the oldest retained data — this is scrollback, not a durable
// log; durable log retention is Phase 9's log-aggregation concern, not
// this buffer's job.
type Buffer struct {
	mu       sync.Mutex
	data     []byte
	capacity int
	start    int // index of the oldest byte in data
	length   int // number of valid bytes currently stored
}

// New creates a Buffer holding at most capacity bytes. Panics on a
// non-positive capacity — a zero-or-negative-capacity scrollback buffer is
// a caller bug, not a runtime condition to handle gracefully.
func New(capacity int) *Buffer {
	if capacity <= 0 {
		panic("ringbuffer: capacity must be positive")
	}
	return &Buffer{
		data:     make([]byte, capacity),
		capacity: capacity,
	}
}

// Write appends p to the buffer, discarding the oldest bytes first if p
// would exceed capacity. Always returns len(p), nil — a ring buffer cannot
// fail to "accept" a write, only choose what it evicts, matching the
// io.Writer contract callers (console hub) expect.
func (b *Buffer) Write(p []byte) (int, error) {
	b.mu.Lock()
	defer b.mu.Unlock()

	if len(p) >= b.capacity {
		// The new write alone fills or exceeds capacity: keep only its
		// tail, buffer holds exactly the most recent `capacity` bytes.
		copy(b.data, p[len(p)-b.capacity:])
		b.start = 0
		b.length = b.capacity
		return len(p), nil
	}

	// Write p starting right after the current content, wrapping as needed.
	writePos := (b.start + b.length) % b.capacity
	n := copy(b.data[writePos:], p)
	if n < len(p) {
		copy(b.data, p[n:])
	}

	newLength := b.length + len(p)
	if newLength > b.capacity {
		// Evict the oldest (newLength - capacity) bytes by advancing start.
		overflow := newLength - b.capacity
		b.start = (b.start + overflow) % b.capacity
		newLength = b.capacity
	}
	b.length = newLength

	return len(p), nil
}

// Bytes returns a copy of the buffer's current contents, oldest byte first.
// A copy, not a slice into internal state, so callers can't observe
// concurrent writes mutating data out from under them mid-read.
func (b *Buffer) Bytes() []byte {
	b.mu.Lock()
	defer b.mu.Unlock()

	out := make([]byte, b.length)
	if b.length == 0 {
		return out
	}
	firstPartLen := b.capacity - b.start
	if firstPartLen >= b.length {
		copy(out, b.data[b.start:b.start+b.length])
	} else {
		copy(out, b.data[b.start:])
		copy(out[firstPartLen:], b.data[:b.length-firstPartLen])
	}
	return out
}

// Len returns the number of bytes currently stored (never exceeds capacity).
func (b *Buffer) Len() int {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.length
}

// Capacity returns the buffer's fixed maximum size.
func (b *Buffer) Capacity() int {
	return b.capacity // immutable after New, no lock needed
}
