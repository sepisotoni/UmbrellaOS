package ringbuffer

import (
	"bytes"
	"sync"
	"testing"
)

func TestNewPanicsOnNonPositiveCapacity(t *testing.T) {
	defer func() {
		if recover() == nil {
			t.Fatal("expected panic for non-positive capacity, got none")
		}
	}()
	New(0)
}

func TestWriteWithinCapacity(t *testing.T) {
	b := New(10)
	n, err := b.Write([]byte("hello"))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if n != 5 {
		t.Fatalf("expected 5 bytes written, got %d", n)
	}
	if got := b.Bytes(); !bytes.Equal(got, []byte("hello")) {
		t.Fatalf("expected %q, got %q", "hello", got)
	}
	if b.Len() != 5 {
		t.Fatalf("expected length 5, got %d", b.Len())
	}
}

func TestWriteEvictsOldestWhenOverCapacity(t *testing.T) {
	b := New(5)
	b.Write([]byte("hello"))
	b.Write([]byte("world")) // now over capacity by 5; should evict all of "hello"

	got := b.Bytes()
	if !bytes.Equal(got, []byte("world")) {
		t.Fatalf("expected %q, got %q", "world", got)
	}
}

func TestWritePartialEviction(t *testing.T) {
	b := New(10)
	b.Write([]byte("0123456789")) // exactly fills capacity
	b.Write([]byte("AB"))         // should evict the oldest 2 bytes ("01")

	got := b.Bytes()
	want := []byte("23456789AB")
	if !bytes.Equal(got, want) {
		t.Fatalf("expected %q, got %q", want, got)
	}
	if b.Len() != 10 {
		t.Fatalf("expected length to remain at capacity 10, got %d", b.Len())
	}
}

func TestWriteLargerThanCapacityKeepsOnlyTail(t *testing.T) {
	b := New(4)
	n, err := b.Write([]byte("abcdefgh")) // 8 bytes into a 4-byte buffer
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if n != 8 {
		t.Fatalf("Write must report full input length written, got %d", n)
	}
	got := b.Bytes()
	if !bytes.Equal(got, []byte("efgh")) {
		t.Fatalf("expected only the tail %q, got %q", "efgh", got)
	}
}

func TestWrapAroundAcrossMultipleWrites(t *testing.T) {
	b := New(6)
	b.Write([]byte("abc"))
	b.Write([]byte("def")) // buffer now exactly "abcdef", start=0
	b.Write([]byte("gh"))  // evict "ab", buffer now "cdefgh"

	got := b.Bytes()
	want := []byte("cdefgh")
	if !bytes.Equal(got, want) {
		t.Fatalf("expected %q, got %q", want, got)
	}

	b.Write([]byte("ij")) // evict "cd", buffer now "efghij"
	got = b.Bytes()
	want = []byte("efghij")
	if !bytes.Equal(got, want) {
		t.Fatalf("expected %q, got %q", want, got)
	}
}

func TestEmptyBufferReturnsEmptySlice(t *testing.T) {
	b := New(8)
	got := b.Bytes()
	if len(got) != 0 {
		t.Fatalf("expected empty slice, got %q", got)
	}
	if b.Len() != 0 {
		t.Fatalf("expected length 0, got %d", b.Len())
	}
}

func TestBytesReturnsCopyNotInternalSlice(t *testing.T) {
	b := New(8)
	b.Write([]byte("hello"))
	got := b.Bytes()
	got[0] = 'X' // mutate the returned copy

	again := b.Bytes()
	if bytes.Equal(again, got) {
		t.Fatal("Bytes() must return a copy — mutating the result must not affect the buffer")
	}
	if !bytes.Equal(again, []byte("hello")) {
		t.Fatalf("internal state must be unaffected by mutating a prior Bytes() result, got %q", again)
	}
}

func TestConcurrentWritesDoNotRace(t *testing.T) {
	b := New(1024)
	var wg sync.WaitGroup
	for i := 0; i < 50; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			b.Write([]byte("x"))
		}()
	}
	wg.Wait()
	// Not asserting exact content (write order across goroutines is
	// unspecified) — the point of this test is that it must pass under
	// `go test -race` without a data race, and Len() must never exceed
	// capacity regardless of interleaving.
	if b.Len() > b.Capacity() {
		t.Fatalf("length %d exceeded capacity %d", b.Len(), b.Capacity())
	}
}

func TestCapacityIsImmutable(t *testing.T) {
	b := New(42)
	if b.Capacity() != 42 {
		t.Fatalf("expected capacity 42, got %d", b.Capacity())
	}
	b.Write([]byte("some data"))
	if b.Capacity() != 42 {
		t.Fatalf("capacity must not change after writes, got %d", b.Capacity())
	}
}
