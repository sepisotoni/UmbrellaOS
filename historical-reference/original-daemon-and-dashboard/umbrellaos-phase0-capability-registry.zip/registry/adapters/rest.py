"""
registry/adapters/rest.py — Generic REST adapter over the Capability Registry.

Every registered capability is reachable at
`POST /api/v1/capabilities/{name}/invoke` with zero per-capability route
code — this is the concrete mechanism behind "a new capability is
automatically available over REST," not an aspiration.

Trade-off, stated plainly rather than glossed over: this is an RPC-style
invoke endpoint (`POST .../{name}/invoke`), not a resource-styled REST path
(`POST /servers/{id}/restart`). Resource-styled path aliases can be layered
on top later — a thin route that calls `registry.call("hosting.server.restart", ...)`
under a prettier URL — without changing the underlying contract. That
ergonomic layer is intentionally deferred rather than built speculatively
before there's a second adapter (Phase 5's AI Tool Registry) to validate the
schema-driven approach against.
"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from api.middleware.session import require_admin_key_or_session
from database import get_db
from models import User
from registry.context import CallContext
from registry.registry import registry

router = APIRouter(prefix="/api/v1/capabilities", tags=["capabilities"])


class CapabilitySummary(BaseModel):
    name: str
    summary: str
    required_permission: str | None
    destructive: bool
    reversible: bool
    audited: bool
    params_schema: dict[str, Any]


@router.get("")
async def list_capabilities() -> list[CapabilitySummary]:
    """
    List every registered capability and its parameter schema. This is the
    same introspection the CLI adapter uses to build its command tree and
    that (Phase 5) the AI Tool Registry will use to build tool definitions —
    one source of truth for "what can UmbrellaOS do," not a hand-maintained
    list per adapter.
    """
    return [
        CapabilitySummary(
            name=spec.name,
            summary=spec.summary,
            required_permission=spec.required_permission,
            destructive=spec.destructive,
            reversible=spec.reversible,
            audited=spec.audited,
            params_schema=spec.params_model.model_json_schema(),
        )
        for spec in registry.list()
    ]


@router.post("/{name}/invoke")
async def invoke_capability(
    name: str,
    payload: dict[str, Any] | None = Body(default=None),
    auth: User | str = Depends(require_admin_key_or_session),
    db: AsyncSession = Depends(get_db),
) -> Any:
    """
    Invoke any registered capability by name. This single route is the
    entire REST surface for every current and future capability — there is
    no separate route per domain to write or maintain.

    Authorization and audit logging happen inside `registry.call()`, not
    here — this route's only job is translating an authenticated FastAPI
    request into a CallContext and a raw params dict.
    """
    ctx = await CallContext.from_web_auth(auth, db, source="rest")
    result = await registry.call(name, ctx, payload or {})
    return result.model_dump(mode="json") if isinstance(result, BaseModel) else result
