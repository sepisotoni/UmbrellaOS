"""
registry/adapters/cli.py — Typer-based CLI adapter over the Capability Registry.

Every capability's dot-separated name becomes a nested CLI command —
`platform.audit.search` -> `umbrella platform audit search` — generated from
the registry at build time, not hand-written per command. Adding a new
capability never requires touching this file.

Authentication: the CLI runs with the same admin-key bootstrap tier REST
uses for the plugin/dashboard bootstrap case (`settings.admin_key`). Phase 3
(Identity/RBAC/SSO) adds first-class CLI login (`umbrella auth login`)
producing a real session, at which point the CLI gains per-user identity
instead of always running as the superuser tier — deliberately not built
here, since Phase 0 has no session/login capability yet to build it against.

Design note: `build_cli()` constructs a brand new `typer.Typer()` tree on
every call rather than mutating a shared module-level app. This matters
beyond style — a CLI adapter that accumulated state across calls would make
it impossible to build two independent CLI trees in the same process (e.g.
one per test, or a future per-tenant CLI variant), and would silently grow
duplicate command groups if ever rebuilt at runtime (a hot-reload dev mode,
for instance). Building fresh every time is what makes `build_cli` safe to
call more than once.
"""
from __future__ import annotations

import asyncio
import json
from typing import Any

import typer

from config import get_settings
from database import AsyncSessionLocal
from registry.context import CallContext
from registry.registry import CapabilityRegistry, registry
from registry.spec import CapabilitySpec


async def _invoke(spec: CapabilitySpec, params_json: str) -> Any:
    settings = get_settings()
    async with AsyncSessionLocal() as db:
        ctx = await CallContext.from_web_auth(settings.admin_key, db, source="cli")
        params: dict[str, Any] = json.loads(params_json) if params_json.strip() else {}
        result = await registry.call(spec.name, ctx, params)
        await db.commit()
        return result


def _make_command(spec: CapabilitySpec):
    def _command(
        params: str = typer.Option(
            "{}",
            "--params",
            "-p",
            help=f"JSON object matching this capability's schema. "
            f"Run 'umbrella list' to see every capability's name.",
        ),
    ) -> None:
        try:
            result = asyncio.run(_invoke(spec, params))
        except Exception as exc:  # noqa: BLE001 - CLI boundary: surface any failure to the operator
            typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
            raise typer.Exit(code=1) from exc

        if hasattr(result, "model_dump"):
            typer.echo(json.dumps(result.model_dump(mode="json"), indent=2))
        else:
            typer.echo(json.dumps(result, indent=2, default=str))

    _command.__doc__ = spec.summary
    return _command


def build_cli(source_registry: CapabilityRegistry = registry) -> typer.Typer:
    """
    Build a complete, independent Typer app with one command per capability
    currently in `source_registry`, nested by dot-segment. Safe to call more
    than once (see module docstring) — each call returns a fresh tree.
    """
    cli_app = typer.Typer(
        name="umbrella",
        help="UmbrellaOS command-line interface — every command below calls "
        "the exact same capability the Dashboard and API use.",
        no_args_is_help=True,
    )
    groups: dict[str, typer.Typer] = {}

    def _get_or_create_group(path: list[str]) -> typer.Typer:
        current = cli_app
        prefix = ""
        for segment in path:
            prefix = f"{prefix}.{segment}" if prefix else segment
            if prefix not in groups:
                sub_app = typer.Typer(help=f"'{prefix}' commands")
                groups[prefix] = sub_app
                current.add_typer(sub_app, name=segment)
            current = groups[prefix]
        return current

    for spec in source_registry.list():
        *group_path, leaf = spec.name.split(".")
        parent = _get_or_create_group(group_path)
        parent.command(name=leaf, help=spec.summary)(_make_command(spec))

    @cli_app.command(name="list")
    def list_capabilities() -> None:
        """List every registered capability (equivalent to GET /api/v1/capabilities)."""
        for spec in source_registry.list():
            flags = []
            if spec.destructive:
                flags.append("destructive")
            if not spec.reversible:
                flags.append("irreversible")
            suffix = f" [{', '.join(flags)}]" if flags else ""
            typer.echo(f"{spec.name}{suffix} — {spec.summary}")

    return cli_app
