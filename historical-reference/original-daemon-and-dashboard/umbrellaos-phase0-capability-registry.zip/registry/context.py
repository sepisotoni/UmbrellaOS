"""
registry/context.py — CallContext: identity of whoever is invoking a capability.

Every adapter (REST, CLI, Discord, AI) builds exactly one CallContext before
calling `CapabilityRegistry.call()`. It is the single object that answers
"who is calling, what can they do, and where did this call originate" —
capability handlers receive one instead of each re-deriving identity from a
FastAPI `Request`, a Discord interaction, or a CLI invocation differently.

Design invariant: an AI-initiated call (Phase 5) builds its CallContext from
the *user the AI is acting on behalf of*, never from a separate elevated
identity. This is what makes "the AI cannot exceed the permissions of the
human it's acting for" true by construction — there is no code path that
grants a CallContext more access than the underlying actor actually has.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Literal

from sqlalchemy.ext.asyncio import AsyncSession

from models import User
from services.permission_resolution import resolve_user_permissions

# Where the call originated. Extended in later phases as more adapters land
# (Phase 5 adds "ai", Phase 6 formalizes "discord" beyond this placeholder).
Source = Literal["rest", "cli", "discord", "ai", "system"]


@dataclass
class CallContext:
    # Stable identifier for the actor. For a staff user this is their
    # Discord ID (matches models.user.User.discord_id); for the admin-key
    # bootstrap tier it's the literal string "admin-key".
    actor_id: str

    # Matches the AuditLog.actor_type convention exactly (staff | plugin |
    # bot | system | ai) so capability audit rows are queryable the same way
    # as every audit row written before Phase 0 existed.
    actor_type: str

    # Which adapter is making this call.
    source: Source

    # The actor's resolved permission keys. Empty for a superuser context —
    # is_superuser is checked first, so an empty set here never means
    # "denied" for the admin-key tier.
    permissions: set[str]

    # True only for the X-Admin-Key / plugin-bootstrap tier. Mirrors the
    # existing "admin key bypasses all permission checks" behavior in
    # api/dependencies/permissions.py — the registry does not introduce a
    # second, different notion of "superuser".
    is_superuser: bool

    # Request-scoped DB session. The registry's audit write and the
    # capability handler's own queries share this session/transaction —
    # a capability's side effects and its audit row commit together.
    db: AsyncSession

    # Correlation ID for this specific call, useful for tracing a single
    # invocation across logs once Phase 9's OpenTelemetry integration lands.
    request_id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def has_permission(self, permission: str | None) -> bool:
        """
        A permission requirement of None means "any authenticated actor may
        call this" — not "no check is performed." Authentication itself
        already happened before a CallContext could be constructed at all.
        """
        if self.is_superuser:
            return True
        if permission is None:
            return True
        return permission in self.permissions

    @classmethod
    async def from_web_auth(
        cls,
        auth: User | str,
        db: AsyncSession,
        source: Source = "rest",
    ) -> "CallContext":
        """
        Build a CallContext from the existing `require_admin_key_or_session`
        dependency's return value — a `User` for a session-authenticated
        staff member, or the raw admin-key string for the bootstrap tier.

        Deliberately reuses that exact dependency's output type rather than
        introducing a second authentication concept: Phase 0 does not change
        who is allowed to authenticate, only how an authenticated call is
        subsequently routed to business logic.
        """
        if isinstance(auth, str):
            return cls(
                actor_id="admin-key",
                actor_type="system",
                source=source,
                permissions=set(),
                is_superuser=True,
                db=db,
            )

        permissions = await resolve_user_permissions(auth, db)
        return cls(
            actor_id=auth.discord_id,
            actor_type="staff",
            source=source,
            permissions=permissions,
            is_superuser=False,
            db=db,
        )
