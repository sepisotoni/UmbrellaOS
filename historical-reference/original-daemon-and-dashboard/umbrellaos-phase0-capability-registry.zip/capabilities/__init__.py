"""
capabilities — import every capability module here for its registration
side effect, exactly mirroring the existing `models/__init__.py` pattern of
importing every model module so Alembic can discover them.

Order does not matter for capabilities (unlike models, there's no
inheritance/foreign-key dependency between capability modules), but new
domains should still add their module import here so the app's startup
(`main.py`) has a single place that guarantees every capability is
registered before the first request/CLI command is handled.
"""
from . import system  # noqa: F401

__all__ = ["system"]
