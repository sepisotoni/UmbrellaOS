// Package environment defines UmbrellaOS's runtime abstraction: the contract
// every container/process runtime (Docker today, potentially Kubernetes or
// another driver later) must satisfy to run a game server under
// umbrella-daemon.
//
// This interface exists specifically so the Docker implementation
// (docker.go) is one implementation, not the only possible one — per the
// ecosystem architecture decision to keep the daemon's runtime pluggable
// without committing to Kubernetes now (see docs/adr/0002). Every other
// package in this daemon (console streaming, stats reporting, crash
// detection) depends on this interface, never on Docker types directly.
package environment

import (
	"context"
	"io"
	"time"
)

// ContainerSpec is everything needed to create a server's container,
// runtime-agnostic. It deliberately does not expose Docker-specific
// concepts (no raw HostConfig, no raw Mounts) — a future non-Docker
// Environment implementation must be able to satisfy this same spec.
type ContainerSpec struct {
	// ServerID is UmbrellaOS's own identifier for the server this container
	// runs, not the runtime's container ID — the two are related via
	// ContainerState.RuntimeID, not conflated.
	ServerID string

	// Image is the fully-qualified image reference to run
	// (e.g. "itzg/minecraft-server:java21").
	Image string

	// Command overrides the image's default entrypoint/command, if set.
	Command []string

	// Env is the container's environment variables. Secrets are expected to
	// already be decrypted by the caller — the Environment interface itself
	// has no opinion on secrets management (that's a Phase 4 concern in
	// umbrella-core, not the daemon's).
	Env map[string]string

	// WorkingDir is the host-side directory bind-mounted as the server's
	// persistent data directory (world files, configs, plugins).
	WorkingDir string

	// Limits are the resource constraints to apply.
	Limits ResourceLimits

	// PortBindings maps container port -> host port, for the allocations
	// Phase 2's hosting control plane assigns.
	PortBindings []PortBinding
}

// PortBinding is one container-port-to-host-port mapping.
type PortBinding struct {
	ContainerPort int
	HostPort      int
	Protocol      string // "tcp" or "udp"
}

// ResourceLimits are the constraints applied to a running container.
// Zero values mean "no explicit limit" for that dimension, not "limit to
// zero" — callers that want a hard zero limit (e.g. to pause scheduling)
// should not use this struct for that; it isn't the resource limits'
// responsibility to encode "not running" states.
type ResourceLimits struct {
	// MemoryBytes is the hard memory limit. 0 = unlimited.
	MemoryBytes int64

	// CPUCores is the CPU limit expressed in whole/fractional cores
	// (e.g. 2.5 = two and a half cores), translated to the runtime's own
	// units internally (Docker: NanoCPUs). 0 = unlimited.
	CPUCores float64

	// DiskBytes is a soft accounting limit surfaced to callers/UI; Docker
	// itself has no first-class per-container disk quota without a
	// quota-capable storage driver, so this is enforced by the disk-usage
	// monitoring/alerting path, not the container runtime, and that
	// distinction is intentional rather than an oversight.
	DiskBytes int64

	// NetworkBpsLimit caps network throughput in bytes/sec. 0 = unlimited.
	// Not enforced by the Docker driver in Phase 1 (Docker has no native
	// per-container bandwidth cap without an additional tc/netem layer) —
	// surfaced here now so the ContainerSpec shape doesn't need to change
	// when that enforcement is added; enforcement is honestly reported as
	// unimplemented in docker.go rather than silently ignored.
	NetworkBpsLimit int64
}

// ContainerStatus is the normalized lifecycle state of a container, mapped
// from whatever states the underlying runtime actually has.
type ContainerStatus string

const (
	StatusCreated  ContainerStatus = "created"
	StatusStarting ContainerStatus = "starting"
	StatusRunning  ContainerStatus = "running"
	StatusStopping ContainerStatus = "stopping"
	StatusStopped  ContainerStatus = "stopped"
	StatusCrashed  ContainerStatus = "crashed"
	StatusRemoved  ContainerStatus = "removed"
	StatusUnknown  ContainerStatus = "unknown"
)

// ContainerState is a point-in-time snapshot of a container's lifecycle
// state, returned by Create/Start/Stop/etc. and by Inspect.
type ContainerState struct {
	ServerID   string
	RuntimeID  string // the runtime's own container ID (Docker container ID)
	Status     ContainerStatus
	StartedAt  *time.Time
	FinishedAt *time.Time
	ExitCode   *int
	OOMKilled  bool
}

// StatsSnapshot is one point-in-time resource-usage sample for a running
// container. Fields mirror what Phase 1's DoD requires surfacing
// (CPU/RAM/disk/network) in runtime-agnostic units.
type StatsSnapshot struct {
	Timestamp        time.Time
	CPUPercent       float64 // 0-100 * NumCPUs, i.e. can exceed 100 on multi-core
	MemoryUsedBytes  int64
	MemoryLimitBytes int64
	DiskUsedBytes    int64
	NetworkRxBytes   int64 // cumulative since container start
	NetworkTxBytes   int64 // cumulative since container start
}

// Environment is the contract a runtime driver must satisfy. Every method
// takes ctx first and is expected to respect cancellation/deadlines —
// container operations against a real runtime are not instantaneous and
// callers (the control-plane connection handler) need to be able to time
// them out.
type Environment interface {
	// Create prepares a container from spec without starting it.
	Create(ctx context.Context, spec ContainerSpec) (ContainerState, error)

	// Start starts a previously-created container.
	Start(ctx context.Context, serverID string) (ContainerState, error)

	// Stop gracefully stops a running container, waiting up to
	// gracePeriod for the process to exit on its own (e.g. a Minecraft
	// server responding to SIGTERM by saving and shutting down) before
	// forcing termination.
	Stop(ctx context.Context, serverID string, gracePeriod time.Duration) (ContainerState, error)

	// Kill forcibly and immediately terminates a running container. Unlike
	// Stop, this never waits for graceful shutdown — reserved for
	// operator-initiated force-kills and the crash/watchdog path, not the
	// default stop action.
	Kill(ctx context.Context, serverID string) (ContainerState, error)

	// Restart is Stop followed by Start, as one operation so callers get a
	// single ContainerState result rather than orchestrating two calls
	// themselves (and so a future driver can implement it more efficiently
	// than two round-trips if its API supports that).
	Restart(ctx context.Context, serverID string, gracePeriod time.Duration) (ContainerState, error)

	// Remove deletes a stopped container's runtime resources. Does not
	// touch the bind-mounted WorkingDir — deleting server data is a
	// separate, explicit operation, never a side effect of container
	// removal.
	Remove(ctx context.Context, serverID string) error

	// Inspect returns the current state of a container without changing it.
	Inspect(ctx context.Context, serverID string) (ContainerState, error)

	// Stats returns one current resource-usage snapshot. Callers that want
	// a continuous stream poll this on an interval (see internal/stats) —
	// kept as a single-snapshot call here so the Environment interface
	// doesn't need its own streaming/subscription concept layered on top of
	// the one internal/console already provides for console I/O.
	Stats(ctx context.Context, serverID string) (StatsSnapshot, error)

	// Attach returns a bidirectional stream connected to the container's
	// console (stdin in, combined stdout+stderr out). Closing the returned
	// io.Closer detaches without stopping the container.
	Attach(ctx context.Context, serverID string) (ConsoleStream, error)
}

// ConsoleStream is a live, bidirectional connection to a running
// container's console.
type ConsoleStream interface {
	io.Reader // reads combined stdout+stderr
	io.Writer // writes become the container's stdin
	io.Closer // detach without stopping the container
}
