"""
tests/test_daemon_client.py — Tests for services/daemon_client.py.

Uses httpx's MockTransport (httpx's own supported testing mechanism, not a
project-specific fake), injected through DaemonClient's real constructor —
these tests exercise the actual `_request` method's error handling and
request construction, not a monkeypatched substitute for it.
"""
import json

import httpx
import pytest

from services.daemon_client import ContainerState, DaemonClient, DaemonError, StatsSnapshot

SECRET = "a-shared-secret-at-least-32-bytes-long-ok"


def _client(handler) -> DaemonClient:
    return DaemonClient(
        "https://node1.example.com:8443",
        "node-1",
        SECRET,
        transport=httpx.MockTransport(handler),
    )


@pytest.mark.asyncio
async def test_start_sends_authenticated_request_and_parses_response():
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["auth_header"] = request.headers.get("Authorization")
        return httpx.Response(
            200,
            json={"ServerID": "srv-1", "RuntimeID": "docker-abc", "Status": "running", "OOMKilled": False},
        )

    client = _client(handler)
    state = await client.start("srv-1")

    assert captured["url"] == "https://node1.example.com:8443/v1/servers/srv-1/start"
    assert captured["auth_header"].startswith("Bearer ")
    assert isinstance(state, ContainerState)
    assert state.status == "running"
    assert state.runtime_id == "docker-abc"


@pytest.mark.asyncio
async def test_stop_sends_grace_period_in_body():
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content) if request.content else None
        return httpx.Response(200, json={"ServerID": "srv-1", "Status": "stopped"})

    client = _client(handler)
    await client.stop("srv-1", grace_period_seconds=45)

    assert captured["body"] == {"grace_period_seconds": 45}


@pytest.mark.asyncio
async def test_stop_omits_body_when_no_grace_period_given():
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["body"] = request.content
        return httpx.Response(200, json={"ServerID": "srv-1", "Status": "stopped"})

    client = _client(handler)
    await client.stop("srv-1")

    assert captured["body"] in (b"", b"null", None)


@pytest.mark.asyncio
async def test_error_response_raises_daemon_error_with_status_code():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, text="no such container")

    client = _client(handler)
    with pytest.raises(DaemonError) as exc_info:
        await client.state("srv-missing")
    assert exc_info.value.status_code == 404


@pytest.mark.asyncio
async def test_stats_parses_snapshot_correctly():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "Timestamp": "2026-07-07T12:00:00Z",
                "CPUPercent": 42.5,
                "MemoryUsedBytes": 500_000_000,
                "MemoryLimitBytes": 2_000_000_000,
                "NetworkRxBytes": 1000,
                "NetworkTxBytes": 500,
            },
        )

    client = _client(handler)
    stats = await client.stats("srv-1")

    assert isinstance(stats, StatsSnapshot)
    assert stats.cpu_percent == 42.5
    assert stats.memory_used_bytes == 500_000_000


@pytest.mark.asyncio
async def test_network_error_raises_daemon_error():
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("connection refused")

    client = _client(handler)
    with pytest.raises(DaemonError):
        await client.state("srv-1")


@pytest.mark.asyncio
async def test_create_sends_expected_body_shape():
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["method"] = request.method
        captured["url"] = str(request.url)
        captured["body"] = json.loads(request.content)
        return httpx.Response(201, json={"ServerID": "srv-1", "Status": "created"})

    client = _client(handler)
    state = await client.create(
        "srv-1",
        image="itzg/minecraft-server:java21",
        working_dir="/srv/umbrella/srv-1",
        memory_bytes=2_147_483_648,
        cpu_cores=1.5,
        env={"EULA": "TRUE"},
        port_bindings=[{"container_port": 25565, "host_port": 30001, "protocol": "tcp"}],
    )

    assert captured["method"] == "POST"
    assert captured["url"] == "https://node1.example.com:8443/v1/servers/srv-1"
    assert captured["body"]["image"] == "itzg/minecraft-server:java21"
    assert captured["body"]["env"] == {"EULA": "TRUE"}
    assert captured["body"]["port_bindings"][0]["host_port"] == 30001
    assert state.status == "created"


@pytest.mark.asyncio
async def test_remove_sends_delete_and_handles_empty_response():
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["method"] = request.method
        captured["url"] = str(request.url)
        return httpx.Response(204)

    client = _client(handler)
    await client.remove("srv-1")  # must not raise on an empty 204 body

    assert captured["method"] == "DELETE"
    assert captured["url"] == "https://node1.example.com:8443/v1/servers/srv-1"


@pytest.mark.asyncio
async def test_restart_and_kill_hit_expected_paths():
    captured_paths = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured_paths.append(request.url.path)
        return httpx.Response(200, json={"ServerID": "srv-1", "Status": "running"})

    client = _client(handler)
    await client.restart("srv-1")
    await client.kill("srv-1")

    assert captured_paths == ["/v1/servers/srv-1/restart", "/v1/servers/srv-1/kill"]
